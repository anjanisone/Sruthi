from contextlib import asynccontextmanager

from fastapi import FastAPI

from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .routers import events, files, jobs, outputs, repo, review
from .upload.router import router as upload_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Attach outbound TokenProvider when configured (Sruthi/ref Java: TokenProviderFactory).

    Access in routes via getattr(request.app.state, \"outbound_token_provider\", None).
    """
    app.state.outbound_token_provider = create_outbound_token_provider()
    yield


app = FastAPI(
    title="AURA API",
    version="0.1.0",
    description="Documentation-first FastAPI prototype of the endpoints captured in Sruthi/6 API Plan screenshots.",
    lifespan=lifespan,
)

app.add_middleware(AuthEnforcementMiddleware)

app.include_router(auth_router)
app.include_router(upload_router)
app.include_router(repo.router)
app.include_router(files.router)
app.include_router(jobs.router)
app.include_router(review.router)
app.include_router(outputs.router)
app.include_router(events.router)


@app.get("/health", tags=["meta"], summary="Liveness probe (always unauthenticated)")
def health() -> dict:
    return {"status": "ok"}

