from __future__ import annotations

from flask import Flask

from .outbound.token_provider_factory import create_outbound_token_provider
from .security import register_auth_hook


def create_app() -> Flask:
    app = Flask(__name__)
    app.json.sort_keys = False
    app.outbound_token_provider = create_outbound_token_provider()

    register_auth_hook(app)

    from .auth.routes import bp as auth_bp
    from .upload.routes import bp as upload_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(upload_bp)

    from .views import register_routes

    register_routes(app)
    return app
