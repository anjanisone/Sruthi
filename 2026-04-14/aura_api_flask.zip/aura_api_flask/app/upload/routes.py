from __future__ import annotations

from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    PresignedUrlData,
    PresignedUrlRequest,
    PresignedUrlResponse,
    UploadConfirmData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE

bp = Blueprint("upload", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


@bp.post("/upload/presigned-url")
def create_presigned_url():
    try:
        _ = PresignedUrlRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "UPLOADING", "file_count": 0}
    return _j(
        PresignedUrlResponse(
            success=True,
            data=PresignedUrlData(
                upload_id=upload_id,
                presigned_url="https://s3.amazonaws.com/...",
                expires_in=3600,
                s3_path=f"jobs/{upload_id}/input/",
                max_file_size_bytes=524288000,
            ),
            errors=[],
        )
    )


@bp.post("/upload/confirm")
def confirm_upload():
    try:
        payload = UploadConfirmRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.uploads_status[payload.upload_id] = {"status": "COMPLETED", "file_count": 150}
    return _j(
        UploadConfirmResponse(
            success=True,
            data=UploadConfirmData(upload_id=payload.upload_id, status="VALIDATED", file_count=150),
            errors=[],
        )
    )


@bp.get("/upload/<upload_id>/status")
def upload_status(upload_id: str):
    record = STATE.uploads_status.get(upload_id) or {"status": "CLONING", "file_count": 150}
    return _j(
        UploadStatusResponse(
            success=True,
            data=UploadStatusData(upload_id=upload_id, status=record["status"], file_count=record["file_count"]),
            errors=[],
        )
    )

