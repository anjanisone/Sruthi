# TODO

- **Full Java `C2CTokenProvider` parity**: integrate the proprietary **JPMC C2C Identity / AWS→ADFS** client (`AwsToAdfsOAuth2ClientCredentialsGrantTokenProvider`) or an approved internal Python binding / sidecar when it becomes available. Today’s stack uses HTTP proxies (`AURA_C2C_TOKEN_ENDPOINT`), local STS replay, and optional **`c2c_secret`** / **CERT JWT** outbound providers as stand-ins.
