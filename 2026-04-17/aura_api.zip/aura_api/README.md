# AURA API (FastAPI) — Endpoint Documentation Prototype

This project is a lightweight FastAPI implementation that mirrors the **endpoint shapes** (paths, request bodies, response envelopes) captured in the `Sruthi/6` “API Plan” screenshots.

## Run locally

```bash
cd "aura_api"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then open:
- **Swagger UI**: `http://127.0.0.1:8000/docs`
- **OpenAPI JSON**: `http://127.0.0.1:8000/openapi.json`

## Notes

- This is **documentation-first**: endpoints return example-shaped payloads and maintain minimal in-memory state for demo purposes.
- **Authentication** follows `Sruthi/ref`: **C2C token exchange** (RFC 8693 form POST to a configured corporate token URL, same shape as `getTokenFromC2C`), optional **local** token exchange for sandboxes (replay GCI `subject_token` to STS and mint an AURA JWT), plus **`client_credentials`** for local demos.

### `POST /auth/token`

- **`grant_type=client_credentials`** — JSON body must include `client_id` and `client_secret`. Defaults match `AURA_CLIENT_ID` / `AURA_CLIENT_SECRET` (see below).
- **`grant_type=urn:ietf:params:oauth:grant-type:token-exchange`** — requires `audience`, `subject_token`, and `subject_token_type`. Supported `subject_token_type` values mirror the reference screenshots:
  - `urn:jpmc:params:identity:token-type:aws-get-caller-identity`
  - `urn:aura:params:identity:token-type:aws-get-caller-identity`

**C2C path (intended production):** set `AURA_C2C_TOKEN_ENDPOINT` to the corporate C2C token URL. The API forwards `grant_type`, `audience`, `requested_token_type`, `subject_token`, and `subject_token_type` as `application/x-www-form-urlencoded`, adds `x-client-request-id` (UUID), and returns the upstream `access_token` (and `expires_in` / `scope` when present) inside the usual `AuthTokenResponse` envelope.

**Local path (no C2C URL, or `AURA_TOKEN_EXCHANGE_MODE=local`):** the `subject_token` must be base64 JSON for an STS `GetCallerIdentity` POST; the server replays it to AWS STS and mints an HS256 **AURA** JWT.

### Environment variables

| Variable | Purpose |
| --- | --- |
| `AURA_C2C_TOKEN_ENDPOINT` | C2C OAuth token URL; when set, `AURA_TOKEN_EXCHANGE_MODE=auto` uses C2C for `token_exchange`. |
| `AURA_C2C_REQUESTED_TOKEN_TYPE` | `requested_token_type` sent to C2C (default matches ref: JWT bearer assertion type). |
| `AURA_C2C_TIMEOUT_SECONDS` | HTTP timeout for C2C calls (default `45`). |
| `AURA_C2C_SSL_CA_BUNDLE` | Optional path to a CA bundle for TLS verification to C2C. |
| `AURA_C2C_INSECURE_SKIP_TLS_VERIFY` | If `true`, disables TLS verification to C2C (**lab only**). |
| `AURA_TOKEN_EXCHANGE_MODE` | `auto` (default: C2C if `AURA_C2C_TOKEN_ENDPOINT` is set, else local STS), `c2c` (require C2C URL), or `local` (never call C2C). |
| `AURA_JWT_SECRET` | HMAC secret for tokens minted on the **local** token-exchange path and for `client_credentials`. |
| `AURA_JWT_EXPIRES_SECONDS` | Default TTL when upstream omits `expires_in` (also used for locally minted tokens). |
| `AURA_CLIENT_ID` / `AURA_CLIENT_SECRET` | Demo client credentials for `client_credentials` grant. |
| `AURA_REQUIRE_AUTH` | When `true`/`1`/`yes`, routes require `Authorization: Bearer …`. Validation uses `AURA_JWT_SECRET`, so it matches **locally minted** JWTs. Tokens returned **only** from C2C are usually issued by another IdP; use a gateway or extend validation (JWKS) if you need `AURA_REQUIRE_AUTH` with C2C tokens. |

### Outbound auth (Sruthi/ref videos — `s3-llmsuite-utility-image` Java `net.chase.cardpricing.auth`)

The ref screen recordings show a **Java** layout: `AuthMethod` (`CERT` vs `C2C`), `TokenProvider`, `CertBasedTokenProvider`, `C2CTokenProvider` (JPMC **AWS→ADFS** SDK + `user_impersonation` + 600s refresh buffer), `JwtBuilder` (RS256 client assertion), and `TokenProviderFactory`.

Python parity lives under `app/outbound/`:

| Java | Python |
| --- | --- |
| `TokenProvider` | `outbound.token_provision.TokenProvider` |
| `CertBasedTokenProvider` | `outbound.cert_based_token_provider.CertBasedTokenProvider` |
| `C2CTokenProvider` (SDK) | `outbound.c2c_client_secret_provider.C2cClientSecretTokenProvider` (**lab** client_secret grant; the proprietary `AwsToAdfsOAuth2ClientCredentialsGrantTokenProvider` is not available in this repo) |
| `JwtBuilder` | `outbound.jwt_assertion.build_adfs_client_assertion_jwt` |
| `TokenProviderFactory` | `outbound.token_provider_factory.create_outbound_token_provider` |

Set **`AURA_OUTBOUND_AUTH_METHOD`** to `none` (default), `cert`, or `c2c_secret`. On startup, `create_outbound_token_provider()` is stored on **`app.state.outbound_token_provider`** for use when calling downstream APIs (e.g. LLM Suite).

Shared ADFS settings:

| Variable | Purpose |
| --- | --- |
| `AURA_ADFS_TOKEN_ENDPOINT` | ADFS / Entra token URL |
| `AURA_ADFS_CLIENT_ID` | Application (client) ID |
| `AURA_ADFS_RESOURCE_URI` | `resource` parameter (Java `resourceUri`) |
| `AURA_ADFS_CLIENT_CERT_PEM` / `AURA_ADFS_CLIENT_KEY_PEM` | PEM paths for **cert** mode |
| `AURA_ADFS_CLIENT_KEY_PASSWORD` | Optional key encryption password |
| `AURA_C2C_CLIENT_SECRET` | Client secret for **c2c_secret** mode only |
| `AURA_ADFS_HTTP_TIMEOUT_SECONDS` | HTTP timeout (default `45`) |
| `AURA_ADFS_SSL_CA_BUNDLE` | Optional CA bundle path |
| `AURA_ADFS_INSECURE_SKIP_TLS_VERIFY` | Lab only: disable TLS verify to ADFS |

A **Flask** twin with the same HTTP surface and env behaviour lives in **`Sruthi/aura_api_flask`**. Long-term gaps (e.g. full JPMC C2C SDK) are listed in **`TODO.md`**.

