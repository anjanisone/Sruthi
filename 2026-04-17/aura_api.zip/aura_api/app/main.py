from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .ingest.router import router as ingest_router
from .jobs.router import router as jobs_router
from .kb.router import router as kb_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .review.router import router as review_router
from .upload.router import router as upload_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Attach outbound TokenProvider when configured (Sruthi/ref Java: TokenProviderFactory).

    Access in routes via getattr(request.app.state, \"outbound_token_provider\", None).
    """
    app.state.outbound_token_provider = create_outbound_token_provider()
    yield


app = FastAPI(
    title="AURA API",
    version="0.2.1",
    description=(
        "Auth, upload, ingest, KB, job management (jobs, ReRun, Chunks/diff), review, outputs, "
        "WebSocket events (documentation-first)."
    ),
    lifespan=lifespan,
)

app.add_middleware(AuthEnforcementMiddleware)

app.include_router(auth_router)
app.include_router(upload_router)
app.include_router(ingest_router)
app.include_router(kb_router)
app.include_router(jobs_router)
app.include_router(review_router)


@app.get("/health", tags=["meta"], summary="Liveness probe (always unauthenticated)")
def health() -> dict:
    return {"status": "ok"}


@app.websocket("/ws/jobs/{job_id}")
async def job_events_websocket(websocket: WebSocket, job_id: str) -> None:
    """Real-time phase / chunk / error / complete events (demo stream)."""
    await websocket.accept()
    try:
        await websocket.send_json(
            {"event": "phase", "job_id": job_id, "phase": 1, "message": "stream_open"}
        )
        await websocket.send_json(
            {"event": "chunk", "job_id": job_id, "chunk_id": "chunk_1", "status": "SUCCESS"}
        )
        await websocket.send_json({"event": "complete", "job_id": job_id, "ok": True})
    except WebSocketDisconnect:
        return
