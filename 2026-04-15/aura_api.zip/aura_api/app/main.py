from contextlib import asynccontextmanager

from fastapi import FastAPI

from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .ingest.router import router as ingest_router
from .jobs.router import router as jobs_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .upload.router import router as upload_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Attach outbound TokenProvider when configured (Sruthi/ref Java: TokenProviderFactory).

    Access in routes via getattr(request.app.state, \"outbound_token_provider\", None).
    """
    app.state.outbound_token_provider = create_outbound_token_provider()
    yield


app = FastAPI(
    title="AURA API",
    version="0.1.0",
    description="Auth, upload, ingest (repo clone + file browser), and jobs (list, estimate, proceed).",
    lifespan=lifespan,
)

app.add_middleware(AuthEnforcementMiddleware)

app.include_router(auth_router)
app.include_router(upload_router)
app.include_router(ingest_router)
app.include_router(jobs_router)


@app.get("/health", tags=["meta"], summary="Liveness probe (always unauthenticated)")
def health() -> dict:
    return {"status": "ok"}

