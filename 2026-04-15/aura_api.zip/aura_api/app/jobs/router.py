from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query, status

from ..models import (
    CostEstimate,
    CostEstimateBreakdown,
    DeleteJobData,
    DeleteJobResponse,
    DiscardEstimateData,
    DiscardEstimateResponse,
    Estimation,
    JobsEstimateData,
    JobsEstimateRequest,
    JobsEstimateResponse,
    JobSummary,
    ListJobsData,
    ListJobsQuerySortBy,
    ListJobsResponse,
    Pagination,
    ProceedFromEstimateData,
    ProceedFromEstimateRequest,
    ProceedFromEstimateResponse,
    SortOrder,
    TimeEstimate,
)
from ..state import STATE

router = APIRouter(tags=["jobs"])


@router.get(
    "/jobs",
    response_model=ListJobsResponse,
    summary="List jobs with pagination and sort",
)
def list_jobs(
    sort_by: ListJobsQuerySortBy = Query(ListJobsQuerySortBy.updated_at),
    sort_order: SortOrder = Query(SortOrder.desc),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> ListJobsResponse:
    summaries: list[JobSummary] = []
    for rec in STATE.jobs.values():
        s = rec.get("summary")
        if isinstance(s, JobSummary):
            summaries.append(s)
    reverse = sort_order == SortOrder.desc
    if sort_by == ListJobsQuerySortBy.created_at:
        summaries.sort(key=lambda j: j.created_at, reverse=reverse)
    elif sort_by == ListJobsQuerySortBy.status:
        summaries.sort(key=lambda j: j.status, reverse=reverse)
    else:
        summaries.sort(key=lambda j: j.updated_at, reverse=reverse)

    total = len(summaries)
    total_pages = max(1, (total + page_size - 1) // page_size) if total else 1
    start = (page - 1) * page_size
    page_jobs = summaries[start : start + page_size]

    return ListJobsResponse(
        success=True,
        data=ListJobsData(
            jobs=page_jobs,
            pagination=Pagination(
                page=page,
                page_size=page_size,
                total_items=total,
                total_pages=total_pages,
            ),
        ),
        errors=[],
    )


@router.delete(
    "/jobs/{job_id}",
    response_model=DeleteJobResponse,
    summary="Cancel or delete a job (demo: marks CANCELLED)",
)
def delete_job(job_id: str) -> DeleteJobResponse:
    rec = STATE.jobs.get(job_id)
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    summary = rec["summary"]
    if not isinstance(summary, JobSummary):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    prev = summary.status
    summary.status = "CANCELLED"
    summary.updated_at = datetime.utcnow()
    return DeleteJobResponse(
        success=True,
        data=DeleteJobData(job_id=job_id, previous_status=prev, new_status="CANCELLED"),
        errors=[],
    )


@router.post(
    "/jobs/estimate",
    response_model=JobsEstimateResponse,
    summary="Create a cost / time estimate for an upload before starting a job",
)
def create_estimate(payload: JobsEstimateRequest) -> JobsEstimateResponse:
    estimate_id = str(uuid.uuid4())
    now = datetime.utcnow()
    data = JobsEstimateData(
        estimate_id=estimate_id,
        status="ESTIMATED",
        estimation=Estimation(
            total_files=150,
            total_lines=45000,
            total_tokens=125000,
            estimated_chunks=25,
            oversized_files=3,
            languages_detected={"java": 80, "python": 50},
        ),
        cost_estimate=CostEstimate(
            bedrock_input_tokens=125000,
            bedrock_output_tokens=75000,
            estimated_cost_usd=2.45,
            pricing_model="claude-3-sonnet",
            breakdown=CostEstimateBreakdown(phase_4_input_cost=1.0, phase_4_output_cost=1.0),
        ),
        time_estimate=TimeEstimate(
            estimated_duration_minutes=15,
            phase_breakdown={"phase_1": 1, "phase_4": 10},
        ),
        phase_1_output_path=f"jobs/{estimate_id}/phase1/",
    )
    STATE.estimates[estimate_id] = {
        "upload_id": payload.upload_id,
        "config": payload.config.model_dump(),
        "status": "ESTIMATED",
        "data": data,
        "created_at": now,
    }
    return JobsEstimateResponse(success=True, data=data, errors=[])


@router.post(
    "/jobs/estimates/{estimate_id}/proceed",
    response_model=ProceedFromEstimateResponse,
    summary="Start a job from a completed estimate",
)
def proceed_from_estimate(
    estimate_id: str,
    payload: ProceedFromEstimateRequest,
) -> ProceedFromEstimateResponse:
    est = STATE.estimates.get(estimate_id)
    if not est or est.get("status") != "ESTIMATED":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Estimate not found or not active.")
    job_id = str(uuid.uuid4())
    STATE.seed_job(job_id)
    summary = STATE.jobs[job_id]["summary"]
    if isinstance(summary, JobSummary):
        summary.status = "RUNNING"
        summary.phase_completed = payload.stop_after_phase or 1
        summary.job_name = f"Job from estimate {estimate_id[:8]}"
    return ProceedFromEstimateResponse(
        success=True,
        data=ProceedFromEstimateData(
            job_id=job_id,
            status="RUNNING",
            starting_phase=2,
            skipped_phases=[1],
            message="Job started from Phase 2 (Phase 1 results reused from estimation)",
        ),
        errors=[],
    )


@router.post(
    "/jobs/estimates/{estimate_id}/discard",
    response_model=DiscardEstimateResponse,
    summary="Discard an estimate and release temp resources (demo)",
)
def discard_estimate(estimate_id: str) -> DiscardEstimateResponse:
    est = STATE.estimates.get(estimate_id)
    if not est:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Estimate not found.")
    est["status"] = "DISCARDED"
    return DiscardEstimateResponse(
        success=True,
        data=DiscardEstimateData(estimate_id=estimate_id, status="DISCARDED", cleanup_completed=True),
        errors=[],
    )
