from __future__ import annotations

import uuid
from datetime import datetime
from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    CostEstimate,
    CostEstimateBreakdown,
    DeleteJobData,
    DeleteJobResponse,
    DiscardEstimateData,
    DiscardEstimateResponse,
    Estimation,
    JobsEstimateData,
    JobsEstimateRequest,
    JobsEstimateResponse,
    JobSummary,
    ListJobsData,
    ListJobsQuerySortBy,
    ListJobsResponse,
    Pagination,
    ProceedFromEstimateData,
    ProceedFromEstimateRequest,
    ProceedFromEstimateResponse,
    SortOrder,
    TimeEstimate,
)
from ..state import STATE

bp = Blueprint("jobs", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


@bp.get("/jobs")
def list_jobs():
    try:
        sort_by = ListJobsQuerySortBy(request.args.get("sort_by", "updated_at"))
        sort_order = SortOrder(request.args.get("sort_order", "desc"))
    except ValueError:
        return jsonify({"detail": "Invalid sort_by or sort_order"}), HTTPStatus.BAD_REQUEST
    try:
        page = max(1, int(request.args.get("page", 1)))
        page_size = min(200, max(1, int(request.args.get("page_size", 50))))
    except ValueError:
        return jsonify({"detail": "Invalid page or page_size"}), HTTPStatus.BAD_REQUEST

    summaries: list[JobSummary] = []
    for rec in STATE.jobs.values():
        s = rec.get("summary")
        if isinstance(s, JobSummary):
            summaries.append(s)
    reverse = sort_order == SortOrder.desc
    if sort_by == ListJobsQuerySortBy.created_at:
        summaries.sort(key=lambda j: j.created_at, reverse=reverse)
    elif sort_by == ListJobsQuerySortBy.status:
        summaries.sort(key=lambda j: j.status, reverse=reverse)
    else:
        summaries.sort(key=lambda j: j.updated_at, reverse=reverse)

    total = len(summaries)
    total_pages = max(1, (total + page_size - 1) // page_size) if total else 1
    start = (page - 1) * page_size
    page_jobs = summaries[start : start + page_size]

    return _j(
        ListJobsResponse(
            success=True,
            data=ListJobsData(
                jobs=page_jobs,
                pagination=Pagination(
                    page=page,
                    page_size=page_size,
                    total_items=total,
                    total_pages=total_pages,
                ),
            ),
            errors=[],
        )
    )


@bp.delete("/jobs/<job_id>")
def delete_job(job_id: str):
    rec = STATE.jobs.get(job_id)
    if not rec:
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    summary = rec["summary"]
    if not isinstance(summary, JobSummary):
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    prev = summary.status
    summary.status = "CANCELLED"
    summary.updated_at = datetime.utcnow()
    return _j(
        DeleteJobResponse(
            success=True,
            data=DeleteJobData(job_id=job_id, previous_status=prev, new_status="CANCELLED"),
            errors=[],
        )
    )


@bp.post("/jobs/estimate")
def create_estimate():
    try:
        payload = JobsEstimateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    estimate_id = str(uuid.uuid4())
    now = datetime.utcnow()
    data = JobsEstimateData(
        estimate_id=estimate_id,
        status="ESTIMATED",
        estimation=Estimation(
            total_files=150,
            total_lines=45000,
            total_tokens=125000,
            estimated_chunks=25,
            oversized_files=3,
            languages_detected={"java": 80, "python": 50},
        ),
        cost_estimate=CostEstimate(
            bedrock_input_tokens=125000,
            bedrock_output_tokens=75000,
            estimated_cost_usd=2.45,
            pricing_model="claude-3-sonnet",
            breakdown=CostEstimateBreakdown(phase_4_input_cost=1.0, phase_4_output_cost=1.0),
        ),
        time_estimate=TimeEstimate(
            estimated_duration_minutes=15,
            phase_breakdown={"phase_1": 1, "phase_4": 10},
        ),
        phase_1_output_path=f"jobs/{estimate_id}/phase1/",
    )
    STATE.estimates[estimate_id] = {
        "upload_id": payload.upload_id,
        "config": payload.config.model_dump(),
        "status": "ESTIMATED",
        "data": data,
        "created_at": now,
    }
    return _j(JobsEstimateResponse(success=True, data=data, errors=[]))


@bp.post("/jobs/estimates/<estimate_id>/proceed")
def proceed_from_estimate(estimate_id: str):
    try:
        payload = ProceedFromEstimateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    est = STATE.estimates.get(estimate_id)
    if not est or est.get("status") != "ESTIMATED":
        return jsonify({"detail": "Estimate not found or not active."}), HTTPStatus.NOT_FOUND
    job_id = str(uuid.uuid4())
    STATE.seed_job(job_id)
    summary = STATE.jobs[job_id]["summary"]
    if isinstance(summary, JobSummary):
        summary.status = "RUNNING"
        summary.phase_completed = payload.stop_after_phase or 1
        summary.job_name = f"Job from estimate {estimate_id[:8]}"
    return _j(
        ProceedFromEstimateResponse(
            success=True,
            data=ProceedFromEstimateData(
                job_id=job_id,
                status="RUNNING",
                starting_phase=2,
                skipped_phases=[1],
                message="Job started from Phase 2 (Phase 1 results reused from estimation)",
            ),
            errors=[],
        )
    )


@bp.post("/jobs/estimates/<estimate_id>/discard")
def discard_estimate(estimate_id: str):
    est = STATE.estimates.get(estimate_id)
    if not est:
        return jsonify({"detail": "Estimate not found."}), HTTPStatus.NOT_FOUND
    est["status"] = "DISCARDED"
    return _j(
        DiscardEstimateResponse(
            success=True,
            data=DiscardEstimateData(estimate_id=estimate_id, status="DISCARDED", cleanup_completed=True),
            errors=[],
        )
    )
