from __future__ import annotations

import os
from pathlib import Path
from typing import FrozenSet

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _truthy(name: str, default: str = "") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


JWT_SECRET: str = os.getenv(
    "AURA_JWT_SECRET",
    "dev-only-change-me-please-use-AURA_JWT_SECRET-in-real-envs",
)
JWT_ALGORITHM: str = os.getenv("AURA_JWT_ALGORITHM", "HS256")
JWT_EXPIRES_SECONDS: int = int(os.getenv("AURA_JWT_EXPIRES_SECONDS", "3600"))

REQUIRE_AUTH: bool = _truthy("AURA_REQUIRE_AUTH")

# When true, /docs serves a small HTML page with no CDN (Swagger UI JS is blocked on many corporate networks).
DOCS_CDN_OFFLINE: bool = _truthy("AURA_DOCS_CDN_OFFLINE")

# Browser loads these URLs for interactive Swagger/ReDoc. Point to an internal mirror if jsdelivr is blocked.
# Server HTTP_PROXY does not apply to the browser — configure OS/browser proxy OR use AURA_DOCS_CDN_OFFLINE=1.
SWAGGER_UI_DIST_CDN: str = os.getenv(
    "AURA_SWAGGER_UI_DIST_CDN",
    "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5",
).strip().rstrip("/")
REDOC_STANDALONE_JS: str = os.getenv(
    "AURA_REDOC_STANDALONE_JS",
    "https://cdn.jsdelivr.net/npm/redoc/bundles/redoc.standalone.js",
).strip()

CLIENT_ID: str = os.getenv("AURA_CLIENT_ID", "aura-demo-client")
CLIENT_SECRET: str = os.getenv("AURA_CLIENT_SECRET", "aura-demo-secret")

# Dev-only: POST /auth/token client_credentials accepts only client_id (no client_secret). Never enable in production.
ALLOW_CLIENT_CREDENTIALS_NO_SECRET: bool = _truthy("AURA_ALLOW_CLIENT_CREDENTIALS_NO_SECRET")

AWS_GET_CALLER_IDENTITY_TOKEN_TYPES: FrozenSet[str] = frozenset(
    {
        "urn:jpmc:params:identity:token-type:aws-get-caller-identity",
        "urn:aura:params:identity:token-type:aws-get-caller-identity",
    }
)

STS_POST_BODY_DEFAULT: str = "Action=GetCallerIdentity&Version=2011-06-15"


def _optional_str(name: str) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    stripped = raw.strip()
    return stripped or None


# ---------------------------------------------------------------------------
# 2026-04-29 — JPMC C2C OAuth2 token exchange (RFC 8693) → IDA JWT
#
# POST $AURA_C2C_TOKEN_ENDPOINT
#   Headers: Content-Type: application/x-www-form-urlencoded, x-client-request-id: <uuid>
#   Body (form): grant_type, audience, requested_token_type, subject_token, subject_token_type
#
# curl reference:
#   grant_type=urn:ietf:params:oauth:grant-type:token-exchange
#   audience=https://idag2.jpmorganchase.com/adfs/oauth2/token/
#   requested_token_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer
#   subject_token=<aws-get-caller-identity token>
#   subject_token_type=urn:jpmc:params:identity:token-type:aws-get-caller-identity
#
# Role client (Basic auth only if AURA_C2C_CLIENT_SECRET is set):
#   c2c:aws:588866471920:app-aura-api-role
# GCI subject token audience claim must be exactly: https://idp.prod.aws.jpmchase.net
# ---------------------------------------------------------------------------
C2C_TOKEN_ENDPOINT: str = (
    _optional_str("AURA_C2C_TOKEN_ENDPOINT")
    or "https://idp.us-east-1.prod.aws.jpmchase.net/token"
)
C2C_IDA_ADFS_AUDIENCE: str = (
    os.getenv(
        "AURA_C2C_IDA_ADFS_AUDIENCE",
        "https://idag2.jpmorganchase.com/adfs/oauth2/token/",
    ).strip()
    or "https://idag2.jpmorganchase.com/adfs/oauth2/token/"
)
C2C_GRANT_TYPE_TOKEN_EXCHANGE: str = "urn:ietf:params:oauth:grant-type:token-exchange"
C2C_REQUESTED_TOKEN_TYPE: str = (
    os.getenv(
        "AURA_C2C_REQUESTED_TOKEN_TYPE",
        "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
    ).strip()
    or "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
)
C2C_CLIENT_ID: str = (
    os.getenv("AURA_C2C_CLIENT_ID", "c2c:aws:588866471920:app-aura-api-role").strip()
    or "c2c:aws:588866471920:app-aura-api-role"
)
C2C_CLIENT_SECRET: str | None = _optional_str("AURA_C2C_CLIENT_SECRET")
C2C_USE_SDK: bool = _truthy("AURA_C2C_USE_SDK")
C2C_SDK_ENTRYPOINT: str | None = _optional_str("AURA_C2C_SDK_ENTRYPOINT")
C2C_TIMEOUT_SECONDS: int = int(os.getenv("AURA_C2C_TIMEOUT_SECONDS", "45"))
C2C_VERIFY_SSL: bool = not _truthy("AURA_C2C_INSECURE_SKIP_TLS_VERIFY")
C2C_SSL_CA_BUNDLE: str | None = _optional_str("AURA_C2C_SSL_CA_BUNDLE")

# ADFS OAuth2 token URL for direct POST /auth/token grants (adfs_*), not the C2C IDP host.
ADFS_TOKEN_ENDPOINT: str | None = _optional_str("AURA_ADFS_TOKEN_ENDPOINT")
ADFS_RESOURCE_URI: str | None = _optional_str("AURA_ADFS_RESOURCE_URI")

ADFS_HTTP_TIMEOUT_SECONDS: int = int(os.getenv("AURA_ADFS_HTTP_TIMEOUT_SECONDS", "45"))

ALLOW_GCI_SUBJECT_TOKEN_BUILDER: bool = _truthy("AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER")

ALLOW_GCI_BUILDER_AWS_CLI_CREDS: bool = _truthy("AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS", "true")

# Server-side zip upload to S3 (PutObject / managed multipart inside boto3).
S3_BUCKET: str | None = _optional_str("AURA_S3_BUCKET")
S3_REGION: str = (
    (_optional_str("AURA_S3_REGION") or _optional_str("AWS_DEFAULT_REGION") or "us-east-1").strip()
)
S3_UPLOAD_PREFIX: str = os.getenv("AURA_S3_UPLOAD_PREFIX", "jobs").strip().strip("/") or "jobs"
S3_MAX_FILE_SIZE_BYTES: int = int(os.getenv("AURA_S3_MAX_FILE_SIZE_BYTES", "524288000"))
# Zip extract + git clone: cap total bytes and number of objects uploaded to S3 under jobs/{id}/source/.
S3_MAX_EXTRACTED_TOTAL_BYTES: int = int(os.getenv("AURA_S3_MAX_EXTRACTED_TOTAL_BYTES", str(10 * 1024 * 1024 * 1024)))
S3_MAX_EXTRACT_FILES: int = int(os.getenv("AURA_S3_MAX_EXTRACT_FILES", "20000"))
GIT_CLONE_TIMEOUT_SECONDS: int = int(os.getenv("AURA_GIT_CLONE_TIMEOUT_SECONDS", "900"))
# Unzip + many PutObject calls can exceed a single-object PUT timeout.
UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS: int = int(os.getenv("AURA_UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS", "3600"))

# POST /upload-zip/file: avoid "infinite loading" when the client or S3 stalls (common on Windows / proxies / AV).
UPLOAD_READ_CHUNK_TIMEOUT_SECONDS: float = float(os.getenv("AURA_UPLOAD_READ_CHUNK_TIMEOUT_SECONDS", "300"))
UPLOAD_S3_PUT_TIMEOUT_SECONDS: float = float(os.getenv("AURA_UPLOAD_S3_PUT_TIMEOUT_SECONDS", "7200"))

# boto3 S3 client (see app/upload/s3_presign.py).
S3_CONNECT_TIMEOUT_SECONDS: int = max(1, int(os.getenv("AURA_S3_CONNECT_TIMEOUT_SECONDS", "15")))
S3_READ_TIMEOUT_SECONDS: int = max(1, int(os.getenv("AURA_S3_READ_TIMEOUT_SECONDS", "600")))
BOTO_PROXY_USE_FORWARDING_HTTPS: bool = _truthy("AURA_BOTO_PROXY_USE_FORWARDING_HTTPS")


def _ensure_standard_proxy_env_from_aura_aliases() -> None:
    """
    boto3/urllib3 read HTTP_PROXY, HTTPS_PROXY, NO_PROXY. If those are unset, copy from
    AURA_HTTP_PROXY / AURA_HTTPS_PROXY / AURA_NO_PROXY so one .env style works everywhere.
    """
    if not (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")):
        alt = _optional_str("AURA_HTTPS_PROXY")
        if alt:
            os.environ["HTTPS_PROXY"] = alt
    if not (os.getenv("HTTP_PROXY") or os.getenv("http_proxy")):
        alt = _optional_str("AURA_HTTP_PROXY")
        if alt:
            os.environ["HTTP_PROXY"] = alt
    if not (os.getenv("NO_PROXY") or os.getenv("no_proxy")):
        alt = _optional_str("AURA_NO_PROXY")
        if alt:
            os.environ["NO_PROXY"] = alt


_ensure_standard_proxy_env_from_aura_aliases()

BOTO_HTTPS_PROXY_CONFIGURED: bool = bool(
    (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or "").strip()
)

# DynamoDB (optional): PutItem / GetItem / Query via /dynamodb/* when AURA_DYNAMODB_TABLE_NAME is set.
DYNAMODB_TABLE_NAME: str | None = _optional_str("AURA_DYNAMODB_TABLE_NAME")
DYNAMODB_REGION: str = (
    _optional_str("AURA_DYNAMODB_REGION")
    or _optional_str("AURA_S3_REGION")
    or _optional_str("AWS_DEFAULT_REGION")
    or "us-east-1"
).strip()

# Optional multi-table layout (used by workers / orchestration):
DYNAMODB_TABLE_REPOS: str | None = _optional_str("AURA_DYNAMODB_TABLE_REPOS")
DYNAMODB_TABLE_UPLOADS: str | None = _optional_str("AURA_DYNAMODB_TABLE_UPLOADS")
DYNAMODB_TABLE_JOBS: str | None = _optional_str("AURA_DYNAMODB_TABLE_JOBS")
DYNAMODB_TABLE_JOB_EVENTS: str | None = _optional_str("AURA_DYNAMODB_TABLE_JOB_EVENTS")

# Step Functions (optional; used when orchestration is enabled):
SFN_REGION: str = (_optional_str("AURA_SFN_REGION") or _optional_str("AWS_DEFAULT_REGION") or "us-east-1").strip()
SFN_STATE_MACHINE_INGEST_ARN: str | None = _optional_str("AURA_SFN_STATE_MACHINE_INGEST_ARN")
SFN_STATE_MACHINE_JOB_ARN: str | None = _optional_str("AURA_SFN_STATE_MACHINE_JOB_ARN")
SFN_STATE_MACHINE_INGEST_NAME: str | None = _optional_str("AURA_SFN_STATE_MACHINE_INGEST_NAME")
SFN_STATE_MACHINE_JOB_NAME: str | None = _optional_str("AURA_SFN_STATE_MACHINE_JOB_NAME")

# ECS/Lambda references (optional; used by ops/scripts or future orchestration wiring)
ECS_CLUSTER_NAME: str | None = _optional_str("AURA_ECS_CLUSTER_NAME")
ECS_TASK_DEFINITION: str | None = _optional_str("AURA_ECS_TASK_DEFINITION")
LAMBDA_TRIGGER_NAME: str | None = _optional_str("AURA_LAMBDA_TRIGGER_NAME")

# --- /v1 public API (LLM Suite AURA spec) ---
# When unset or "same", mirror AURA_REQUIRE_AUTH. Set to 0/1 to override independently.
_V1_AUTH_RAW: str = os.getenv("AURA_V1_REQUIRE_AUTH", "same").strip().lower()


def v1_require_auth_effective() -> bool:
    if _V1_AUTH_RAW in {"", "same"}:
        return REQUIRE_AUTH
    return _V1_AUTH_RAW in {"1", "true", "yes", "on"}


# Dev-only: decode IDA-shaped JWTs without signature verification (never enable in prod).
V1_IDA_UNVERIFIED_JWT: bool = _truthy("AURA_V1_IDA_UNVERIFIED_JWT")

# Resource audience string for IDA / app.state (internal pattern); optional.
IDA_RESOURCE_URI: str | None = _optional_str("AURA_IDA_RESOURCE_URI")


def ida_adfs_token_endpoint() -> str | None:
    """ADFS OAuth2 token URL for adfs_client_credentials / adfs_password (separate from C2C IDP)."""
    return ADFS_TOKEN_ENDPOINT


def ida_client_credentials_resource_uri() -> str | None:
    """Resource parameter for ADFS client_credentials (Role claims are issued for this resource)."""
    return (ADFS_RESOURCE_URI or IDA_RESOURCE_URI)


# Comma-separated claim keys to scan for RBAC role strings (IDA uses capital "Role" list — see token payload).
V1_ROLE_CLAIM_KEYS: tuple[str, ...] = tuple(
    k.strip()
    for k in os.getenv(
        "AURA_V1_ROLE_CLAIM_KEYS",
        "Role,roles,role,entitlements,groups,group",
    ).split(",")
    if k.strip()
)

# Optional admin role id (JPMC entitlement string) for destructive v1 actions; unset = no extra gate.
V1_ADMIN_ROLE: str | None = _optional_str("AURA_V1_ADMIN_ROLE")

V1_PRESIGN_EXPIRES_SECONDS: int = int(os.getenv("AURA_V1_PRESIGN_EXPIRES_SECONDS", "900"))

# POST /v1/analysis-jobs requires JPMCIdentifier/sub-derived user_id unless this is set (local only).
V1_ALLOW_JOB_WITHOUT_USER_ID: bool = _truthy("AURA_V1_ALLOW_JOB_WITHOUT_USER_ID")

# When unset, a failed PutItem to aura-jobs fails the request (503) before Step Functions starts.
V1_JOB_DYNAMO_BEST_EFFORT: bool = _truthy("AURA_V1_JOB_DYNAMO_BEST_EFFORT")

# If 1, repo/upload Dynamo errors are logged but requests still succeed (local dev without tables).
V1_DYNAMO_OPTIONAL: bool = _truthy("AURA_V1_DYNAMO_OPTIONAL")

# When env tables are unset, /v1 uses these AURA table names (override with AURA_DYNAMODB_TABLE_*).
V1_DYNAMODB_DEFAULT_REPOS: str = os.getenv("AURA_V1_DYNAMODB_DEFAULT_REPOS", "aura-repos").strip() or "aura-repos"
V1_DYNAMODB_DEFAULT_UPLOADS: str = os.getenv("AURA_V1_DYNAMODB_DEFAULT_UPLOADS", "aura-uploads").strip() or "aura-uploads"
V1_DYNAMODB_DEFAULT_JOBS: str = os.getenv("AURA_V1_DYNAMODB_DEFAULT_JOBS", "aura-jobs").strip() or "aura-jobs"


def v1_repos_table() -> str:
    return (DYNAMODB_TABLE_REPOS or V1_DYNAMODB_DEFAULT_REPOS).strip()


def v1_uploads_table() -> str:
    return (DYNAMODB_TABLE_UPLOADS or V1_DYNAMODB_DEFAULT_UPLOADS).strip()


def v1_jobs_table() -> str:
    return (DYNAMODB_TABLE_JOBS or DYNAMODB_TABLE_NAME or V1_DYNAMODB_DEFAULT_JOBS).strip()
