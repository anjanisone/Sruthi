from __future__ import annotations

import importlib
import uuid
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests

from . import settings


class C2CError(Exception):
    def __init__(self, message: str, *, http_status: Optional[int] = None, body: Any = None) -> None:
        super().__init__(message)
        self.http_status = http_status
        self.body = body


def tls_verify_for_adfs_requests() -> bool | str:
    """TLS `verify` argument for requests to ADFS / C2C token endpoints."""
    bundle = settings.C2C_SSL_CA_BUNDLE
    if bundle:
        return bundle
    if not settings.C2C_VERIFY_SSL:
        return False
    return True


# Backwards-compatible name
_c2c_verify_arg = tls_verify_for_adfs_requests


def _post_c2c_token_exchange(
    *,
    url: str,
    audience: str,
    subject_token: str,
    subject_token_type: str,
    client_request_id: str,
    auth: tuple[str, str] | None,
    timeout_seconds: int,
    verify: bool | str,
) -> requests.Response:
    """
    Same wire shape as:

        curl --location --request POST '<url>' \\
          --header 'Content-Type: application/x-www-form-urlencoded' \\
          --header 'x-client-request-id: <uuid>' \\
          --data-urlencode 'grant_type=...' \\
          --data-urlencode 'audience=...' \\
          ...

    Implemented with ``requests`` (form body as a single urlencoded string, not JSON).
    """
    form: dict[str, str] = {
        "grant_type": settings.C2C_GRANT_TYPE_TOKEN_EXCHANGE,
        "audience": audience,
        "requested_token_type": settings.C2C_REQUESTED_TOKEN_TYPE,
        "subject_token": subject_token,
        "subject_token_type": subject_token_type,
    }
    body = urlencode(form)
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-client-request-id": client_request_id,
    }
    return requests.post(
        url,
        data=body,
        headers=headers,
        auth=auth,
        timeout=timeout_seconds,
        verify=verify,
        allow_redirects=True,
    )


def _exchange_with_sdk(*, audience: str, subject_token: str, subject_token_type: str) -> Dict[str, Any]:
    """
    Optional integration point for `c2c-aws-idp-sdk`.

    Because the SDK is internal (not pip-installable in all environments), this function uses a configurable
    entrypoint to avoid hardcoding an API surface.

    Set:
    - AURA_C2C_USE_SDK=1
    - AURA_C2C_SDK_ENTRYPOINT="some_module:some_callable"

    The callable will be invoked as:
      fn(audience=..., subject_token=..., subject_token_type=..., token_endpoint=..., client_id=..., client_secret=...)
    and must return a dict containing at least `access_token`.
    """

    if not settings.C2C_SDK_ENTRYPOINT:
        raise C2CError(
            "AURA_C2C_USE_SDK=1 but AURA_C2C_SDK_ENTRYPOINT is not set (expected 'module:callable')."
        )

    if ":" not in settings.C2C_SDK_ENTRYPOINT:
        raise C2CError("AURA_C2C_SDK_ENTRYPOINT must be in the form 'module:callable'.")
    mod_name, fn_name = settings.C2C_SDK_ENTRYPOINT.split(":", 1)
    try:
        mod = importlib.import_module(mod_name)
    except Exception as exc:
        raise C2CError(f"Could not import SDK entrypoint module {mod_name!r}: {exc}") from exc
    fn = getattr(mod, fn_name, None)
    if not callable(fn):
        raise C2CError(f"SDK entrypoint {settings.C2C_SDK_ENTRYPOINT!r} is not callable.")

    try:
        body = fn(
            audience=audience,
            subject_token=subject_token,
            subject_token_type=subject_token_type,
            token_endpoint=settings.C2C_TOKEN_ENDPOINT,
            client_id=settings.C2C_CLIENT_ID,
            client_secret=settings.C2C_CLIENT_SECRET,
        )
    except Exception as exc:
        raise C2CError(f"C2C SDK call failed: {exc}") from exc

    if not isinstance(body, dict) or "access_token" not in body:
        raise C2CError("C2C SDK response missing access_token.", http_status=502, body=body)
    return body


def exchange_with_c2c(*, audience: str, subject_token: str, subject_token_type: str) -> Dict[str, Any]:
    endpoint = settings.C2C_TOKEN_ENDPOINT

    if settings.C2C_USE_SDK:
        return _exchange_with_sdk(audience=audience, subject_token=subject_token, subject_token_type=subject_token_type)

    client_request_id = str(uuid.uuid4())
    auth: tuple[str, str] | None = None
    if settings.C2C_CLIENT_SECRET:
        if not settings.C2C_CLIENT_ID:
            raise C2CError("AURA_C2C_CLIENT_ID is required when AURA_C2C_CLIENT_SECRET is set.")
        auth = (settings.C2C_CLIENT_ID, settings.C2C_CLIENT_SECRET)

    try:
        resp = _post_c2c_token_exchange(
            url=endpoint,
            audience=audience,
            subject_token=subject_token,
            subject_token_type=subject_token_type,
            client_request_id=client_request_id,
            auth=auth,
            timeout_seconds=settings.C2C_TIMEOUT_SECONDS,
            verify=_c2c_verify_arg(),
        )
    except requests.RequestException as exc:
        raise C2CError(f"C2C request failed: {exc}") from exc

    try:
        body = resp.json()
    except ValueError as exc:
        raise C2CError(
            f"C2C returned non-JSON (HTTP {resp.status_code}).",
            http_status=resp.status_code,
            body=resp.text[:2000],
        ) from exc

    if resp.status_code >= 400:
        msg = body.get("error_description") or body.get("error") or resp.reason or "C2C error"
        raise C2CError(str(msg), http_status=resp.status_code, body=body)

    if isinstance(body, dict) and body.get("error"):
        msg = body.get("error_description") or body.get("error") or "C2C error"
        raise C2CError(str(msg), http_status=resp.status_code or 400, body=body)

    if not isinstance(body, dict) or "access_token" not in body:
        raise C2CError("C2C response missing access_token.", http_status=502, body=body)

    return body
