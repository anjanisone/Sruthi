#!/usr/bin/env python3
"""
2026-04-29 — Validate .env in this folder against C2C IDP contract from screenshots:
  POST {AURA_C2C_TOKEN_ENDPOINT}
  Content-Type: application/x-www-form-urlencoded
  x-client-request-id: <uuid> (runtime; not in .env)
  Body fields: grant_type, audience, requested_token_type, subject_token, subject_token_type
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

# Expected literals from provided curl / runbook screenshots
EXPECTED = {
    "AURA_C2C_TOKEN_ENDPOINT": "https://idp.us-east-1.prod.aws.jpmchase.net/token",
    "AURA_C2C_IDA_ADFS_AUDIENCE": "https://idag2.jpmorganchase.com/adfs/oauth2/token/",
    "AURA_C2C_REQUESTED_TOKEN_TYPE": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
    "AURA_C2C_CLIENT_ID": "c2c:aws:588866471920:app-aura-api-role",
    "AURA_ADFS_TOKEN_ENDPOINT": "https://idag2.jpmorganchase.com/adfs/oauth2/token",
    "AURA_GCI_SUBJECT_TOKEN_AUDIENCE": "https://idp.prod.aws.jpmchase.net",
}

RFC8693_GRANT = "urn:ietf:params:oauth:grant-type:token-exchange"
SUBJECT_TOKEN_TYPE = "urn:jpmc:params:identity:token-type:aws-get-caller-identity"


def main() -> int:
    errors: list[str] = []
    for key, expected in EXPECTED.items():
        got = (os.getenv(key) or "").strip()
        if not got:
            errors.append(f"missing or empty: {key}")
            continue
        if got != expected:
            errors.append(f"{key}: expected {expected!r}, got {got!r}")

    # Document-only checks (must match app hardcodes / curl)
    print("RFC8693 grant_type (app hardcode / curl):", RFC8693_GRANT)
    print("subject_token_type (request payload / curl):", SUBJECT_TOKEN_TYPE)

    if errors:
        print("VALIDATION FAILED:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1

    print("OK: .env values match screenshot requirements for:")
    for k in EXPECTED:
        print(f"  - {k}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
