from __future__ import annotations

import os
from pathlib import Path
from typing import FrozenSet

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _truthy(name: str, default: str = "") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


JWT_SECRET: str = os.getenv(
    "AURA_JWT_SECRET",
    "dev-only-change-me-please-use-AURA_JWT_SECRET-in-real-envs",
)
JWT_ALGORITHM: str = os.getenv("AURA_JWT_ALGORITHM", "HS256")
JWT_EXPIRES_SECONDS: int = int(os.getenv("AURA_JWT_EXPIRES_SECONDS", "3600"))

REQUIRE_AUTH: bool = _truthy("AURA_REQUIRE_AUTH")

# When true, /docs serves a small HTML page with no CDN (Swagger UI JS is blocked on many corporate networks).
DOCS_CDN_OFFLINE: bool = _truthy("AURA_DOCS_CDN_OFFLINE")

# Parity with FastAPI: browser-side Swagger would use these if you add a hosted bundle later.
SWAGGER_UI_DIST_CDN: str = os.getenv(
    "AURA_SWAGGER_UI_DIST_CDN",
    "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5",
).strip().rstrip("/")
REDOC_STANDALONE_JS: str = os.getenv(
    "AURA_REDOC_STANDALONE_JS",
    "https://cdn.jsdelivr.net/npm/redoc/bundles/redoc.standalone.js",
).strip()

CLIENT_ID: str = os.getenv("AURA_CLIENT_ID", "aura-demo-client")
CLIENT_SECRET: str = os.getenv("AURA_CLIENT_SECRET", "aura-demo-secret")

AWS_GET_CALLER_IDENTITY_TOKEN_TYPES: FrozenSet[str] = frozenset(
    {
        "urn:jpmc:params:identity:token-type:aws-get-caller-identity",
        "urn:aura:params:identity:token-type:aws-get-caller-identity",
    }
)

STS_POST_BODY_DEFAULT: str = "Action=GetCallerIdentity&Version=2011-06-15"


def _optional_str(name: str) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    stripped = raw.strip()
    return stripped or None


C2C_TOKEN_ENDPOINT: str | None = _optional_str("AURA_C2C_TOKEN_ENDPOINT")
ADFS_TOKEN_ENDPOINT: str | None = _optional_str("AURA_ADFS_TOKEN_ENDPOINT")
ADFS_RESOURCE_URI: str | None = _optional_str("AURA_ADFS_RESOURCE_URI")
C2C_CLIENT_ID: str | None = _optional_str("AURA_C2C_CLIENT_ID")
C2C_CLIENT_SECRET: str | None = _optional_str("AURA_C2C_CLIENT_SECRET")
C2C_USE_SDK: bool = _truthy("AURA_C2C_USE_SDK")
C2C_SDK_ENTRYPOINT: str | None = _optional_str("AURA_C2C_SDK_ENTRYPOINT")
C2C_REQUESTED_TOKEN_TYPE: str = os.getenv(
    "AURA_C2C_REQUESTED_TOKEN_TYPE",
    "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
)
C2C_TIMEOUT_SECONDS: int = int(os.getenv("AURA_C2C_TIMEOUT_SECONDS", "45"))
C2C_VERIFY_SSL: bool = not _truthy("AURA_C2C_INSECURE_SKIP_TLS_VERIFY")
C2C_SSL_CA_BUNDLE: str | None = _optional_str("AURA_C2C_SSL_CA_BUNDLE")

ADFS_HTTP_TIMEOUT_SECONDS: int = int(os.getenv("AURA_ADFS_HTTP_TIMEOUT_SECONDS", "45"))

TOKEN_EXCHANGE_MODE: str = os.getenv("AURA_TOKEN_EXCHANGE_MODE", "local").strip().lower()

ALLOW_GCI_SUBJECT_TOKEN_BUILDER: bool = _truthy("AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER")

ALLOW_GCI_BUILDER_AWS_CLI_CREDS: bool = _truthy("AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS", "true")

# Server-side zip upload to S3 (PutObject / managed multipart inside boto3).
S3_BUCKET: str | None = _optional_str("AURA_S3_BUCKET")
S3_REGION: str = (
    (_optional_str("AURA_S3_REGION") or _optional_str("AWS_DEFAULT_REGION") or "us-east-1").strip()
)
S3_UPLOAD_PREFIX: str = os.getenv("AURA_S3_UPLOAD_PREFIX", "jobs").strip().strip("/") or "jobs"
S3_MAX_FILE_SIZE_BYTES: int = int(os.getenv("AURA_S3_MAX_FILE_SIZE_BYTES", "524288000"))
S3_MAX_EXTRACTED_TOTAL_BYTES: int = int(os.getenv("AURA_S3_MAX_EXTRACTED_TOTAL_BYTES", str(10 * 1024 * 1024 * 1024)))
S3_MAX_EXTRACT_FILES: int = int(os.getenv("AURA_S3_MAX_EXTRACT_FILES", "20000"))
GIT_CLONE_TIMEOUT_SECONDS: int = int(os.getenv("AURA_GIT_CLONE_TIMEOUT_SECONDS", "900"))
UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS: int = int(os.getenv("AURA_UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS", "3600"))

# POST /upload-zip/file: avoid "infinite loading" when the client or S3 stalls (common on Windows / proxies / AV).
UPLOAD_READ_CHUNK_TIMEOUT_SECONDS: float = float(os.getenv("AURA_UPLOAD_READ_CHUNK_TIMEOUT_SECONDS", "300"))
UPLOAD_S3_PUT_TIMEOUT_SECONDS: float = float(os.getenv("AURA_UPLOAD_S3_PUT_TIMEOUT_SECONDS", "7200"))

# boto3 S3 client (see app/upload/s3_presign.py).
S3_CONNECT_TIMEOUT_SECONDS: int = max(1, int(os.getenv("AURA_S3_CONNECT_TIMEOUT_SECONDS", "15")))
S3_READ_TIMEOUT_SECONDS: int = max(1, int(os.getenv("AURA_S3_READ_TIMEOUT_SECONDS", "600")))
BOTO_PROXY_USE_FORWARDING_HTTPS: bool = _truthy("AURA_BOTO_PROXY_USE_FORWARDING_HTTPS")


def _ensure_standard_proxy_env_from_aura_aliases() -> None:
    """
    boto3/urllib3 read HTTP_PROXY, HTTPS_PROXY, NO_PROXY. If those are unset, copy from
    AURA_HTTP_PROXY / AURA_HTTPS_PROXY / AURA_NO_PROXY so one .env style works everywhere.
    """
    if not (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")):
        alt = _optional_str("AURA_HTTPS_PROXY")
        if alt:
            os.environ["HTTPS_PROXY"] = alt
    if not (os.getenv("HTTP_PROXY") or os.getenv("http_proxy")):
        alt = _optional_str("AURA_HTTP_PROXY")
        if alt:
            os.environ["HTTP_PROXY"] = alt
    if not (os.getenv("NO_PROXY") or os.getenv("no_proxy")):
        alt = _optional_str("AURA_NO_PROXY")
        if alt:
            os.environ["NO_PROXY"] = alt


_ensure_standard_proxy_env_from_aura_aliases()


def _ensure_aws_profile_from_aura_alias() -> None:
    """
    Prefer credentials from a named `aws` CLI profile (SSO, assumed roles, etc.). If
    `AWS_PROFILE` is unset, copy from AURA_AWS_PROFILE so one .env line works.
    """
    if not (os.getenv("AWS_PROFILE") or os.getenv("AWS_DEFAULT_PROFILE")):
        alt = _optional_str("AURA_AWS_PROFILE")
        if alt:
            os.environ["AWS_PROFILE"] = alt


_ensure_aws_profile_from_aura_alias()

BOTO_HTTPS_PROXY_CONFIGURED: bool = bool(
    (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or "").strip()
)

DYNAMODB_TABLE_NAME: str | None = _optional_str("AURA_DYNAMODB_TABLE_NAME")
DYNAMODB_REGION: str = (
    _optional_str("AURA_DYNAMODB_REGION")
    or _optional_str("AURA_S3_REGION")
    or _optional_str("AWS_DEFAULT_REGION")
    or "us-east-1"
).strip()

# Optional multi-table layout (used by workers / orchestration):
DYNAMODB_TABLE_REPOS: str | None = _optional_str("AURA_DYNAMODB_TABLE_REPOS")
DYNAMODB_TABLE_UPLOADS: str | None = _optional_str("AURA_DYNAMODB_TABLE_UPLOADS")
DYNAMODB_TABLE_JOBS: str | None = _optional_str("AURA_DYNAMODB_TABLE_JOBS")
DYNAMODB_TABLE_JOB_EVENTS: str | None = _optional_str("AURA_DYNAMODB_TABLE_JOB_EVENTS")

# Step Functions (optional; used when orchestration is enabled):
SFN_REGION: str = (_optional_str("AURA_SFN_REGION") or _optional_str("AWS_DEFAULT_REGION") or "us-east-1").strip()
SFN_STATE_MACHINE_INGEST_ARN: str | None = _optional_str("AURA_SFN_STATE_MACHINE_INGEST_ARN")
SFN_STATE_MACHINE_JOB_ARN: str | None = _optional_str("AURA_SFN_STATE_MACHINE_JOB_ARN")
SFN_STATE_MACHINE_INGEST_NAME: str | None = _optional_str("AURA_SFN_STATE_MACHINE_INGEST_NAME")
SFN_STATE_MACHINE_JOB_NAME: str | None = _optional_str("AURA_SFN_STATE_MACHINE_JOB_NAME")

# ECS/Lambda references (optional; used by ops/scripts or future orchestration wiring)
ECS_CLUSTER_NAME: str | None = _optional_str("AURA_ECS_CLUSTER_NAME")
ECS_TASK_DEFINITION: str | None = _optional_str("AURA_ECS_TASK_DEFINITION")
LAMBDA_TRIGGER_NAME: str | None = _optional_str("AURA_LAMBDA_TRIGGER_NAME")

# GitHub (optional): fine-grained or classic PAT for api.github.com (see GET /github/connection).
GITHUB_TOKEN: str | None = _optional_str("AURA_GITHUB_TOKEN") or _optional_str("GITHUB_TOKEN")

# Non-secret flags for /meta
AWS_PROFILE_RESOLVED: str | None = _optional_str("AWS_PROFILE") or _optional_str("AWS_DEFAULT_PROFILE") or _optional_str(
    "AURA_AWS_PROFILE"
)
GITHUB_TOKEN_CONFIGURED: bool = bool(GITHUB_TOKEN)

IDA_RESOURCE_URI: str | None = _optional_str("AURA_IDA_RESOURCE_URI")


def ida_adfs_token_endpoint() -> str | None:
    return (ADFS_TOKEN_ENDPOINT or C2C_TOKEN_ENDPOINT)


def ida_client_credentials_resource_uri() -> str | None:
    return (ADFS_RESOURCE_URI or IDA_RESOURCE_URI)
