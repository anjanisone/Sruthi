from __future__ import annotations

import base64
import json
import xml.etree.ElementTree as ET
from typing import Any, Dict, Tuple
from urllib.parse import urlparse

import requests

from . import settings


class GciValidationError(Exception):
    pass


def _is_allowed_sts_https_url(uri: str) -> bool:
    try:
        parsed = urlparse(uri)
    except Exception:
        return False
    if parsed.scheme != "https":
        return False
    host = (parsed.hostname or "").lower()
    if host == "sts.amazonaws.com":
        return True
    return host.startswith("sts.") and host.endswith(".amazonaws.com")


def _flatten_headers(raw: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for name, value in raw.items():
        if isinstance(value, list):
            if not value:
                raise GciValidationError(f"Header {name!r} is empty.")
            out[name] = str(value[0])
        else:
            out[name] = str(value)
    return out


def verify_aws_get_caller_identity_subject_token(subject_token: str) -> Dict[str, str]:
    try:
        decoded = base64.b64decode(subject_token, validate=True)
        doc = json.loads(decoded.decode("utf-8"))
    except (ValueError, json.JSONDecodeError, UnicodeError) as exc:
        raise GciValidationError("subject_token is not valid base64 JSON.") from exc

    if not isinstance(doc, dict):
        raise GciValidationError("subject_token JSON must be an object.")

    uri = doc.get("uri")
    if not isinstance(uri, str) or not uri:
        raise GciValidationError('subject_token JSON must include string "uri".')
    if not _is_allowed_sts_https_url(uri):
        raise GciValidationError("uri must be an https STS endpoint on amazonaws.com.")

    raw_headers = doc.get("headers")
    if not isinstance(raw_headers, dict):
        raise GciValidationError('subject_token JSON must include object "headers".')

    headers = _flatten_headers(raw_headers)
    body = doc.get("body")
    if body is None:
        body = settings.STS_POST_BODY_DEFAULT
    elif not isinstance(body, str):
        raise GciValidationError('"body", if present, must be a string.')

    try:
        resp = requests.post(uri, data=body.encode("utf-8"), headers=headers, timeout=15)
    except requests.RequestException as exc:
        raise GciValidationError(f"STS request failed: {exc}") from exc

    if resp.status_code != 200:
        raise GciValidationError(f"STS returned HTTP {resp.status_code}.")

    identity = _parse_get_caller_identity_xml(resp.text)
    if not identity.get("arn"):
        raise GciValidationError("STS response did not include an ARN.")
    return identity


def _parse_get_caller_identity_xml(xml_text: str) -> Dict[str, str]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise GciValidationError("STS response was not valid XML.") from exc

    result_el = None
    for el in root.iter():
        if el.tag.split("}")[-1] == "GetCallerIdentityResult":
            result_el = el
            break
    if result_el is None:
        raise GciValidationError("STS XML missing GetCallerIdentityResult.")

    out: Dict[str, str] = {}
    for el in result_el.iter():
        name = el.tag.split("}")[-1]
        if name in {"Arn", "UserId", "Account"} and el.text:
            key = "arn" if name == "Arn" else "user_id" if name == "UserId" else "account"
            out[key] = el.text.strip()
    return out


def claims_from_sts_identity(identity: Dict[str, str], *, audience: str) -> Tuple[Dict[str, Any], str]:
    sub = identity.get("user_id") or identity.get("arn") or "unknown"
    claims: Dict[str, Any] = {
        "sub": sub,
        "aud": audience,
        "aws_arn": identity.get("arn"),
        "aws_account": identity.get("account"),
        "aws_user_id": identity.get("user_id"),
        "auth_method": "aws_get_caller_identity",
    }
    scope = "read write"
    return claims, scope
