from __future__ import annotations

from typing import Any, Dict, Literal, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from starlette.requests import Request

from . import sfn

router = APIRouter(prefix="/stepfunctions", tags=["stepfunctions"])


class StartExecutionRequest(BaseModel):
    kind: Optional[Literal["ingest", "job"]] = Field(
        default=None, description="Select configured ARN (AURA_SFN_STATE_MACHINE_*_ARN)."
    )
    state_machine_arn: Optional[str] = Field(
        default=None, description="Override ARN; if set, kind is ignored."
    )
    name: Optional[str] = Field(default=None, description="Optional execution name (must be unique per state machine).")
    input: Dict[str, Any] = Field(default_factory=dict, description="JSON input for the state machine.")


class StartExecutionResponse(BaseModel):
    execution_arn: str | None = None
    state_machine_arn: str | None = None
    start_date: Any | None = None


class StopExecutionRequest(BaseModel):
    execution_arn: str
    error: Optional[str] = None
    cause: Optional[str] = None


class StopExecutionResponse(BaseModel):
    stop_date: Any | None = None


class DescribeExecutionResponse(BaseModel):
    execution_arn: str | None = None
    state_machine_arn: str | None = None
    name: str | None = None
    status: str | None = None
    start_date: Any | None = None
    stop_date: Any | None = None
    input: str | None = None
    output: str | None = None
    error: str | None = None
    cause: str | None = None


class ExecutionHistoryResponse(BaseModel):
    events: list[dict[str, Any]] = Field(default_factory=list)
    next_token: str | None = None


@router.post("/executions/start", response_model=StartExecutionResponse, summary="Start a Step Functions execution")
def start_execution(request: Request, payload: StartExecutionRequest) -> StartExecutionResponse:
    user_id = getattr(request.state, "user_id", None)
    try:
        resp = sfn.start_execution(
            kind=payload.kind,
            state_machine_arn=payload.state_machine_arn,
            name=payload.name,
            input_obj=payload.input,
            user_id=user_id,
        )
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        raise HTTPException(status_code=code, detail=detail) from exc
    return StartExecutionResponse(
        execution_arn=resp.get("executionArn"),
        state_machine_arn=resp.get("stateMachineArn"),
        start_date=resp.get("startDate"),
    )


@router.post("/executions/stop", response_model=StopExecutionResponse, summary="Stop a Step Functions execution")
def stop_execution(payload: StopExecutionRequest) -> StopExecutionResponse:
    try:
        resp = sfn.stop_execution(execution_arn=payload.execution_arn, error=payload.error, cause=payload.cause)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        raise HTTPException(status_code=code, detail=detail) from exc
    return StopExecutionResponse(stop_date=resp.get("stopDate"))


@router.get(
    "/executions/describe",
    response_model=DescribeExecutionResponse,
    summary="Get execution state + input/output (DescribeExecution)",
)
def describe_execution(execution_arn: str) -> DescribeExecutionResponse:
    try:
        d = sfn.describe_execution(execution_arn=execution_arn)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        raise HTTPException(status_code=code, detail=detail) from exc
    return DescribeExecutionResponse(
        execution_arn=d.get("executionArn"),
        state_machine_arn=d.get("stateMachineArn"),
        name=d.get("name"),
        status=d.get("status"),
        start_date=d.get("startDate"),
        stop_date=d.get("stopDate"),
        input=d.get("input"),
        output=d.get("output"),
        error=d.get("error"),
        cause=d.get("cause"),
    )


@router.get(
    "/executions/result",
    response_model=DescribeExecutionResponse,
    summary="Get execution result (output/error/cause) + status",
)
def execution_result(execution_arn: str) -> DescribeExecutionResponse:
    # Same as describe; kept as a convenience name.
    return describe_execution(execution_arn=execution_arn)


@router.get(
    "/executions/history",
    response_model=ExecutionHistoryResponse,
    summary="Get execution history events (GetExecutionHistory)",
)
def get_execution_history(execution_arn: str, max_results: int = 1000, reverse_order: bool = False) -> ExecutionHistoryResponse:
    try:
        h = sfn.execution_history(execution_arn=execution_arn, max_results=max_results, reverse_order=reverse_order)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        raise HTTPException(status_code=code, detail=detail) from exc
    return ExecutionHistoryResponse(events=list(h.get("events", [])), next_token=h.get("nextToken"))

