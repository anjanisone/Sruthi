from __future__ import annotations

import json
from typing import Any, Dict, Tuple

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from .. import settings


def _client():
    return boto3.client("stepfunctions", region_name=settings.SFN_REGION)


def _resolve_state_machine_arn_by_name(name: str) -> str | None:
    """
    Resolve a state machine ARN by name via ListStateMachines.
    This avoids needing account-id to construct an ARN when only the name is known.
    """
    target = (name or "").strip()
    if not target:
        return None
    client = _client()
    next_token: str | None = None
    while True:
        kwargs: Dict[str, Any] = {"maxResults": 1000}
        if next_token:
            kwargs["nextToken"] = next_token
        resp = client.list_state_machines(**kwargs)
        for sm in resp.get("stateMachines", []) or []:
            if sm.get("name") == target and sm.get("stateMachineArn"):
                return str(sm["stateMachineArn"])
        next_token = resp.get("nextToken")
        if not next_token:
            return None


def _require_arn(kind: str | None, state_machine_arn: str | None) -> str:
    if state_machine_arn:
        return state_machine_arn
    k = (kind or "").strip().lower()
    if k in {"ingest", "ingestion"} and settings.SFN_STATE_MACHINE_INGEST_ARN:
        return settings.SFN_STATE_MACHINE_INGEST_ARN
    if k in {"job", "jobs"} and settings.SFN_STATE_MACHINE_JOB_ARN:
        return settings.SFN_STATE_MACHINE_JOB_ARN
    if k in {"ingest", "ingestion"} and settings.SFN_STATE_MACHINE_INGEST_NAME:
        arn = _resolve_state_machine_arn_by_name(settings.SFN_STATE_MACHINE_INGEST_NAME)
        if arn:
            return arn
    if k in {"job", "jobs"} and settings.SFN_STATE_MACHINE_JOB_NAME:
        arn = _resolve_state_machine_arn_by_name(settings.SFN_STATE_MACHINE_JOB_NAME)
        if arn:
            return arn
    raise ValueError(
        "Step Functions is not configured. Set AURA_SFN_STATE_MACHINE_INGEST_ARN/AURA_SFN_STATE_MACHINE_JOB_ARN "
        "(or AURA_SFN_STATE_MACHINE_INGEST_NAME/AURA_SFN_STATE_MACHINE_JOB_NAME), or pass state_machine_arn explicitly."
    )


def start_execution(
    *,
    kind: str | None,
    state_machine_arn: str | None,
    name: str | None,
    input_obj: Dict[str, Any],
    user_id: str | None,
) -> Dict[str, Any]:
    arn = _require_arn(kind, state_machine_arn)
    payload = dict(input_obj or {})
    if user_id and "user_id" not in payload:
        payload["user_id"] = user_id
    kwargs: Dict[str, Any] = {"stateMachineArn": arn, "input": json.dumps(payload, default=str)}
    if name:
        kwargs["name"] = name
    resp = _client().start_execution(**kwargs)
    return {
        "executionArn": resp.get("executionArn"),
        "startDate": resp.get("startDate"),
        "stateMachineArn": arn,
    }


def stop_execution(*, execution_arn: str, error: str | None, cause: str | None) -> Dict[str, Any]:
    kwargs: Dict[str, Any] = {"executionArn": execution_arn}
    if error:
        kwargs["error"] = error
    if cause:
        kwargs["cause"] = cause
    resp = _client().stop_execution(**kwargs)
    return {
        "stopDate": resp.get("stopDate"),
    }


def describe_execution(*, execution_arn: str) -> Dict[str, Any]:
    resp = _client().describe_execution(executionArn=execution_arn)
    return {
        "executionArn": resp.get("executionArn"),
        "stateMachineArn": resp.get("stateMachineArn"),
        "name": resp.get("name"),
        "status": resp.get("status"),
        "startDate": resp.get("startDate"),
        "stopDate": resp.get("stopDate"),
        "input": resp.get("input"),
        "output": resp.get("output"),
        "error": resp.get("error"),
        "cause": resp.get("cause"),
        "traceHeader": resp.get("traceHeader"),
    }


def execution_history(*, execution_arn: str, max_results: int = 1000, reverse_order: bool = False) -> Dict[str, Any]:
    resp = _client().get_execution_history(
        executionArn=execution_arn,
        maxResults=max(1, min(int(max_results), 1000)),
        reverseOrder=bool(reverse_order),
    )
    return {
        "events": resp.get("events", []),
        "nextToken": resp.get("nextToken"),
    }


def translate_error(exc: Exception) -> Tuple[int, str]:
    if isinstance(exc, ValueError):
        return 503, str(exc)
    if isinstance(exc, ClientError):
        code = (exc.response.get("Error", {}) or {}).get("Code") or "ClientError"
        msg = (exc.response.get("Error", {}) or {}).get("Message") or str(exc)
        # common auth / missing resource
        if code in {"AccessDeniedException"}:
            return 403, msg
        if code in {"ExecutionDoesNotExist", "StateMachineDoesNotExist"}:
            return 404, msg
        if code in {"InvalidArn", "InvalidName", "InvalidExecutionInput", "ValidationException"}:
            return 400, msg
        return 503, f"{code}: {msg}"
    if isinstance(exc, BotoCoreError):
        return 503, f"AWS request failed: {exc}"
    return 500, str(exc)

