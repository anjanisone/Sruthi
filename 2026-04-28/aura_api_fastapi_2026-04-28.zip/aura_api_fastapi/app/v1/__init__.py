"""Versioned public API surface (LLM Suite / AURA v1 spec)."""
