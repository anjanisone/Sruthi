from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict


@dataclass
class V1State:
    repos: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    uploads: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    analysis_jobs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    publish: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def touch_repo(self, repo_id: str) -> Dict[str, Any]:
        if repo_id not in self.repos:
            self.repos[repo_id] = {
                "repo_id": repo_id,
                "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "versions": [],
                "tree": {"": [{"name": "src", "path": "src/", "type": "directory"}]},
            }
        return self.repos[repo_id]


V1_STATE = V1State()
