from __future__ import annotations

import logging
import re
from typing import Any

from ..stepfunctions.sfn import describe_execution, execution_history

logger = logging.getLogger(__name__)

# --- Job record status (DynamoDB / API) — aligns with LLM Suite pipeline docs ---
STATUS_SUBMITTED = "SUBMITTED"
STATUS_QUEUED = "queued"
STATUS_ANALYSING = "ANALYSING"
STATUS_COMPLETED = "COMPLETED"
STATUS_FAILED = "FAILED"
STATUS_CANCELLED = "CANCELLED"

# --- Six main analysis phases (Step Functions workers update Dynamo between phases) ---
# Phase 4b (oversized files) is tracked as analysis_phase=4 + sub_phase="4b".
PIPELINE_PHASES: dict[int, dict[str, str]] = {
    1: {
        "key": "STATIC_ANALYSIS",
        "title": "Phase 1: Static Analysis",
        "output": "project_metadata.json → S3",
    },
    2: {
        "key": "DEPENDENCY_GRAPH",
        "title": "Phase 2: Dependency Graph",
        "output": "dependency_graph.json → S3",
    },
    3: {
        "key": "INTELLIGENT_CHUNKING",
        "title": "Phase 3: Intelligent Chunking",
        "output": "chunks.json → S3",
    },
    4: {
        "key": "AI_PROCESSING",
        "title": "Phase 4: AI Processing (3 agents + Bedrock)",
        "output": "cached results → S3; status in DynamoDB",
    },
    5: {
        "key": "SPEC_ASSEMBLY",
        "title": "Phase 5: Spec Assembly",
        "output": "RAG-optimized markdown → S3",
    },
    6: {
        "key": "DOCUMENT_GENERATION",
        "title": "Phase 6: Document Generation (PDF, HTML, TXT)",
        "output": "S3; DynamoDB → COMPLETED",
    },
}

SUB_PHASE_OVERSIZED = "4b"


def pipeline_phase_info(analysis_phase: int, sub_phase: str | None = None) -> dict[str, Any]:
    """Structured phase info for GET /v1/analysis-jobs/{id} and OpenAPI consumers."""
    n = max(0, min(6, int(analysis_phase or 0)))
    meta = PIPELINE_PHASES.get(n) if n else None
    out: dict[str, Any] = {
        "analysis_phase": n,
        "sub_phase": (sub_phase if n == 4 else None),
        "key": meta["key"] if meta else None,
        "title": meta["title"] if meta else None,
        "expected_output": meta["output"] if meta else None,
    }
    if n == 0:
        out["title"] = out["title"] or "Awaiting analysis (no pipeline phase yet)"
    if n == 4 and sub_phase == SUB_PHASE_OVERSIZED:
        out["title"] = "Phase 4b: Oversized File Handling"
        out["key"] = "OVERSIZED_FILE_HANDLING"
    return out


def phase_label(analysis_phase: int, sub_phase: str | None = None) -> str:
    """Short `phase` string stored on the job row (compat with older clients)."""
    info = pipeline_phase_info(analysis_phase, sub_phase)
    if info.get("key"):
        if info.get("sub_phase") == SUB_PHASE_OVERSIZED:
            return "PHASE_4B"
        return str(info["key"])
    if analysis_phase <= 0:
        return ""
    return f"PHASE_{analysis_phase}"


def normalize_job_fields(job: dict[str, Any]) -> None:
    if "analysis_phase" not in job or job["analysis_phase"] is None:
        job["analysis_phase"] = 0
    else:
        try:
            from decimal import Decimal

            raw = job["analysis_phase"]
            if isinstance(raw, Decimal):
                job["analysis_phase"] = int(raw)
            else:
                job["analysis_phase"] = int(raw)
        except (TypeError, ValueError):
            job["analysis_phase"] = 0
    job["analysis_phase"] = max(0, min(6, int(job["analysis_phase"])))
    sp = job.get("sub_phase")
    job["sub_phase"] = (str(sp).strip() if sp is not None else "") or None
    if job["sub_phase"] == "":
        job["sub_phase"] = None


def apply_pipeline_labels(job: dict[str, Any]) -> None:
    """Attach `pipeline` summary for API responses."""
    normalize_job_fields(job)
    job["pipeline"] = pipeline_phase_info(int(job["analysis_phase"]), job.get("sub_phase"))


def infer_sub_phase_from_history(events: list[dict[str, Any]]) -> str | None:
    for ev in events:
        details = ev.get("stateEnteredEventDetails") or {}
        name = str(details.get("name") or "")
        if re.search(r"(4b|Oversized|OVERSIZED|LargeFile)", name, re.I):
            return SUB_PHASE_OVERSIZED
    return None


def infer_analysis_phase_from_history(events: list[dict[str, Any]]) -> tuple[int, str | None]:
    """
    Best-effort: map Step Functions state names to pipeline phase 1–6 and optional 4b.
    Name states in ASL with clear tokens (e.g. ``Phase2DependencyGraph``) for reliable mapping.
    """
    best = 0
    sub: str | None = None
    for ev in events:
        details = ev.get("stateEnteredEventDetails") or {}
        name = str(details.get("name") or "")
        if re.search(r"(4b|Oversized|OVERSIZED|LargeFile)", name, re.I):
            sub = SUB_PHASE_OVERSIZED
        if re.search(r"(StaticAnalysis|Static[_\s]?Analysis|Phase[_\s]?1\b)", name, re.I):
            best = max(best, 1)
        if re.search(r"(Dependency|DepGraph|Phase[_\s]?2\b)", name, re.I):
            best = max(best, 2)
        if re.search(r"(Chunk|Phase[_\s]?3\b)", name, re.I):
            best = max(best, 3)
        if re.search(
            r"(Bedrock|TechSpec|CodeAnnotat|SpecGeneratOrch|Phase[_\s]?4\b|AI[_\s]?Process)", name, re.I
        ):
            best = max(best, 4)
        if re.search(r"(SpecAssembly|Phase[_\s]?5\b)", name, re.I):
            best = max(best, 5)
        if re.search(r"(DocumentGener|Phase[_\s]?6\b)", name, re.I):
            best = max(best, 6)
    if best == 0:
        best = 1
    return min(6, best), sub


def sync_job_from_step_functions(job: dict[str, Any]) -> bool:
    """
    Refresh status, analysis_phase (1–6), and optional sub_phase from Step Functions.
    Returns True if job dict was mutated.
    """
    normalize_job_fields(job)
    arn = job.get("execution_arn")
    if not arn:
        return False
    terminal = {STATUS_COMPLETED, STATUS_FAILED, STATUS_CANCELLED, "cancelled"}
    if job.get("status") in terminal:
        return False
    try:
        desc = describe_execution(execution_arn=arn)
    except Exception as exc:
        logger.debug("v1: describe_execution skipped: %s", exc)
        return False

    st = str(desc.get("status") or "")
    changed = False

    if st == "RUNNING":
        try:
            hist = execution_history(execution_arn=arn, max_results=500, reverse_order=False)
            events = list(hist.get("events") or [])
            inferred, sub = infer_analysis_phase_from_history(events)
            sub_hist = infer_sub_phase_from_history(events)
            sub = sub or sub_hist
            ap = max(int(job.get("analysis_phase") or 0), inferred, 1)
            ap = min(6, ap)
            cur_sub = job.get("sub_phase")
            if (
                job.get("status") != STATUS_ANALYSING
                or int(job.get("analysis_phase") or 0) != ap
                or cur_sub != sub
            ):
                job["status"] = STATUS_ANALYSING
                job["analysis_phase"] = ap
                job["sub_phase"] = sub
                job["phase"] = phase_label(ap, sub)
                changed = True
        except Exception as exc:
            logger.debug("v1: execution_history skipped: %s", exc)
            ap = max(1, min(6, int(job.get("analysis_phase") or 1)))
            if job.get("status") != STATUS_ANALYSING:
                job["status"] = STATUS_ANALYSING
                job["analysis_phase"] = ap
                job["phase"] = phase_label(ap, job.get("sub_phase"))
                changed = True
    elif st == "SUCCEEDED":
        if job.get("status") != STATUS_COMPLETED or int(job.get("analysis_phase") or 0) != 6:
            job["status"] = STATUS_COMPLETED
            job["analysis_phase"] = 6
            job["sub_phase"] = None
            job["phase"] = phase_label(6, None)
            job["error"] = None
            changed = True
    elif st in {"FAILED", "TIMED_OUT", "ABORTED"}:
        msg = desc.get("error") or desc.get("cause") or st
        if job.get("status") != STATUS_FAILED:
            job["status"] = STATUS_FAILED
            job["error"] = str(msg)[:2000]
            job["phase"] = st
            changed = True

    if changed:
        from datetime import datetime, timezone

        job["updated_at"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    apply_pipeline_labels(job)
    return changed
