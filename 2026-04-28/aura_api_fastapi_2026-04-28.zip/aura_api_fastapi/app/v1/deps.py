from __future__ import annotations

from typing import Annotated, Any, Iterable

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .. import settings
from ..jwt_tokens import decode_access_token_maybe_ida
from ..user_identity import extract_user_id_from_claims

_bearer = HTTPBearer(auto_error=False)


def _decode_v1_token(token: str) -> dict[str, Any] | None:
    return decode_access_token_maybe_ida(token, allow_ida_unverified=True)


def _flatten_roles_from_claims(claims: dict[str, Any]) -> set[str]:
    out: list[str] = []
    for key in settings.V1_ROLE_CLAIM_KEYS:
        raw = claims.get(key)
        if raw is None:
            continue
        if isinstance(raw, str):
            for part in raw.replace(";", ",").split(","):
                p = part.strip()
                if p:
                    out.append(p)
        elif isinstance(raw, Iterable) and not isinstance(raw, (str, bytes, dict)):
            for item in raw:
                if isinstance(item, str) and item.strip():
                    out.append(item.strip())
        elif isinstance(raw, dict):
            for v in raw.values():
                if isinstance(v, str) and v.strip():
                    out.append(v.strip())
    return set(out)


def RequireV1Admin():
    """If AURA_V1_ADMIN_ROLE is set, require that role; otherwise no-op."""

    role = (settings.V1_ADMIN_ROLE or "").strip()
    if not role:

        async def _noop() -> None:
            return None

        return _noop
    return RequireV1Role(role)


async def get_v1_claims(
    cred: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
) -> dict[str, Any]:
    need = settings.v1_require_auth_effective()
    if cred is None or not (cred.credentials or "").strip():
        if need:
            raise HTTPException(status_code=401, detail="Not authenticated")
        return {}
    claims = _decode_v1_token(cred.credentials.strip())
    if claims is None:
        if need:
            raise HTTPException(status_code=401, detail="Invalid or expired token")
        return {}
    return claims


async def get_v1_user_id(claims: Annotated[dict[str, Any], Depends(get_v1_claims)]) -> str | None:
    return extract_user_id_from_claims(claims)


def RequireV1Role(role: str):
    """FastAPI dependency factory: require a role/entitlement string in token claims."""

    async def _check(claims: Annotated[dict[str, Any], Depends(get_v1_claims)]) -> None:
        if not role:
            return
        roles = _flatten_roles_from_claims(claims)
        if role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")

    return _check
