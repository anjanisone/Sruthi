from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from .. import settings
from ..stepfunctions.sfn import start_execution, stop_execution, translate_error
from ..upload import s3_presign
from . import dynamo_sync
from .deps import RequireV1Admin, get_v1_claims, get_v1_user_id
from .job_lifecycle import (
    STATUS_ANALYSING,
    STATUS_CANCELLED,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_QUEUED,
    STATUS_SUBMITTED,
    apply_pipeline_labels,
    normalize_job_fields,
    phase_label,
    sync_job_from_step_functions,
)
from .state import V1_STATE

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["v1 — AURA public API"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def _default_tree_and_files() -> tuple[dict[str, list[dict[str, Any]]], dict[str, dict[str, Any]]]:
    tree: dict[str, list[dict[str, Any]]] = {
        "": [
            {"name": "README.md", "path": "README.md", "type": "file", "size": 0},
            {"name": "src", "path": "src/", "type": "directory"},
        ]
    }
    files = {"README.md": {"content": "# stub\n", "metadata_only": False}}
    return tree, files


def load_job(job_id: str) -> dict[str, Any] | None:
    job = V1_STATE.analysis_jobs.get(job_id)
    if job:
        normalize_job_fields(job)
        return job
    row = dynamo_sync.fetch_job(job_id)
    if not row:
        return None
    job = dynamo_sync.job_from_dynamo_row(row)
    V1_STATE.analysis_jobs[job_id] = job
    return job


def ensure_repo_loaded(repo_id: str) -> bool:
    if repo_id in V1_STATE.repos:
        return True
    row = dynamo_sync.fetch_repo(repo_id)
    if not row:
        return False
    tree, files = _default_tree_and_files()
    V1_STATE.repos[repo_id] = {
        "repo_id": repo_id,
        "remote_url": row.get("remote_url", ""),
        "branch": row.get("branch", "main"),
        "commit_sha": row.get("commit_sha"),
        "created_at": row.get("created_at", _now_iso()),
        "created_by": row.get("user_id"),
        "versions": [],
        "tree": tree,
        "files": files,
    }
    return True


# --- Request bodies ---


class RegisterRepoBody(BaseModel):
    remote_url: str = Field(..., examples=["https://github.example.corp/org/repo.git"])
    branch: str = Field(default="main", examples=["main"])
    commit_sha: str | None = Field(default=None, examples=["abc1234"])


class CreateAnalysisJobBody(BaseModel):
    repo_id: str
    version: str | None = Field(default=None, description="Ingested snapshot id / commit label")
    upload_id: str | None = Field(
        default=None,
        description="Optional workspace upload; aura-uploads row is backfilled with job_id after submit.",
    )
    options: dict[str, Any] | None = None


class UploadsMintBody(BaseModel):
    files: list[dict[str, str]] | None = Field(
        default=None,
        description="Optional list of {name, content_type}; defaults to one generic part.",
    )


class ValidateBody(BaseModel):
    paths: list[str] | None = None


# --- Platform ---


@router.get("/health", summary="ALB/ECS health (no auth)")
def v1_health() -> dict[str, str]:
    return {"status": "ok", "api": "aura", "version": "v1"}


@router.get("/me", summary="Caller identity from Bearer token (debug RBAC)")
def v1_me(
    claims: dict[str, Any] = Depends(get_v1_claims),
    user_id: str | None = Depends(get_v1_user_id),
) -> dict[str, Any]:
    if settings.v1_require_auth_effective() and not claims:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return {
        "user_id": user_id,
        "claims": claims,
        "resource_uri": settings.IDA_RESOURCE_URI,
    }


# --- Ingestion ---


@router.post("/repos", summary="Register a repository source")
def v1_register_repo(
    body: RegisterRepoBody,
    user_id: str | None = Depends(get_v1_user_id),
    _claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    repo_id = _new_id("repo")
    created_at = _now_iso()
    tree, files = _default_tree_and_files()
    V1_STATE.repos[repo_id] = {
        "repo_id": repo_id,
        "remote_url": body.remote_url,
        "branch": body.branch,
        "commit_sha": body.commit_sha,
        "created_at": created_at,
        "created_by": user_id,
        "versions": [],
        "tree": tree,
        "files": files,
    }
    try:
        dynamo_sync.put_repo_record(
            repo_id=repo_id,
            user_id=user_id,
            remote_url=body.remote_url,
            branch=body.branch,
            commit_sha=body.commit_sha,
            created_at=created_at,
        )
    except (ClientError, BotoCoreError, ValueError, OSError) as exc:
        logger.warning("v1: repo DynamoDB persist failed: %s", exc)
        if not settings.V1_DYNAMO_OPTIONAL:
            raise HTTPException(
                status_code=503,
                detail=f"Could not persist repo to DynamoDB ({settings.v1_repos_table()}): {exc}",
            ) from exc
    return {"repo_id": repo_id, "remote_url": body.remote_url, "branch": body.branch}


@router.post("/repos/{repo_id}/ingest", summary="Trigger pull from Git provider into S3")
def v1_repo_ingest(
    repo_id: str,
    user_id: str | None = Depends(get_v1_user_id),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not ensure_repo_loaded(repo_id):
        raise HTTPException(status_code=404, detail="repo not found")
    version = _new_id("ver")
    snap = {
        "version": version,
        "created_at": _now_iso(),
        "status": "ready",
        "triggered_by": user_id,
    }
    V1_STATE.repos[repo_id]["versions"].append(snap)
    exec_info: dict[str, Any] | None = None
    try:
        exec_info = start_execution(
            kind="ingest",
            state_machine_arn=None,
            name=None,
            input_obj={"repo_id": repo_id, "version": version, "op": "ingest"},
            user_id=user_id,
        )
    except Exception as exc:
        code, msg = translate_error(exc)
        logger.info("v1 ingest SFN not started (%s): %s", code, msg)
        snap["orchestration"] = {"skipped": True, "reason": msg}
    else:
        snap["orchestration"] = exec_info
    return {"repo_id": repo_id, "version": version, "snapshot": snap}


@router.post("/uploads", summary="Mint pre-signed S3 upload URL(s)")
def v1_uploads_mint(
    body: UploadsMintBody,
    user_id: str | None = Depends(get_v1_user_id),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    upload_id = _new_id("upl")
    bucket = settings.S3_BUCKET
    files = body.files or [{"name": "artifact.bin", "content_type": "application/octet-stream"}]
    parts: list[dict[str, Any]] = []
    if not bucket:
        for f in files:
            name = f.get("name") or "upload.bin"
            parts.append(
                {
                    "name": name,
                    "put_url": f"https://example.invalid/presigned/{upload_id}/{name}",
                    "note": "Set AURA_S3_BUCKET for real pre-signed URLs.",
                }
            )
    else:
        client = s3_presign.s3_client()
        for f in files:
            raw_name = f.get("name") or "upload.bin"
            safe_name = s3_presign.safe_object_basename(raw_name)
            key = s3_presign.build_upload_key(upload_id, safe_name)
            put_url = client.generate_presigned_url(
                "put_object",
                Params={"Bucket": bucket, "Key": key, "ContentType": f.get("content_type") or "application/octet-stream"},
                ExpiresIn=max(60, min(settings.V1_PRESIGN_EXPIRES_SECONDS, 604800)),
            )
            parts.append({"name": safe_name, "key": key, "put_url": put_url})
    created_at = _now_iso()
    summary = [{"name": p.get("name"), "key": p.get("key")} for p in parts]
    V1_STATE.uploads[upload_id] = {
        "upload_id": upload_id,
        "status": "pending",
        "created_at": created_at,
        "user_id": user_id,
        "parts": parts,
    }
    try:
        dynamo_sync.put_upload_record(
            upload_id=upload_id,
            user_id=user_id,
            status="pending",
            created_at=created_at,
            parts_summary=summary,
        )
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: upload DynamoDB persist failed: %s", exc)
        if not settings.V1_DYNAMO_OPTIONAL:
            raise HTTPException(
                status_code=503,
                detail=f"Could not persist upload to DynamoDB ({settings.v1_uploads_table()}): {exc}",
            ) from exc
    return {"upload_id": upload_id, "urls": parts}


@router.post("/uploads/{upload_id}/complete", summary="Finalize upload and create version record")
def v1_upload_complete(
    upload_id: str,
    user_id: str | None = Depends(get_v1_user_id),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    rec = V1_STATE.uploads.get(upload_id)
    if not rec:
        raise HTTPException(status_code=404, detail="upload not found")
    rec["status"] = "completed"
    completed_at = _now_iso()
    rec["completed_at"] = completed_at
    try:
        dynamo_sync.patch_upload_status(
            upload_id=upload_id,
            status="completed",
            completed_at=completed_at,
            user_id=user_id,
        )
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: upload complete DynamoDB failed: %s", exc)
    version = _new_id("snap")
    return {"upload_id": upload_id, "version": version, "status": rec["status"]}


@router.get("/repos/{repo_id}/versions", summary="List ingested snapshots / versions")
def v1_repo_versions(
    repo_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not ensure_repo_loaded(repo_id):
        raise HTTPException(status_code=404, detail="repo not found")
    return {"repo_id": repo_id, "versions": V1_STATE.repos[repo_id].get("versions", [])}


# --- Browse / validate ---


@router.get("/repos/{repo_id}/tree", summary="Browse files and folders")
def v1_tree(
    repo_id: str,
    version: str | None = Query(default=None),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not ensure_repo_loaded(repo_id):
        raise HTTPException(status_code=404, detail="repo not found")
    return {
        "repo_id": repo_id,
        "version": version,
        "entries": V1_STATE.repos[repo_id].get("tree", {}).get("", []),
    }


@router.get("/repos/{repo_id}/files/{file_path:path}", summary="Fetch file contents or metadata")
def v1_file(
    repo_id: str,
    file_path: str,
    version: str | None = Query(default=None),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not ensure_repo_loaded(repo_id):
        raise HTTPException(status_code=404, detail="repo not found")
    norm = file_path.lstrip("/")
    files = V1_STATE.repos[repo_id].get("files", {})
    meta = files.get(norm)
    if meta is None:
        raise HTTPException(status_code=404, detail="file not found")
    return {"repo_id": repo_id, "version": version, "path": norm, **meta}


@router.post("/repos/{repo_id}/validate", summary="Validate file types / size policy")
def v1_validate(
    repo_id: str,
    body: ValidateBody,
    version: str | None = Query(default=None),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not ensure_repo_loaded(repo_id):
        raise HTTPException(status_code=404, detail="repo not found")
    violations: list[str] = []
    max_bytes = settings.S3_MAX_FILE_SIZE_BYTES
    for p in body.paths or []:
        if ".." in p or p.startswith("/"):
            violations.append(f"invalid path: {p}")
    return {"repo_id": repo_id, "version": version, "ok": not violations, "violations": violations, "max_file_bytes": max_bytes}


# --- Analysis jobs ---


def _default_artifacts(job_id: str) -> list[dict[str, Any]]:
    base = f"https://aura.local/artifact-stub/{job_id}"
    return [
        {"artifact_id": f"{job_id}_report_pdf", "name": "report", "format": "pdf", "url": f"{base}/report.pdf"},
        {"artifact_id": f"{job_id}_wiki", "name": "wiki", "format": "md", "url": f"{base}/wiki.md"},
    ]


@router.post("/analysis-jobs", summary="Create job record and start Step Functions when configured")
def v1_create_job(
    body: CreateAnalysisJobBody,
    user_id: str | None = Depends(get_v1_user_id),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not settings.V1_ALLOW_JOB_WITHOUT_USER_ID and not user_id:
        raise HTTPException(
            status_code=401,
            detail="Authorization token must include JPMCIdentifier (or sub) to submit analysis jobs.",
        )
    if not ensure_repo_loaded(body.repo_id):
        raise HTTPException(status_code=404, detail="repo not found")

    if body.upload_id:
        mem_u = V1_STATE.uploads.get(body.upload_id)
        ddb_u = dynamo_sync.fetch_upload(body.upload_id)
        if not mem_u and not ddb_u:
            raise HTTPException(status_code=404, detail="upload not found")
        owner = (mem_u or {}).get("user_id") or (ddb_u or {}).get("user_id") or ""
        if user_id and owner and owner != user_id:
            raise HTTPException(status_code=403, detail="upload belongs to another principal")

    job_id = _new_id("job")
    now = _now_iso()
    job: dict[str, Any] = {
        "job_id": job_id,
        "repo_id": body.repo_id,
        "upload_id": body.upload_id,
        "version": body.version,
        "status": STATUS_SUBMITTED,
        "analysis_phase": 0,
        "sub_phase": None,
        "phase": STATUS_SUBMITTED,
        "options": body.options or {},
        "created_at": now,
        "updated_at": now,
        "user_id": user_id,
        "error": None,
        "execution_arn": None,
        "artifacts": [],
    }
    try:
        dynamo_sync.put_job_record(job=job)
    except Exception as exc:
        if settings.V1_JOB_DYNAMO_BEST_EFFORT:
            logger.warning("v1: job DynamoDB write failed (continuing): %s", exc)
        else:
            raise HTTPException(
                status_code=503,
                detail=f"Could not persist job to DynamoDB ({settings.v1_jobs_table()}): {exc}",
            ) from exc

    job["status"] = STATUS_QUEUED
    job["analysis_phase"] = 0
    job["phase"] = STATUS_QUEUED
    job["updated_at"] = _now_iso()
    try:
        dynamo_sync.update_job_record(
            job_id=job_id,
            attributes={
                "status": job["status"],
                "phase": job["phase"],
                "analysis_phase": 0,
                "sub_phase": "",
                "updated_at": job["updated_at"],
            },
        )
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: job DynamoDB queued transition failed: %s", exc)

    sfn_input: dict[str, Any] = {
        "job_id": job_id,
        "repo_id": body.repo_id,
        "upload_id": body.upload_id or "",
        "version": body.version,
        "options": body.options or {},
        "user_id": user_id or "",
    }
    try:
        exec_info = start_execution(
            kind="job",
            state_machine_arn=None,
            name=job_id.replace("_", "-")[:80],
            input_obj=sfn_input,
            user_id=user_id,
        )
        job["execution_arn"] = exec_info.get("executionArn")
        job["status"] = STATUS_ANALYSING
        job["analysis_phase"] = 1
        job["phase"] = phase_label(1)
        job["updated_at"] = _now_iso()
        try:
            dynamo_sync.update_job_record(
                job_id=job_id,
                attributes={
                    "execution_arn": job["execution_arn"] or "",
                    "status": job["status"],
                    "phase": job["phase"],
                    "analysis_phase": 1,
                    "sub_phase": "",
                    "updated_at": job["updated_at"],
                    "error": "",
                },
            )
        except (ClientError, BotoCoreError, ValueError) as exc:
            logger.warning("v1: job DynamoDB update after SFN failed: %s", exc)
    except Exception as exc:
        code, msg = translate_error(exc)
        job["status"] = STATUS_QUEUED
        job["analysis_phase"] = 0
        job["sub_phase"] = None
        job["phase"] = STATUS_QUEUED
        job["error"] = msg
        job["updated_at"] = _now_iso()
        logger.info("v1 job SFN not started (%s): %s", code, msg)
        try:
            dynamo_sync.update_job_record(
                job_id=job_id,
                attributes={
                    "status": job["status"],
                    "phase": job["phase"],
                    "analysis_phase": 0,
                    "sub_phase": "",
                    "error": msg,
                    "updated_at": job["updated_at"],
                },
            )
        except (ClientError, BotoCoreError, ValueError) as exc2:
            logger.warning("v1: job DynamoDB error-state update failed: %s", exc2)

    if body.upload_id:
        try:
            dynamo_sync.patch_upload_job_id(upload_id=body.upload_id, job_id=job_id, updated_at=job["updated_at"])
            if body.upload_id in V1_STATE.uploads:
                V1_STATE.uploads[body.upload_id]["job_id"] = job_id
        except (ClientError, BotoCoreError, ValueError) as exc:
            logger.warning("v1: upload job_id backfill failed: %s", exc)

    apply_pipeline_labels(job)
    V1_STATE.analysis_jobs[job_id] = job
    return job


@router.get("/analysis-jobs/{job_id}", summary="Job status, phase, errors")
def v1_get_job(
    job_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    if sync_job_from_step_functions(job):
        try:
            attrs: dict[str, Any] = {
                "status": job["status"],
                "phase": job.get("phase") or "",
                "analysis_phase": int(job.get("analysis_phase") or 0),
                "sub_phase": job.get("sub_phase") or "",
                "error": job.get("error") or "",
                "updated_at": job["updated_at"],
            }
            dynamo_sync.update_job_record(job_id=job_id, attributes=attrs)
        except (ClientError, BotoCoreError, ValueError) as exc:
            logger.warning("v1: job DynamoDB sync after SFN describe failed: %s", exc)
        V1_STATE.analysis_jobs[job_id] = job
    apply_pipeline_labels(job)
    return job


@router.get("/analysis-jobs", summary="List jobs for a repository")
def v1_list_jobs(
    repo_id: str = Query(..., alias="repoId"),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    items = [j for j in V1_STATE.analysis_jobs.values() if j.get("repo_id") == repo_id]
    return {"repoId": repo_id, "jobs": items}


@router.post(
    "/analysis-jobs/{job_id}/rerun",
    summary="Rerun / resume from last completed phase",
    dependencies=[Depends(RequireV1Admin())],
)
def v1_rerun_job(
    job_id: str,
    user_id: str | None = Depends(get_v1_user_id),
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    normalize_job_fields(job)
    last_ap = int(job.get("analysis_phase") or 0)
    job["status"] = STATUS_QUEUED
    job["phase"] = STATUS_QUEUED
    job["updated_at"] = _now_iso()
    job["error"] = None
    try:
        exec_info = start_execution(
            kind="job",
            state_machine_arn=None,
            name=f"{job_id}-rerun".replace("_", "-")[:80],
            input_obj={
                "job_id": job_id,
                "resume": True,
                "repo_id": job.get("repo_id"),
                "resume_from_phase": last_ap,
            },
            user_id=user_id,
        )
        job["execution_arn"] = exec_info.get("executionArn")
        job["status"] = STATUS_ANALYSING
        job["analysis_phase"] = max(1, min(6, last_ap or 1))
        job["phase"] = phase_label(job["analysis_phase"], job.get("sub_phase"))
    except Exception as exc:
        _, msg = translate_error(exc)
        job["error"] = msg
        job["status"] = STATUS_QUEUED
        job["phase"] = STATUS_QUEUED
    try:
        dynamo_sync.update_job_record(
            job_id=job_id,
            attributes={
                "status": job["status"],
                "phase": job["phase"],
                "analysis_phase": int(job.get("analysis_phase") or 0),
                "sub_phase": job.get("sub_phase") or "",
                "execution_arn": job.get("execution_arn") or "",
                "error": job.get("error") or "",
                "updated_at": job["updated_at"],
            },
        )
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: job DynamoDB update (rerun) failed: %s", exc)
    apply_pipeline_labels(job)
    V1_STATE.analysis_jobs[job_id] = job
    return job


@router.post(
    "/analysis-jobs/{job_id}/cancel",
    summary="Cancel a running job",
    dependencies=[Depends(RequireV1Admin())],
)
def v1_cancel_job(
    job_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    arn = job.get("execution_arn")
    if arn:
        try:
            stop_execution(execution_arn=arn, error="UserCancel", cause="v1/cancel")
        except Exception as exc:
            logger.warning("v1 cancel stop_execution: %s", exc)
    job["status"] = STATUS_CANCELLED
    job["phase"] = STATUS_CANCELLED
    job["updated_at"] = _now_iso()
    try:
        dynamo_sync.update_job_record(
            job_id=job_id,
            attributes={
                "status": job["status"],
                "phase": job["phase"],
                "analysis_phase": int(job.get("analysis_phase") or 0),
                "sub_phase": job.get("sub_phase") or "",
                "updated_at": job["updated_at"],
            },
        )
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: job DynamoDB update (cancel) failed: %s", exc)
    apply_pipeline_labels(job)
    V1_STATE.analysis_jobs[job_id] = job
    return {"job_id": job_id, "status": job["status"]}


# --- Artifacts ---


@router.get("/analysis-jobs/{job_id}/artifacts", summary="List artifacts for a job")
def v1_list_artifacts(
    job_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    arts = job.get("artifacts") or []
    if not arts and job.get("status") in {
        STATUS_COMPLETED,
        STATUS_FAILED,
        STATUS_ANALYSING,
    }:
        arts = _default_artifacts(job_id)
        job["artifacts"] = arts
    return {"job_id": job_id, "artifacts": arts}


@router.get("/analysis-jobs/{job_id}/artifacts/{artifact_id}", summary="Download link (pre-signed S3 when configured)")
def v1_get_artifact(
    job_id: str,
    artifact_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    arts = job.get("artifacts") or _default_artifacts(job_id)
    job["artifacts"] = arts
    for a in arts:
        if a.get("artifact_id") == artifact_id:
            out = dict(a)
            bucket = settings.S3_BUCKET
            key = a.get("s3_key")
            if bucket and key:
                try:
                    client = s3_presign.s3_client()
                    out["download_url"] = client.generate_presigned_url(
                        "get_object",
                        Params={"Bucket": bucket, "Key": key},
                        ExpiresIn=max(60, min(settings.V1_PRESIGN_EXPIRES_SECONDS, 604800)),
                    )
                except (ClientError, BotoCoreError) as exc:
                    logger.warning("v1 artifact presign failed: %s", exc)
                    out["download_url"] = a.get("url")
            else:
                out["download_url"] = a.get("url")
            return out
    raise HTTPException(status_code=404, detail="artifact not found")


# --- KB publish ---


@router.post("/analysis-jobs/{job_id}/publish", summary="Trigger KB publisher pipeline")
def v1_publish_post(
    job_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    if not load_job(job_id):
        raise HTTPException(status_code=404, detail="job not found")
    st = {"status": "queued", "updated_at": _now_iso(), "detail": None}
    V1_STATE.publish[job_id] = st
    st["status"] = "running"
    st["updated_at"] = _now_iso()
    st["status"] = "succeeded"
    st["detail"] = "stub publish ok"
    return {"job_id": job_id, "publish": dict(st)}


@router.get("/analysis-jobs/{job_id}/publish", summary="Poll KB publish status")
def v1_publish_get(
    job_id: str,
    claims: dict[str, Any] = Depends(get_v1_claims),
) -> dict[str, Any]:
    st = V1_STATE.publish.get(job_id)
    if not st:
        return {"job_id": job_id, "status": "queued", "updated_at": _now_iso(), "detail": None}
    return {"job_id": job_id, **st}
