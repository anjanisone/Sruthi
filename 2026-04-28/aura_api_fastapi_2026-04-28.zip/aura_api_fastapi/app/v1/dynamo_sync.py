from __future__ import annotations

import json
import logging
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError

from .. import settings
from ..dynamodb.ddb import get_item_named, put_item_named, update_item_named

from .job_lifecycle import normalize_job_fields

logger = logging.getLogger(__name__)


def _repos_table() -> str:
    return settings.v1_repos_table()


def _uploads_table() -> str:
    return settings.v1_uploads_table()


def _jobs_table() -> str:
    return settings.v1_jobs_table()


def put_repo_record(
    *,
    repo_id: str,
    user_id: str | None,
    remote_url: str,
    branch: str,
    commit_sha: str | None,
    created_at: str,
) -> None:
    item: dict[str, Any] = {
        "repo_id": repo_id,
        "user_id": user_id or "",
        "remote_url": remote_url,
        "branch": branch,
        "created_at": created_at,
    }
    if commit_sha:
        item["commit_sha"] = commit_sha
    put_item_named(table_name=_repos_table(), item=item)


def put_upload_record(
    *,
    upload_id: str,
    user_id: str | None,
    status: str,
    created_at: str,
    parts_summary: list[dict[str, Any]] | None = None,
    job_id: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    item: dict[str, Any] = {
        "upload_id": upload_id,
        "user_id": user_id or "",
        "status": status,
        "created_at": created_at,
    }
    if job_id:
        item["job_id"] = job_id
    if parts_summary is not None:
        item["parts_summary"] = parts_summary
    if extra:
        for k, v in extra.items():
            if v is not None:
                item[k] = v
    put_item_named(table_name=_uploads_table(), item=item)


def patch_upload_status(
    *, upload_id: str, status: str, completed_at: str | None = None, user_id: str | None = None
) -> None:
    attrs: dict[str, Any] = {"status": status}
    if completed_at:
        attrs["completed_at"] = completed_at
    if user_id is not None:
        attrs["user_id"] = user_id
    update_item_named(table_name=_uploads_table(), key={"upload_id": upload_id}, attributes=attrs)


def patch_upload_job_id(*, upload_id: str, job_id: str, updated_at: str) -> None:
    """Backfill upload row with job_id after job submission (UpdateItem upserts missing items)."""
    update_item_named(
        table_name=_uploads_table(),
        key={"upload_id": upload_id},
        attributes={"job_id": job_id, "updated_at": updated_at},
    )


def put_job_record(*, job: dict[str, Any]) -> None:
    """Full job row for aura-jobs (PK job_id)."""
    row = job_to_dynamo_item(job)
    put_item_named(table_name=_jobs_table(), item=row)


def update_job_record(*, job_id: str, attributes: dict[str, Any]) -> None:
    update_item_named(table_name=_jobs_table(), key={"job_id": job_id}, attributes=attributes)


def job_to_dynamo_item(job: dict[str, Any]) -> dict[str, Any]:
    opts = job.get("options") or {}
    normalize_job_fields(job)
    row: dict[str, Any] = {
        "job_id": job["job_id"],
        "repo_id": job.get("repo_id"),
        "user_id": job.get("user_id") or "",
        "upload_id": job.get("upload_id") or "",
        "version": job.get("version") or "",
        "status": job.get("status"),
        "phase": job.get("phase") or "",
        "analysis_phase": int(job.get("analysis_phase") or 0),
        "sub_phase": job.get("sub_phase") or "",
        "execution_arn": job.get("execution_arn") or "",
        "created_at": job.get("created_at"),
        "updated_at": job.get("updated_at"),
        "error": job.get("error") or "",
    }
    if opts:
        row["options_json"] = json.dumps(opts, default=str)
    return row


def fetch_repo(repo_id: str) -> dict[str, Any] | None:
    try:
        return get_item_named(table_name=_repos_table(), key={"repo_id": repo_id})
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: fetch_repo failed: %s", exc)
        return None


def fetch_job(job_id: str) -> dict[str, Any] | None:
    try:
        return get_item_named(table_name=_jobs_table(), key={"job_id": job_id})
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: fetch_job failed: %s", exc)
        return None


def fetch_upload(upload_id: str) -> dict[str, Any] | None:
    try:
        return get_item_named(table_name=_uploads_table(), key={"upload_id": upload_id})
    except (ClientError, BotoCoreError, ValueError) as exc:
        logger.warning("v1: fetch_upload failed: %s", exc)
        return None


def job_from_dynamo_row(row: dict[str, Any]) -> dict[str, Any]:
    """Normalize aura-jobs item for API responses (in-memory shape)."""
    out = dict(row)
    ap = out.get("analysis_phase")
    if ap is not None:
        try:
            from decimal import Decimal

            if isinstance(ap, Decimal):
                out["analysis_phase"] = int(ap)
            else:
                out["analysis_phase"] = int(ap)
        except (TypeError, ValueError):
            out["analysis_phase"] = 0
    else:
        out["analysis_phase"] = 0
    oj = out.pop("options_json", None) or ""
    if oj:
        try:
            out["options"] = json.loads(oj)
        except (json.JSONDecodeError, TypeError):
            out["options"] = {}
    else:
        out.setdefault("options", {})
    for k in ("upload_id", "version", "execution_arn", "error", "sub_phase"):
        if out.get(k) == "":
            out[k] = None
    out.setdefault("artifacts", [])
    normalize_job_fields(out)
    return out
