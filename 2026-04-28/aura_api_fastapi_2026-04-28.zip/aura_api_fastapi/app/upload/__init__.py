"""Upload package: import submodules explicitly (e.g. ``app.upload.router``) to avoid import cycles."""
