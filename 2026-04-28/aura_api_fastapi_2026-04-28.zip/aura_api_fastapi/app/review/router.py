from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter

from ..models import (
    ReviewApproveData,
    ReviewApproveRequest,
    ReviewApproveResponse,
    ReviewGetData,
    ReviewGetResponse,
    ReviewRegenerateData,
    ReviewRegenerateRequest,
    ReviewRegenerateResponse,
    ReviewUpdateData,
    ReviewUpdateRequest,
    ReviewUpdateResponse,
)
from ..state import STATE

router = APIRouter(tags=["review"])


@router.get(
    "/jobs/{job_id}/review",
    response_model=ReviewGetResponse,
    summary="Get markdown review specs for a job",
)
def get_review(job_id: str) -> ReviewGetResponse:
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    specs = rec.get("review_specs", [])
    summary = rec["summary"]
    phase = getattr(summary, "phase_completed", 5)
    return ReviewGetResponse(
        success=True,
        data=ReviewGetData(
            job_id=job_id,
            status="AWAITING_REVIEW",
            phase_completed=phase,
            specs=specs,
            review_expires_at=datetime.utcnow(),
            total_specs=len(specs),
        ),
        errors=[],
    )


@router.put(
    "/jobs/{job_id}/review/spec",
    response_model=ReviewUpdateResponse,
    summary="Update a single review spec (markdown)",
)
def update_review_spec(job_id: str, payload: ReviewUpdateRequest) -> ReviewUpdateResponse:
    STATE.seed_job(job_id)
    return ReviewUpdateResponse(
        success=True,
        data=ReviewUpdateData(spec_path=payload.spec_path, status="UPDATED", updated_at=datetime.utcnow()),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/review/approve",
    response_model=ReviewApproveResponse,
    summary="Approve review and continue pipeline",
)
def approve_review(job_id: str, payload: ReviewApproveRequest) -> ReviewApproveResponse:
    STATE.seed_job(job_id)
    return ReviewApproveResponse(
        success=True,
        data=ReviewApproveData(
            job_id=job_id,
            status="RUNNING",
            current_phase=6,
            output_formats=payload.output_formats,
        ),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/review/regenerate",
    response_model=ReviewRegenerateResponse,
    summary="Regenerate after review feedback",
)
def regenerate_after_review(job_id: str, payload: ReviewRegenerateRequest) -> ReviewRegenerateResponse:
    _ = payload
    STATE.seed_job(job_id)
    return ReviewRegenerateResponse(
        success=True,
        data=ReviewRegenerateData(job_id=job_id, status="RUNNING", restarting_from_phase=4),
        errors=[],
    )
