from __future__ import annotations

import logging
import uuid

from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, HTTPException, Query, status
from starlette.requests import Request

from .. import settings
from ..models import (
    FileListData,
    FileListResponse,
    FilePreviewData,
    FilePreviewResponse,
    Pagination,
    RepoCloneData,
    RepoCloneRequest,
    RepoCloneResponse,
    ZipCloneRequest,
)
from ..s3_workspace import aggregate_languages_from_tree, clone_repo_to_s3
from ..state import STATE

router = APIRouter(tags=["ingest"])
logger = logging.getLogger(__name__)


def _norm_list_path(current_path: str) -> str:
    p = (current_path or "").strip()
    if not p or p == "/":
        return ""
    return p.rstrip("/") + "/"


def _require_s3_bucket() -> str:
    if not settings.S3_BUCKET:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="S3 is not configured. Set AURA_S3_BUCKET and credentials with s3:PutObject on the upload prefix.",
        )
    return settings.S3_BUCKET


def _clone_repo_to_workspace(payload: RepoCloneRequest, source: str, *, user_id: str | None) -> RepoCloneResponse:
    bucket = _require_s3_bucket()
    upload_id = str(uuid.uuid4())
    branch = (payload.branch or "main").strip() or "main"
    try:
        fc, tb, warnings, tree, prefix = clone_repo_to_s3(
            bucket=bucket,
            upload_id=upload_id,
            repository_url=(payload.repository_url or "").strip(),
            branch=branch,
            access_token=payload.access_token,
            username=payload.username,
            app_password=payload.app_password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc)) from exc
    except OSError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"git clone could not run (is git installed on PATH?): {exc}",
        ) from exc
    except (ClientError, BotoCoreError) as exc:
        logger.exception("ingest clone S3 failure upload_id=%s", upload_id)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"S3 upload after clone failed: {exc}",
        ) from exc

    langs = aggregate_languages_from_tree(tree)
    s3_uri = f"s3://{bucket}/{prefix}"
    STATE.ingest_file_trees[upload_id] = tree
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "upload_kind": "repo_clone",
        "user_id": user_id,
        "file_count": fc,
        "total_size_bytes": tb,
        "detected_languages": langs,
        "s3_path": prefix,
        "s3_uri": s3_uri,
        "object_url": "",
        "bucket": bucket,
        "key": "",
        "source": source,
        "validation_warnings": warnings,
    }
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(
            upload_id=upload_id,
            user_id=user_id,
            status="COMPLETED",
            estimated_time_seconds=0,
            file_count=fc,
            total_size_bytes=tb,
            s3_prefix=prefix,
            s3_uri=s3_uri,
        ),
        errors=[],
    )


def _start_clone(upload_id: str, source: str, *, user_id: str | None) -> RepoCloneResponse:
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0, "source": source, "user_id": user_id}
    STATE.seed_ingest_tree(upload_id)
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, user_id=user_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )


@router.post(
    "/ingest/repo-clone",
    response_model=RepoCloneResponse,
    summary="Generic repository clone (Bitbucket/GitHub compatible shape)",
)
def repo_clone(request: Request, payload: RepoCloneRequest) -> RepoCloneResponse:
    user_id = getattr(request.state, "user_id", None)
    return _clone_repo_to_workspace(payload, "repo_clone", user_id=user_id)


@router.post(
    "/ingest/bitbucket-clone",
    response_model=RepoCloneResponse,
    summary="Clone from Bitbucket into an upload workspace",
)
def bitbucket_clone(request: Request, payload: RepoCloneRequest) -> RepoCloneResponse:
    user_id = getattr(request.state, "user_id", None)
    return _clone_repo_to_workspace(payload, "bitbucket", user_id=user_id)


@router.post(
    "/ingest/github-clone",
    response_model=RepoCloneResponse,
    summary="Clone from GitHub into an upload workspace",
)
def github_clone(request: Request, payload: RepoCloneRequest) -> RepoCloneResponse:
    user_id = getattr(request.state, "user_id", None)
    return _clone_repo_to_workspace(payload, "github", user_id=user_id)


@router.post(
    "/ingest/zip-clone",
    response_model=RepoCloneResponse,
    summary="Ingest a direct zip upload (same workspace shape as repo clones)",
)
def zip_clone(request: Request, payload: ZipCloneRequest) -> RepoCloneResponse:
    _ = payload
    user_id = getattr(request.state, "user_id", None)
    return _start_clone(str(uuid.uuid4()), "zip", user_id=user_id)


@router.get(
    "/ingest/{upload_id}/files",
    response_model=FileListResponse,
    summary="Browse files for an upload / clone workspace (code browsing)",
)
def list_ingest_files(
    upload_id: str,
    current_path: str = Query("", description="Directory path to list (e.g. src/ or empty for root)"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> FileListResponse:
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    STATE.seed_ingest_tree(upload_id)
    key = _norm_list_path(current_path)
    tree = STATE.ingest_file_trees.get(upload_id, {})
    items = list(tree.get(key, []))
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return FileListResponse(
        success=True,
        data=FileListData(
            upload_id=upload_id,
            current_path=key if key else "/",
            items=page_items,
            pagination=Pagination(
                page=page,
                page_size=page_size,
                total_items=total,
                total_pages=total_pages,
            ),
        ),
        errors=[],
    )


@router.get(
    "/ingest/{upload_id}/files/preview",
    response_model=FilePreviewResponse,
    summary="Preview a single file from the ingest workspace (code browsing)",
)
def preview_ingest_file(
    upload_id: str,
    path: str = Query(..., description="File path relative to repo root (e.g. src/api/UserController.java)"),
) -> FilePreviewResponse:
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    STATE.seed_ingest_tree(upload_id)
    tree = STATE.ingest_file_trees[upload_id]
    target = None
    for lst in tree.values():
        for it in lst:
            if it.path == path and it.type == "file":
                target = it
                break
        if target:
            break
    if target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found for path.")
    lang = target.language or "text"
    return FilePreviewResponse(
        success=True,
        data=FilePreviewData(
            path=target.path,
            language=lang,
            size_bytes=target.size_bytes or 0,
            line_count=42,
            content=f"# Preview for {target.path}\n(package com.example; …)",
            syntax_highlighted=True,
            encoding="UTF-8",
        ),
        errors=[],
    )
