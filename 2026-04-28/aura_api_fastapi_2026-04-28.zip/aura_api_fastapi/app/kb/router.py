from __future__ import annotations

import uuid
from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException, Query, status

from ..models import (
    KbCreateData,
    KbCreateRequest,
    KbCreateResponse,
    KbCredentialDeleteData,
    KbCredentialDeleteResponse,
    KbCredentialItem,
    KbCredentialListData,
    KbCredentialListResponse,
    KbCredentialStoreData,
    KbCredentialStoreRequest,
    KbCredentialStoreResponse,
    KbDetailResponse,
    KbMetadata,
    KbSummaryItem,
    KbTenantsData,
    KbTenantsResponse,
    KbTokenData,
    KbTokenRequest,
    KbTokenResponse,
    KbValidateData,
    KbValidateRequest,
    KbValidateResponse,
    ListKbsData,
    ListKbsResponse,
    Pagination,
)
from ..state import STATE

router = APIRouter(tags=["kb"])


def _ensure_kb_seed() -> None:
    if STATE.knowledge_bases:
        return
    STATE.knowledge_bases["kb-demo-1"] = {
        "name": "Demo knowledge base",
        "tenant_id": "tenant-1",
        "description": "Seeded KB",
        "tags": ["demo"],
        "status": "ACTIVE",
        "document_count": 12,
    }


@router.get("/kb", response_model=ListKbsResponse, summary="List knowledge bases")
def list_kbs(
    tenant_id: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> ListKbsResponse:
    _ensure_kb_seed()
    items: list[KbSummaryItem] = []
    for kb_id, rec in STATE.knowledge_bases.items():
        if tenant_id and rec.get("tenant_id") != tenant_id:
            continue
        items.append(
            KbSummaryItem(
                kb_id=kb_id,
                name=str(rec.get("name", "")),
                document_count=int(rec.get("document_count", 0)),
                tenant_id=str(rec.get("tenant_id", "")),
            )
        )
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return ListKbsResponse(
        success=True,
        data=ListKbsData(
            items=page_items,
            pagination=Pagination(page=page, page_size=page_size, total_items=total, total_pages=total_pages),
        ),
        errors=[],
    )


@router.get("/kb/tenants", response_model=KbTenantsResponse, summary="List tenants")
def list_tenants() -> KbTenantsResponse:
    _ensure_kb_seed()
    tenants = sorted({str(v.get("tenant_id", "")) for v in STATE.knowledge_bases.values() if v.get("tenant_id")})
    return KbTenantsResponse(success=True, data=KbTenantsData(tenants=tenants), errors=[])


@router.post("/kb/token", response_model=KbTokenResponse, summary="Generate KB-scoped token")
def mint_kb_token(payload: KbTokenRequest) -> KbTokenResponse:
    exp = datetime.utcnow() + timedelta(hours=payload.expires_in_hours)
    return KbTokenResponse(
        success=True,
        data=KbTokenData(token=f"kb.{uuid.uuid4()}", expires_at=exp, scope=payload.scope),
        errors=[],
    )


@router.post("/kb/credentials", response_model=KbCredentialStoreResponse, summary="Store KB credentials")
def store_kb_credentials(payload: KbCredentialStoreRequest) -> KbCredentialStoreResponse:
    cred_id = str(uuid.uuid4())
    STATE.kb_credentials[cred_id] = {
        "tenant_id": payload.tenant_id,
        "kb_id": payload.kb_id,
        "alias": payload.alias,
        "stored_at": datetime.utcnow().isoformat(),
    }
    return KbCredentialStoreResponse(
        success=True,
        data=KbCredentialStoreData(credential_id=cred_id, alias=payload.alias, stored=True),
        errors=[],
    )


@router.get("/kb/credentials", response_model=KbCredentialListResponse, summary="List stored KB credentials")
def list_kb_credentials(tenant_id: str | None = Query(None)) -> KbCredentialListResponse:
    rows: list[KbCredentialItem] = []
    for cred_id, rec in STATE.kb_credentials.items():
        if tenant_id and rec.get("tenant_id") != tenant_id:
            continue
        rows.append(
            KbCredentialItem(
                credential_id=cred_id,
                tenant_id=str(rec.get("tenant_id", "")),
                kb_id=str(rec.get("kb_id", "")),
                alias=str(rec.get("alias", "")),
                expires_soon=False,
            )
        )
    return KbCredentialListResponse(success=True, data=KbCredentialListData(credentials=rows), errors=[])


@router.delete("/kb/credentials/{credential_id}", response_model=KbCredentialDeleteResponse)
def delete_kb_credential(credential_id: str) -> KbCredentialDeleteResponse:
    if credential_id not in STATE.kb_credentials:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Credential not found.")
    del STATE.kb_credentials[credential_id]
    return KbCredentialDeleteResponse(
        success=True,
        data=KbCredentialDeleteData(credential_id=credential_id, deleted=True),
        errors=[],
    )


@router.post("/kb", response_model=KbCreateResponse, summary="Create a knowledge base")
def create_kb(payload: KbCreateRequest) -> KbCreateResponse:
    _ensure_kb_seed()
    kb_id = str(uuid.uuid4())
    STATE.knowledge_bases[kb_id] = {
        "name": payload.kb_name,
        "tenant_id": payload.tenant_id,
        "description": payload.description,
        "tags": payload.tags,
        "status": "CREATING",
        "document_count": 0,
    }
    return KbCreateResponse(success=True, data=KbCreateData(kb_id=kb_id, status="CREATING"), errors=[])


@router.get("/kb/{kb_id}", response_model=KbDetailResponse, summary="Get KB metadata")
def get_kb(kb_id: str, tenant_id: str | None = Query(None)) -> KbDetailResponse:
    _ensure_kb_seed()
    rec = STATE.knowledge_bases.get(kb_id)
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="KB not found.")
    if tenant_id and rec.get("tenant_id") != tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="KB not found.")
    return KbDetailResponse(
        success=True,
        data=KbMetadata(
            kb_id=kb_id,
            tenant_id=str(rec.get("tenant_id", "")),
            name=str(rec.get("name", "")),
            description=str(rec.get("description", "")),
            tags=list(rec.get("tags", [])),
            status=str(rec.get("status", "ACTIVE")),
        ),
        errors=[],
    )


@router.post("/kb/{kb_id}/validate", response_model=KbValidateResponse, summary="Validate KB access")
def validate_kb(kb_id: str, payload: KbValidateRequest) -> KbValidateResponse:
    _ensure_kb_seed()
    if kb_id not in STATE.knowledge_bases:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="KB not found.")
    exp = datetime.utcnow() + timedelta(hours=1)
    return KbValidateResponse(
        success=True,
        data=KbValidateData(valid=True, permissions=["read", "write"], expires_at=exp),
        errors=[],
    )
