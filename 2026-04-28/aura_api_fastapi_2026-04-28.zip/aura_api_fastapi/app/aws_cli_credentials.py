from __future__ import annotations

from typing import Optional, Tuple


def load_aws_cli_credentials(*, profile: Optional[str] = None) -> Tuple[str, str, Optional[str]]:
    try:
        import boto3  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ValueError(
            "boto3 is required for credential_source=aws_cli. Install dependencies (pip install -r requirements.txt)."
        ) from exc

    session = boto3.Session(profile_name=profile)
    creds = session.get_credentials()
    if creds is None:
        raise ValueError(
            "No AWS credentials found. Use `aws configure`, a named profile, SSO login, or standard AWS_* env vars."
        )

    frozen = creds.get_frozen_credentials()
    key_id = frozen.access_key
    secret = frozen.secret_key
    token: Optional[str] = frozen.token if frozen.token else None

    if not key_id or not secret:
        raise ValueError("AWS credential resolution returned incomplete access key material.")

    return key_id, secret, token
