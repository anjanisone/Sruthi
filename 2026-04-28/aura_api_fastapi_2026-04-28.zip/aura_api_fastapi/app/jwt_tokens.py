from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict
from uuid import uuid4

import jwt

from . import settings


def mint_access_token(*, claims: Dict[str, Any], scope: str = "read write") -> tuple[str, int]:
    now = datetime.now(timezone.utc)
    exp_seconds = settings.JWT_EXPIRES_SECONDS
    payload: Dict[str, Any] = {
        "sub": claims.get("sub", "unknown"),
        "scope": scope,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=exp_seconds)).timestamp()),
        "jti": str(uuid4()),
        **{k: v for k, v in claims.items() if k not in {"sub", "scope", "iat", "exp", "jti"}},
    }
    token = jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    if isinstance(token, bytes):
        token = token.decode("utf-8")
    return token, exp_seconds


def decode_access_token(token: str) -> Dict[str, Any]:
    return jwt.decode(
        token,
        settings.JWT_SECRET,
        algorithms=[settings.JWT_ALGORITHM],
        options={"require": ["exp", "iat", "sub"]},
    )


def decode_access_token_maybe_ida(token: str, *, allow_ida_unverified: bool) -> Dict[str, Any] | None:
    """
    Validate HS256 app tokens first. Optionally accept IDA-shaped JWTs without signature
    verification (dev-only; gated by AURA_V1_IDA_UNVERIFIED_JWT and allow_ida_unverified).
    """
    try:
        return decode_access_token(token)
    except Exception:
        pass
    if allow_ida_unverified and settings.V1_IDA_UNVERIFIED_JWT:
        try:
            return jwt.decode(
                token,
                options={"verify_signature": False},
                algorithms=["RS256", "RS512", "ES256", "HS256"],
            )
        except Exception:
            return None
    return None
