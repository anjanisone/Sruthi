from __future__ import annotations

import logging
import mimetypes
import shutil
import subprocess
import tempfile
import zipfile
from collections import defaultdict
from pathlib import Path
from urllib.parse import quote, urlparse, urlunparse

from . import settings
from .models import FileListItem
from .upload.s3_presign import build_workspace_source_prefix, s3_client

logger = logging.getLogger(__name__)

_EXT_LANG = {
    ".py": "python",
    ".java": "java",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".jsx": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".xml": "xml",
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".md": "markdown",
    ".txt": "text",
    ".html": "html",
    ".css": "css",
    ".sql": "sql",
    ".sh": "shell",
    ".kt": "kotlin",
    ".kts": "kotlin",
}


def _language_for_path(rel: str) -> str | None:
    return _EXT_LANG.get(Path(rel).suffix.lower())


def is_safe_archive_member_path(name: str) -> bool:
    norm = name.replace("\\", "/").lstrip("/")
    if not norm or norm.startswith("../") or "/../" in f"/{norm}/":
        return False
    parts = Path(norm).parts
    return ".." not in parts


def extract_zip_to_directory(zip_path: str, dest_dir: Path) -> tuple[int, int]:
    """
    Extract zip members into dest_dir with Zip-slip protection.
    Returns (file_count, total_uncompressed_bytes).
    """
    dest_dir = dest_dir.resolve()
    dest_dir.mkdir(parents=True, exist_ok=True)
    total = 0
    files = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = info.filename
            if not is_safe_archive_member_path(name):
                logger.warning("upload_zip skip_unsafe_member name=%s", name)
                continue
            target = (dest_dir / name).resolve()
            try:
                target.relative_to(dest_dir)
            except ValueError:
                logger.warning("upload_zip skip_escape_member name=%s", name)
                continue
            if total + info.file_size > settings.S3_MAX_EXTRACTED_TOTAL_BYTES:
                raise ValueError(
                    f"Zip would exceed AURA_S3_MAX_EXTRACTED_TOTAL_BYTES ({settings.S3_MAX_EXTRACTED_TOTAL_BYTES})."
                )
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)
            total += info.file_size
            files += 1
            if files > settings.S3_MAX_EXTRACT_FILES:
                raise ValueError(
                    f"Zip contains more than AURA_S3_MAX_EXTRACT_FILES ({settings.S3_MAX_EXTRACT_FILES}) files."
                )
    return files, total


def upload_directory_to_s3(*, local_root: Path, bucket: str, key_prefix: str) -> tuple[int, int, list[str]]:
    """
    Upload every file under local_root to s3://bucket/{key_prefix}<relative path>.
    key_prefix should end with /.
    """
    if not key_prefix.endswith("/"):
        key_prefix = key_prefix + "/"
    client = s3_client()
    warnings: list[str] = []
    file_count = 0
    total = 0
    local_root = local_root.resolve()
    for path in sorted(local_root.rglob("*")):
        if not path.is_file():
            continue
        if file_count >= settings.S3_MAX_EXTRACT_FILES:
            warnings.append(f"Upload stopped after {settings.S3_MAX_EXTRACT_FILES} files (AURA_S3_MAX_EXTRACT_FILES).")
            break
        rel = path.relative_to(local_root).as_posix()
        key = f"{key_prefix}{rel}"
        st = path.stat()
        total += st.st_size
        if total > settings.S3_MAX_EXTRACTED_TOTAL_BYTES:
            raise ValueError(
                f"Upload would exceed AURA_S3_MAX_EXTRACTED_TOTAL_BYTES ({settings.S3_MAX_EXTRACTED_TOTAL_BYTES})."
            )
        ctype, _ = mimetypes.guess_type(str(path))
        extra: dict = {}
        if ctype:
            extra["ContentType"] = ctype
        with open(path, "rb") as body:
            client.upload_fileobj(body, bucket, key, ExtraArgs=extra if extra else {})
        file_count += 1
    return file_count, total, warnings


def aggregate_languages_from_tree(tree: dict[str, list[FileListItem]]) -> dict[str, int]:
    out: dict[str, int] = {}
    for items in tree.values():
        for it in items:
            if it.type == "file" and it.language:
                out[it.language] = out.get(it.language, 0) + 1
    return out


def build_ingest_file_tree(local_root: Path) -> dict[str, list[FileListItem]]:
    """Build STATE.ingest_file_trees shape: parent dir key ('' or 'src/') -> immediate children."""
    local_root = local_root.resolve()
    children: dict[str, dict[str, FileListItem]] = defaultdict(dict)

    def parent_key_for(rel_posix: str) -> str:
        parent = str(Path(rel_posix).parent)
        if parent in (".", ""):
            return ""
        return parent + "/"

    for path in sorted(local_root.rglob("*")):
        rel = path.relative_to(local_root).as_posix()
        parent = parent_key_for(rel)
        name = path.name
        if path.is_dir():
            item_path = rel + "/"
            children[parent][name] = FileListItem(
                name=name,
                path=item_path,
                type="directory",
                item_count=None,
            )
        else:
            children[parent][name] = FileListItem(
                name=name,
                path=rel,
                type="file",
                size_bytes=path.stat().st_size,
                language=_language_for_path(rel),
            )

    # Ensure single-root repo: if git clone created one subdir, callers pass that subdir as local_root — no change here.
    return {k: list(v.values()) for k, v in children.items()}


def authenticated_git_clone_url(url: str, *, access_token: str | None, username: str | None, app_password: str | None) -> str:
    raw = (url or "").strip()
    u = urlparse(raw)
    if u.scheme not in ("http", "https"):
        raise ValueError("repository_url must use http or https.")
    host = (u.hostname or "").lower()
    if access_token and "github.com" in host:
        auth = access_token.strip()
        netloc = f"{auth}@{u.hostname}"
        if u.port:
            netloc += f":{u.port}"
        return urlunparse((u.scheme, netloc, u.path, u.params, u.query, u.fragment))
    if username and app_password and "bitbucket.org" in host:
        user = quote(username, safe="")
        pw = quote(app_password, safe="")
        netloc = f"{user}:{pw}@{u.hostname}"
        if u.port:
            netloc += f":{u.port}"
        return urlunparse((u.scheme, netloc, u.path, u.params, u.query, u.fragment))
    return raw


def upload_zip_object_to_s3(*, local_zip: str | Path, bucket: str, key: str, content_type: str) -> None:
    client = s3_client()
    with open(local_zip, "rb") as body:
        client.upload_fileobj(body, bucket, key, ExtraArgs={"ContentType": content_type})


def expand_zip_and_upload_to_s3(
    *,
    upload_id: str,
    zip_path: str,
    bucket: str,
    input_key: str,
    content_type: str,
) -> tuple[int, int, list[str], dict[str, list[FileListItem]], str, int]:
    """
    Unzip to a temp directory, upload each file under ``.../source/``, then upload the original ``.zip`` to ``input_key``.

    Returns (extracted_file_count, extracted_bytes_on_s3, warnings, ingest_tree, source_prefix, zip_file_size).
    """
    zp = Path(zip_path)
    zsize = int(zp.stat().st_size)
    extract_dir = Path(tempfile.mkdtemp(prefix="aura_unzip_"))
    try:
        extract_zip_to_directory(str(zp), extract_dir)
        tree = build_ingest_file_tree(extract_dir)
        prefix = build_workspace_source_prefix(upload_id)
        fc, tb, warn = upload_directory_to_s3(local_root=extract_dir, bucket=bucket, key_prefix=prefix)
        upload_zip_object_to_s3(local_zip=zp, bucket=bucket, key=input_key, content_type=content_type)
        return fc, tb, warn, tree, prefix, zsize
    finally:
        shutil.rmtree(extract_dir, ignore_errors=True)


def clone_repo_to_s3(
    *,
    bucket: str,
    upload_id: str,
    repository_url: str,
    branch: str,
    access_token: str | None,
    username: str | None,
    app_password: str | None,
) -> tuple[int, int, list[str], dict[str, list[FileListItem]], str]:
    """
    Clone repository then upload tree to S3 under workspace prefix.
    Returns file_count, total_bytes, warnings, ingest_tree, s3_prefix.
    """
    clone_url = authenticated_git_clone_url(
        repository_url, access_token=access_token, username=username, app_password=app_password
    )
    work_parent = Path(tempfile.mkdtemp(prefix="aura_gitwrap_"))
    try:
        cmd = [
            "git",
            "clone",
            "--depth",
            "1",
            "--branch",
            branch,
            clone_url,
            str(work_parent / "repo"),
        ]
        proc = subprocess.run(
            cmd,
            cwd=str(work_parent),
            capture_output=True,
            text=True,
            timeout=settings.GIT_CLONE_TIMEOUT_SECONDS,
            check=False,
        )
        if proc.returncode != 0:
            err = (proc.stderr or proc.stdout or "").strip()
            raise RuntimeError(err or f"git clone failed with exit {proc.returncode}")
        root = (work_parent / "repo").resolve()
        prefix = build_workspace_source_prefix(upload_id)
        tree = build_ingest_file_tree(root)
        fc, tb, warn = upload_directory_to_s3(local_root=root, bucket=bucket, key_prefix=prefix)
        return fc, tb, warn, tree, prefix
    finally:
        shutil.rmtree(work_parent, ignore_errors=True)
