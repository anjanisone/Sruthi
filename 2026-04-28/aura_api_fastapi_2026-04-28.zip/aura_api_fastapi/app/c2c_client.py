from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

import requests

from . import settings


class C2CError(Exception):
    def __init__(self, message: str, *, http_status: Optional[int] = None, body: Any = None) -> None:
        super().__init__(message)
        self.http_status = http_status
        self.body = body


def _c2c_verify_arg() -> bool | str:
    bundle = settings.C2C_SSL_CA_BUNDLE
    if bundle:
        return bundle
    if not settings.C2C_VERIFY_SSL:
        return False
    return True


def exchange_with_c2c(*, audience: str, subject_token: str, subject_token_type: str) -> Dict[str, Any]:
    endpoint = settings.C2C_TOKEN_ENDPOINT
    if not endpoint:
        raise C2CError("AURA_C2C_TOKEN_ENDPOINT is not configured.")

    client_request_id = str(uuid.uuid4())
    request_data = {
        "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
        "audience": audience,
        "requested_token_type": settings.C2C_REQUESTED_TOKEN_TYPE,
        "subject_token": subject_token,
        "subject_token_type": subject_token_type,
    }
    request_headers = {
        "x-client-request-id": client_request_id,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    auth = None
    if settings.C2C_CLIENT_SECRET:
        if not settings.C2C_CLIENT_ID:
            raise C2CError("AURA_C2C_CLIENT_ID is required when AURA_C2C_CLIENT_SECRET is set.")
        # Most OAuth servers prefer Basic auth for client_secret.
        auth = (settings.C2C_CLIENT_ID, settings.C2C_CLIENT_SECRET)

    try:
        resp = requests.post(
            endpoint,
            data=request_data,
            headers=request_headers,
            auth=auth,
            timeout=settings.C2C_TIMEOUT_SECONDS,
            verify=_c2c_verify_arg(),
        )
    except requests.RequestException as exc:
        raise C2CError(f"C2C request failed: {exc}") from exc

    try:
        body = resp.json()
    except ValueError as exc:
        raise C2CError(
            f"C2C returned non-JSON (HTTP {resp.status_code}).",
            http_status=resp.status_code,
            body=resp.text[:2000],
        ) from exc

    if resp.status_code >= 400:
        msg = body.get("error_description") or body.get("error") or resp.reason or "C2C error"
        raise C2CError(str(msg), http_status=resp.status_code, body=body)

    if isinstance(body, dict) and body.get("error"):
        msg = body.get("error_description") or body.get("error") or "C2C error"
        raise C2CError(str(msg), http_status=resp.status_code or 400, body=body)

    if not isinstance(body, dict) or "access_token" not in body:
        raise C2CError("C2C response missing access_token.", http_status=502, body=body)

    return body
