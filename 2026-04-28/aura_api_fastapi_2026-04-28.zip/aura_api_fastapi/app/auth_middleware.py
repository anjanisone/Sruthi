from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from . import settings
from .jwt_tokens import decode_access_token_maybe_ida
from .user_identity import extract_user_id_from_claims


def _is_exempt_path(path: str) -> bool:
    if path in {"/", "/health", "/favicon.ico", "/v1/health"}:
        return True
    if path.startswith("/docs") or path.startswith("/redoc"):
        return True
    if path.startswith("/ws/"):
        return True
    if path in {
        "/openapi.json",
        "/auth/token",
        "/auth/build-gci-subject-token",
        "/upload-zip/ui",
        "/meta",
    }:
        return True
    return False


class AuthEnforcementMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Best-effort identity extraction even when auth is disabled,
        # so uploads/jobs can still be attributed when a bearer token is provided.
        request.state.user_claims = None
        request.state.user_id = None
        authorization = request.headers.get("Authorization") or ""
        if authorization.lower().startswith("bearer "):
            token = authorization.split(" ", 1)[1].strip()
            path = request.url.path
            allow_ida = path.startswith("/v1/") and path != "/v1/health"
            claims = decode_access_token_maybe_ida(token, allow_ida_unverified=allow_ida)
            request.state.user_claims = claims
            request.state.user_id = extract_user_id_from_claims(claims)

        if not settings.REQUIRE_AUTH:
            return await call_next(request)

        if request.method == "OPTIONS" or _is_exempt_path(request.url.path):
            return await call_next(request)

        if not authorization or not authorization.lower().startswith("bearer "):
            return JSONResponse({"detail": "Not authenticated"}, status_code=401)

        # When REQUIRE_AUTH=1, token must validate.
        if request.state.user_claims is None:
            return JSONResponse({"detail": "Invalid or expired token"}, status_code=401)

        return await call_next(request)
