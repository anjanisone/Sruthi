from __future__ import annotations

import asyncio
import logging

from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, HTTPException, status

from ..models import (
    DynamoGetItemData,
    DynamoGetItemRequest,
    DynamoGetItemResponse,
    DynamoPutItemData,
    DynamoPutItemRequest,
    DynamoPutItemResponse,
    DynamoQueryData,
    DynamoQueryRequest,
    DynamoQueryResponse,
)
from . import ddb

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dynamodb", tags=["dynamodb"])


def _http_from_client_error(exc: ClientError) -> HTTPException:
    code, detail = ddb.translate_client_error(exc)
    return HTTPException(status_code=code, detail=detail)


@router.post(
    "/items",
    response_model=DynamoPutItemResponse,
    summary="Put a full item into the configured DynamoDB table (PutItem)",
)
async def dynamodb_put_item(payload: DynamoPutItemRequest) -> DynamoPutItemResponse:
    try:
        await asyncio.to_thread(ddb.put_item, item=dict(payload.item))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
    except ClientError as exc:
        raise _http_from_client_error(exc) from exc
    except BotoCoreError as exc:
        logger.exception("dynamodb PutItem boto core error")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"DynamoDB request failed: {exc}",
        ) from exc
    return DynamoPutItemResponse(success=True, data=DynamoPutItemData(ok=True), errors=[])


@router.post(
    "/items/get",
    response_model=DynamoGetItemResponse,
    summary="Fetch one item by primary key (GetItem)",
)
async def dynamodb_get_item(payload: DynamoGetItemRequest) -> DynamoGetItemResponse:
    try:
        item = await asyncio.to_thread(ddb.get_item, key=dict(payload.key))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
    except ClientError as exc:
        raise _http_from_client_error(exc) from exc
    except BotoCoreError as exc:
        logger.exception("dynamodb GetItem boto core error")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"DynamoDB request failed: {exc}",
        ) from exc
    return DynamoGetItemResponse(
        success=True,
        data=DynamoGetItemData(item=item, found=item is not None),
        errors=[],
    )


@router.post(
    "/items/query",
    response_model=DynamoQueryResponse,
    summary="Query items by partition key (and optional sort key equality)",
)
async def dynamodb_query(payload: DynamoQueryRequest) -> DynamoQueryResponse:
    try:
        items, lek = await asyncio.to_thread(
            ddb.query_by_partition_key,
            partition_key_attr=payload.partition_key_attr,
            partition_key_value=payload.partition_key_value,
            sort_key_attr=payload.sort_key_attr,
            sort_key_value=payload.sort_key_value,
            limit=payload.limit,
            scan_index_forward=payload.scan_index_forward,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
    except ClientError as exc:
        raise _http_from_client_error(exc) from exc
    except BotoCoreError as exc:
        logger.exception("dynamodb Query boto core error")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"DynamoDB request failed: {exc}",
        ) from exc
    return DynamoQueryResponse(
        success=True,
        data=DynamoQueryData(items=items, count=len(items), last_evaluated_key=lek),
        errors=[],
    )
