from __future__ import annotations

import base64
import logging
import os
from decimal import Decimal
from typing import Any

import boto3
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.types import Binary
from botocore.config import Config
from botocore.exceptions import ClientError

from .. import settings

logger = logging.getLogger(__name__)
_proxy_notice_sent = False


def _proxies_from_env() -> dict[str, str] | None:
    http = (os.getenv("HTTP_PROXY") or os.getenv("http_proxy") or "").strip()
    https = (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or "").strip()
    if not http and not https:
        return None
    out: dict[str, str] = {}
    if http:
        out["http"] = http
    if https:
        out["https"] = https
    return out or None


def _ddb_boto_config() -> Config:
    kwargs: dict[str, Any] = {
        "connect_timeout": settings.S3_CONNECT_TIMEOUT_SECONDS,
        "read_timeout": settings.S3_READ_TIMEOUT_SECONDS,
        "retries": {"max_attempts": 5, "mode": "standard"},
    }
    proxies = _proxies_from_env()
    if proxies:
        kwargs["proxies"] = proxies
    if settings.BOTO_PROXY_USE_FORWARDING_HTTPS:
        kwargs["proxies_config"] = {"proxy_use_forwarding_for_https": True}
    return Config(**kwargs)


def _ddb_resource():
    global _proxy_notice_sent
    proxies = _proxies_from_env()
    if proxies and not _proxy_notice_sent:
        logger.info(
            "boto3 DynamoDB: using HTTP_PROXY/HTTPS_PROXY (or AURA_HTTP_PROXY/AURA_HTTPS_PROXY)."
        )
        _proxy_notice_sent = True
    return boto3.resource(
        "dynamodb",
        region_name=settings.DYNAMODB_REGION,
        config=_ddb_boto_config(),
    )


def require_table_name() -> str:
    name = settings.DYNAMODB_TABLE_NAME
    if not name:
        raise ValueError(
            "DynamoDB is not configured. Set AURA_DYNAMODB_TABLE_NAME (and AWS credentials with dynamodb:PutItem/GetItem/Query)."
        )
    return name


def table():
    return _ddb_resource().Table(require_table_name())


def dynamo_to_jsonable(value: Any) -> Any:
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    if isinstance(value, Binary):
        return base64.b64encode(value.value).decode("ascii")
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    if isinstance(value, dict):
        return {k: dynamo_to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [dynamo_to_jsonable(v) for v in value]
    if isinstance(value, set):
        return [dynamo_to_jsonable(v) for v in value]
    return value


def put_item(*, item: dict[str, Any]) -> None:
    table().put_item(Item=item)


def get_item(*, key: dict[str, Any]) -> dict[str, Any] | None:
    resp = table().get_item(Key=key)
    raw = resp.get("Item")
    if not raw:
        return None
    return dynamo_to_jsonable(raw)


def query_by_partition_key(
    *,
    partition_key_attr: str,
    partition_key_value: Any,
    sort_key_attr: str | None,
    sort_key_value: Any | None,
    limit: int,
    scan_index_forward: bool,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    t = table()
    if sort_key_attr and sort_key_value is not None:
        expr = Key(partition_key_attr).eq(partition_key_value) & Key(sort_key_attr).eq(sort_key_value)
    else:
        expr = Key(partition_key_attr).eq(partition_key_value)
    resp = t.query(
        KeyConditionExpression=expr,
        Limit=limit,
        ScanIndexForward=scan_index_forward,
    )
    items = [dynamo_to_jsonable(i) for i in resp.get("Items", [])]
    lek = resp.get("LastEvaluatedKey")
    lek_out = dynamo_to_jsonable(lek) if lek else None
    return items, lek_out


def translate_client_error(exc: ClientError) -> tuple[int, str]:
    code = (exc.response.get("Error") or {}).get("Code", "")
    msg = (exc.response.get("Error") or {}).get("Message", str(exc))
    if code == "ResourceNotFoundException":
        return 404, msg
    if code == "ConditionalCheckFailedException":
        return 409, msg
    if code in {"ValidationException", "InvalidParameterValue"}:
        return 400, msg
    return 503, f"DynamoDB error ({code}): {msg}"
