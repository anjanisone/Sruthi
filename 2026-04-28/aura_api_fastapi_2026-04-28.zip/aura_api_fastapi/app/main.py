from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.responses import HTMLResponse

from . import settings
from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .dynamodb.router import router as dynamodb_router
from .ingest.router import router as ingest_router
from .jobs.router import router as jobs_router
from .kb.router import router as kb_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .review.router import router as review_router
from .stepfunctions.router import router as stepfunctions_router
from .upload.router import router as upload_router
from .v1.router import router as v1_router

_DOCS_OFFLINE_HTML = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/><title>AURA</title></head>
<body style="font-family:system-ui;margin:2rem"><h1>AURA</h1>
<p><a href="/openapi.json">openapi.json</a> · <a href="/upload-zip/ui">upload</a> · <a href="/meta">meta</a> · <a href="/health">health</a></p>
<p style="color:#666">Offline docs. Set <code>AURA_DOCS_CDN_OFFLINE=0</code> for Swagger.</p></body></html>"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.resource_uri = settings.IDA_RESOURCE_URI
    app.state.outbound_token_provider = create_outbound_token_provider()
    logging.info("AURA startup complete.")
    yield


app = FastAPI(
    title="AURA API",
    version="0.2.4",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
)

_cdn = settings.SWAGGER_UI_DIST_CDN

if settings.DOCS_CDN_OFFLINE:

    @app.get("/docs", include_in_schema=False)
    async def docs_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)

    @app.get("/redoc", include_in_schema=False)
    async def redoc_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)
else:

    @app.get("/docs", include_in_schema=False)
    async def swagger_ui() -> HTMLResponse:
        return get_swagger_ui_html(
            openapi_url=app.openapi_url,
            title=f"{app.title} — Swagger UI",
            swagger_js_url=f"{_cdn}/swagger-ui-bundle.js",
            swagger_css_url=f"{_cdn}/swagger-ui.css",
            swagger_favicon_url=f"{_cdn}/favicon-32x32.png",
        )

    @app.get("/redoc", include_in_schema=False)
    async def redoc_html() -> HTMLResponse:
        return get_redoc_html(
            openapi_url=app.openapi_url,
            title=f"{app.title} — ReDoc",
            redoc_js_url=settings.REDOC_STANDALONE_JS,
        )

app.add_middleware(AuthEnforcementMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(dynamodb_router)
app.include_router(upload_router)
app.include_router(ingest_router)
app.include_router(kb_router)
app.include_router(jobs_router)
app.include_router(review_router)
app.include_router(stepfunctions_router)
app.include_router(v1_router)


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok"}


@app.get("/meta", tags=["meta"])
def deployment_meta() -> dict:
    return {
        "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "swagger_custom_cdn",
        "swagger_ui_dist_cdn": settings.SWAGGER_UI_DIST_CDN,
        "redoc_js": settings.REDOC_STANDALONE_JS,
        "dynamodb_table_configured": bool(settings.DYNAMODB_TABLE_NAME),
        "s3_https_proxy": "set" if settings.BOTO_HTTPS_PROXY_CONFIGURED else "unset",
    }


@app.websocket("/ws/jobs/{job_id}")
async def job_events_websocket(websocket: WebSocket, job_id: str) -> None:
    await websocket.accept()
    try:
        await websocket.send_json(
            {"event": "phase", "job_id": job_id, "phase": 1, "message": "stream_open"}
        )
        await websocket.send_json(
            {"event": "chunk", "job_id": job_id, "chunk_id": "chunk_1", "status": "SUCCESS"}
        )
        await websocket.send_json({"event": "complete", "job_id": job_id, "ok": True})
    except WebSocketDisconnect:
        return
