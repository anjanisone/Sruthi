from fastapi import APIRouter, HTTPException, status

from .. import settings
from ..aws_cli_credentials import load_aws_cli_credentials
from ..c2c_client import C2CError, exchange_with_c2c
from ..gci_build import build_gci_subject_token
from ..gci_sts import GciValidationError, claims_from_sts_identity, verify_aws_get_caller_identity_subject_token
from ..jwt_tokens import mint_access_token
from ..models import (
    AuthTokenData,
    AuthTokenRequest,
    AuthTokenResponse,
    GciSubjectTokenBuildData,
    GciSubjectTokenBuildRequest,
    GciSubjectTokenBuildResponse,
    GrantType,
)

router = APIRouter(tags=["auth"])


def _http_status_for_c2c(err: C2CError) -> int:
    if err.http_status is None:
        return status.HTTP_502_BAD_GATEWAY
    if err.http_status >= 500:
        return status.HTTP_502_BAD_GATEWAY
    if err.http_status in (401, 403):
        return err.http_status
    if err.http_status == 400:
        return status.HTTP_400_BAD_REQUEST
    return status.HTTP_502_BAD_GATEWAY


def _use_c2c_for_token_exchange() -> bool:
    mode = settings.TOKEN_EXCHANGE_MODE
    if mode == "c2c":
        return True
    if mode == "local":
        return False
    return bool(settings.C2C_TOKEN_ENDPOINT)


@router.post("/auth/token", response_model=AuthTokenResponse)
def auth_token(payload: AuthTokenRequest) -> AuthTokenResponse:
    if payload.grant_type == GrantType.client_credentials:
        if payload.client_id != settings.CLIENT_ID or payload.client_secret != settings.CLIENT_SECRET:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid client credentials.")
        access_token, expires_in = mint_access_token(
            claims={"sub": f"client:{payload.client_id}", "auth_method": "client_credentials"},
        )
        scope = "read write"
    elif payload.grant_type == GrantType.token_exchange:
        if payload.subject_token_type not in settings.AWS_GET_CALLER_IDENTITY_TOKEN_TYPES:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unsupported subject_token_type for this server.",
            )
        assert payload.audience is not None and payload.subject_token is not None

        use_c2c = _use_c2c_for_token_exchange()
        if settings.TOKEN_EXCHANGE_MODE == "c2c" and not settings.C2C_TOKEN_ENDPOINT:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Token exchange is configured for C2C but AURA_C2C_TOKEN_ENDPOINT is not set.",
            )

        if use_c2c:
            try:
                body = exchange_with_c2c(
                    audience=payload.audience,
                    subject_token=payload.subject_token,
                    subject_token_type=payload.subject_token_type,
                )
            except C2CError as exc:
                raise HTTPException(status_code=_http_status_for_c2c(exc), detail=str(exc)) from exc
            access_token = str(body["access_token"])
            raw_exp = body.get("expires_in")
            expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
            scope = str(body.get("scope") or "read write")
        else:
            try:
                identity = verify_aws_get_caller_identity_subject_token(payload.subject_token)
            except GciValidationError as exc:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc
            claims, scope = claims_from_sts_identity(identity, audience=payload.audience)
            access_token, expires_in = mint_access_token(claims=claims, scope=scope)
    else:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Unsupported grant_type.")

    return AuthTokenResponse(
        success=True,
        data=AuthTokenData(
            access_token=access_token,
            token_type="Bearer",
            expires_in=expires_in,
            scope=scope,
        ),
        errors=[],
    )


@router.post("/auth/build-gci-subject-token", response_model=GciSubjectTokenBuildResponse)
def build_gci_subject_token_route(payload: GciSubjectTokenBuildRequest) -> GciSubjectTokenBuildResponse:
    if not settings.ALLOW_GCI_SUBJECT_TOKEN_BUILDER:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GCI builder is disabled. Set AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER=true to enable (dev only).",
        )
    access_key_id = payload.access_key_id
    secret_access_key = payload.secret_access_key
    session_token = payload.session_token

    if payload.credential_source == "aws_cli":
        if not settings.ALLOW_GCI_BUILDER_AWS_CLI_CREDS:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="credential_source=aws_cli is disabled. Set AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS=true or use static keys.",
            )
        try:
            access_key_id, secret_access_key, session_token = load_aws_cli_credentials(profile=payload.aws_profile)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    assert access_key_id is not None and secret_access_key is not None

    try:
        token = build_gci_subject_token(
            region=payload.region,
            audience=payload.audience,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            session_token=session_token,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    return GciSubjectTokenBuildResponse(
        success=True,
        data=GciSubjectTokenBuildData(subject_token=token),
        errors=[],
    )

