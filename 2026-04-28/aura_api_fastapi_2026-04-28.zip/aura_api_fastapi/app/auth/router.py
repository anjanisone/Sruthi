from typing import Annotated

from fastapi import APIRouter, Body, HTTPException, status

from .. import settings
from ..aws_cli_credentials import load_aws_cli_credentials
from ..c2c_client import C2CError, exchange_with_c2c, tls_verify_for_adfs_requests
from ..gci_build import build_gci_subject_token
from ..gci_sts import GciValidationError, claims_from_sts_identity, verify_aws_get_caller_identity_subject_token
from ..jwt_tokens import mint_access_token
from ..outbound.adfs_client import post_adfs_token
from ..outbound.token_provision import TokenProvisionException
from ..models import (
    AdfsClientCredentialsAuthRequest,
    AdfsPasswordAuthRequest,
    AuthTokenData,
    AuthTokenRequest,
    AuthTokenResponse,
    ClientCredentialsAuthRequest,
    GciSubjectTokenBuildData,
    GciSubjectTokenBuildRequest,
    GciSubjectTokenBuildResponse,
    TokenExchangeAuthRequest,
)

_IDA_OPTION_A_FORBIDDEN_DETAIL = (
    "adfs_client_credentials disabled (AURA_ENFORCE_IDA_TOKEN_OPTION_A). "
    "Use IDA Bearer from c2csdk, or set AURA_ENFORCE_IDA_TOKEN_OPTION_A=0 for lab."
)

router = APIRouter(tags=["auth"])

# First example is the default in Swagger UI (matches ADFS password grant: no client_secret).
_AUTH_TOKEN_OPENAPI_EXAMPLES: dict[str, dict] = {
    "ida_password": {
        "summary": "IDA / ADFS password (FID)",
        "value": {
            "grant_type": "adfs_password",
            "client_id": "<IDA OAuth client id>",
            "username": "AD\\<FID>",
            "password": "<password>",
            "resource": "<JPMC:URI:RS-...>",
        },
    },
    "token_exchange": {
        "summary": "Token exchange (GCI)",
        "value": {
            "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
            "audience": "https://api.example.com/",
            "subject_token": "<gci>",
            "subject_token_type": "urn:jpmc:params:identity:token-type:aws-get-caller-identity",
        },
    },
    "client_credentials": {
        "summary": "Local JWT (client_credentials)",
        "value": {"grant_type": "client_credentials", "client_id": "<AURA_CLIENT_ID>"},
    },
    "client_credentials_with_secret": {
        "summary": "Local JWT + secret",
        "value": {
            "grant_type": "client_credentials",
            "client_id": "<AURA_CLIENT_ID>",
            "client_secret": "<AURA_CLIENT_SECRET>",
        },
    },
}


def _http_status_for_c2c(err: C2CError) -> int:
    if err.http_status is None:
        return status.HTTP_502_BAD_GATEWAY
    if err.http_status >= 500:
        return status.HTTP_502_BAD_GATEWAY
    if err.http_status in (401, 403):
        return err.http_status
    if err.http_status == 400:
        return status.HTTP_400_BAD_REQUEST
    return status.HTTP_502_BAD_GATEWAY


def _use_c2c_for_token_exchange() -> bool:
    mode = settings.TOKEN_EXCHANGE_MODE
    if mode == "c2c":
        return True
    if mode == "local":
        return False
    return bool(settings.C2C_TOKEN_ENDPOINT)


@router.post("/auth/token", response_model=AuthTokenResponse, summary="Issue access token")
def auth_token(
    payload: Annotated[AuthTokenRequest, Body(openapi_examples=_AUTH_TOKEN_OPENAPI_EXAMPLES)],
) -> AuthTokenResponse:
    if isinstance(payload, ClientCredentialsAuthRequest):
        if settings.ALLOW_CLIENT_CREDENTIALS_NO_SECRET:
            if payload.client_id != settings.CLIENT_ID:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="client_id must match this server's AURA_CLIENT_ID (no-secret dev mode).",
                )
        else:
            if (payload.client_secret or "") != settings.CLIENT_SECRET or payload.client_id != settings.CLIENT_ID:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=(
                        "Bad client_id/client_secret, or set AURA_ALLOW_CLIENT_CREDENTIALS_NO_SECRET=1 and omit secret."
                    ),
                )
        access_token, expires_in = mint_access_token(
            claims={"sub": f"client:{payload.client_id}", "auth_method": "client_credentials"},
        )
        scope = "read write"
    elif isinstance(payload, TokenExchangeAuthRequest):
        if payload.subject_token_type not in settings.AWS_GET_CALLER_IDENTITY_TOKEN_TYPES:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unsupported subject_token_type for this server.",
            )
        use_c2c = _use_c2c_for_token_exchange()
        if settings.TOKEN_EXCHANGE_MODE == "c2c" and not settings.C2C_TOKEN_ENDPOINT:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Token exchange is configured for C2C but AURA_C2C_TOKEN_ENDPOINT is not set.",
            )

        if use_c2c:
            try:
                body = exchange_with_c2c(
                    audience=payload.audience,
                    subject_token=payload.subject_token,
                    subject_token_type=payload.subject_token_type,
                )
            except C2CError as exc:
                raise HTTPException(status_code=_http_status_for_c2c(exc), detail=str(exc)) from exc
            access_token = str(body["access_token"])
            raw_exp = body.get("expires_in")
            expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
            scope = str(body.get("scope") or "read write")
        else:
            try:
                identity = verify_aws_get_caller_identity_subject_token(payload.subject_token)
            except GciValidationError as exc:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc
            claims, scope = claims_from_sts_identity(identity, audience=payload.audience)
            access_token, expires_in = mint_access_token(claims=claims, scope=scope)
    elif isinstance(payload, AdfsClientCredentialsAuthRequest):
        if settings.ENFORCE_IDA_TOKEN_OPTION_A:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=_IDA_OPTION_A_FORBIDDEN_DETAIL)
        token_url = settings.ida_adfs_token_endpoint()
        resource = (payload.resource or settings.ida_client_credentials_resource_uri() or "").strip()
        if not token_url:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Set AURA_ADFS_TOKEN_ENDPOINT (e.g. https://idauatg2.jpmorganchase.com/adfs/oauth2/token) "
                "or AURA_C2C_TOKEN_ENDPOINT for ADFS client_credentials.",
            )
        if not resource:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Set resource in the request body or configure AURA_ADFS_RESOURCE_URI / AURA_IDA_RESOURCE_URI "
                "(JPMC:URI:RS-… audience so ADFS issues Role claims).",
            )
        scope = (payload.adfs_scope or "user_impersonation").strip() or "user_impersonation"
        form = {
            "grant_type": "client_credentials",
            "client_id": str(payload.client_id),
            "client_secret": str(payload.client_secret),
            "resource": resource,
            "scope": scope,
        }
        try:
            body = post_adfs_token(
                token_endpoint=token_url,
                form=form,
                timeout_seconds=settings.ADFS_HTTP_TIMEOUT_SECONDS,
                verify=tls_verify_for_adfs_requests(),
            )
        except TokenProvisionException as exc:
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc)) from exc
        access_token = str(body["access_token"])
        raw_exp = body.get("expires_in")
        expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
    elif isinstance(payload, AdfsPasswordAuthRequest):
        if settings.ENFORCE_IDA_TOKEN_OPTION_A:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=_IDA_OPTION_A_FORBIDDEN_DETAIL)
        if not settings.ALLOW_ADFS_PASSWORD_GRANT:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="adfs_password disabled. Set AURA_ALLOW_ADFS_PASSWORD_GRANT=1 (lab only).",
            )
        token_url = settings.ida_adfs_token_endpoint()
        resource = (payload.resource or settings.ida_client_credentials_resource_uri() or "").strip()
        if not token_url:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Set AURA_ADFS_TOKEN_ENDPOINT (or AURA_C2C_TOKEN_ENDPOINT).",
            )
        if not resource:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Set resource in body or AURA_ADFS_RESOURCE_URI / AURA_IDA_RESOURCE_URI.",
            )
        form = {
            "grant_type": "password",
            "client_id": str(payload.client_id),
            "username": str(payload.username),
            "password": str(payload.password),
            "resource": resource,
        }
        try:
            body = post_adfs_token(
                token_endpoint=token_url,
                form=form,
                timeout_seconds=settings.ADFS_HTTP_TIMEOUT_SECONDS,
                verify=tls_verify_for_adfs_requests(),
            )
        except TokenProvisionException as exc:
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc)) from exc
        access_token = str(body["access_token"])
        raw_exp = body.get("expires_in")
        expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
        scope = str(body.get("scope") or "openid")
    else:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Unsupported grant_type.")

    return AuthTokenResponse(
        success=True,
        data=AuthTokenData(
            access_token=access_token,
            token_type="Bearer",
            expires_in=expires_in,
            scope=scope,
        ),
        errors=[],
    )


@router.post("/auth/build-gci-subject-token", response_model=GciSubjectTokenBuildResponse)
def build_gci_subject_token_route(payload: GciSubjectTokenBuildRequest) -> GciSubjectTokenBuildResponse:
    if not settings.ALLOW_GCI_SUBJECT_TOKEN_BUILDER:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GCI builder is disabled. Set AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER=true to enable (dev only).",
        )
    access_key_id = payload.access_key_id
    secret_access_key = payload.secret_access_key
    session_token = payload.session_token

    if payload.credential_source == "aws_cli":
        if not settings.ALLOW_GCI_BUILDER_AWS_CLI_CREDS:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="credential_source=aws_cli is disabled. Set AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS=true or use static keys.",
            )
        try:
            access_key_id, secret_access_key, session_token = load_aws_cli_credentials(profile=payload.aws_profile)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    assert access_key_id is not None and secret_access_key is not None

    try:
        token = build_gci_subject_token(
            region=payload.region,
            audience=payload.audience,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            session_token=session_token,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    return GciSubjectTokenBuildResponse(
        success=True,
        data=GciSubjectTokenBuildData(subject_token=token),
        errors=[],
    )

