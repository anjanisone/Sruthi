# AURA API (FastAPI)

`pip install -r requirements.txt` → `uvicorn app.main:app --host 127.0.0.1 --port 8000` — copy `.env.example` to `.env`.
