# Step Functions definitions

## Files

| File | Description |
|------|-------------|
| `aura_minimal_pass.asl.json` | Minimal valid machine (Pass → Succeed). Smoke-test deployments. |
| `aura_ingest_routing.asl.json` | **Choice** state on `$.source` (`zip` \| `repo` \| `dynamo`) then labeled **Pass** states. Extend by replacing Pass with **Task** states (Lambda, SDK, HTTP invoke). |
| `aura_sdk_dynamodb_put.asl.json` | Example **AWS SDK** integration: `dynamodb:putItem`. Replace `TableName` with your table or pass `TableName.$` from input. |

## Deploy notes

1. **Substitutions**: ASL JSON uses fixed example ARNs and table names. In production, inject values via **CloudFormation `Fn::Sub`**, **SAM `DefinitionSubstitutions`**, or **CDK `JsonPath`** / string replace in CI.
2. **Calling the AURA HTTP API** from Step Functions: use **`arn:aws:states:::http:invoke`** with an **EventBridge API destination** connection (OAuth or API key), or invoke a **Lambda** that performs `requests` / `urllib` to this API (often simpler for mutual-TLS or custom headers).
3. **IAM**: Each SDK Task needs the corresponding IAM policy on the state machine role (for example `dynamodb:PutItem` on the table ARN).
4. **Lint**: Use AWS Toolkit for VS Code or `aws stepfunctions validate-state-machine-definition` where available.

## Execution input examples

See `parameters.example.json` in this directory for sample JSON passed to `StartExecution`.
