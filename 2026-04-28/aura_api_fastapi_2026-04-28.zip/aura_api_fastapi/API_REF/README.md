# API reference assets

This folder holds **deployment-oriented artifacts** that are not loaded by the Python app at runtime. Use them with **SAM, CloudFormation, CDK, or Terraform** when wiring AURA API into AWS.

| Path | Purpose |
|------|---------|
| `SCOPE_PUBLIC_API_FIRST_FOUR.md` | **Product scope:** which HTTP routes match architecture points 1–4 (ingest, auth, browse, job submit) vs deferred pipeline APIs. |
| `stepfunctions/` | Amazon States Language (ASL) state machine definitions. |
| `deploy/` | Snippets and notes for registering those definitions in AWS. |
| `http/AURA_API_ROUTES.md` | Quick map of HTTP routes (keep in sync when you add endpoints). |

After changing routes or payloads, update the ASL **Parameters** / **ResultSelector** examples and the routes markdown as needed.
