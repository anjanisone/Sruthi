# Public API scope: first four architecture points

This document fixes **what this HTTP API owns** versus what lives in **AWS platform services** (ALB, IAM, KMS, Step Functions, ECS workers).

## Mapping: architecture point → responsibility

| # | Architecture point | What the **HTTP API** should expose | What is **not** a REST concern on this service |
|---|-------------------|-------------------------------------|--------------------------------------------------|
| **1** | **Code ingestion** | Endpoints to get source into **S3** in a known layout and return stable **workspace identifiers** (`upload_id` / prefix). | Route 53, ALB, ECS placement, **KMS key policies** (configure on bucket/S3); server-side clone runs inside the API task today—acceptable until you move clone to **Lambda/Fargate** and keep only **presigned URL** upload APIs. |
| **2** | **Authentication / authorization** | **One** app-level contract: validate caller identity on each request (today: optional JWT via `AURA_REQUIRE_AUTH`; production: swap for **API Gateway authorizer**, **ALB OIDC**, or **IAM SigV4** in front of this app). | **ID Anywhere** integration, **IAM RBAC** for AWS resources, and **KMS** usage are **platform/IaC**—no need for dozens of custom routes; the API assumes the caller is already authorized at the edge. |
| **3** | **Code browsing** | **List** and **preview** (read) paths for a workspace **before** `POST /jobs`, so users can validate the tree. | Large-file streaming, virus scan, and **S3 GET authorization** may move to **presigned URLs**; the API can still expose metadata and short previews. |
| **4** | **Job submission** | **`POST /jobs`**: accept `upload_id` (or equivalent workspace reference), create **DynamoDB** job row (`SUBMITTED`), return `job_id`. **`GET /jobs/{job_id}`** (and minimal list) for status sourced from DynamoDB in production. **Trigger Step Functions** (from API or from DynamoDB Streams + Lambda—pick one pattern in IaC). | **Step Functions definition**, **ECS task** execution of phases 5–13, **Bedrock** calls, **PDF/HTML** generation—these stay **inside the state machine / worker**, not as growing surface area on this API. |

## Decision: which APIs to **create and keep** (v1 public contract)

Prioritize these **route families**; everything else is **secondary, mock, or deferred** until workers exist.

1. **Ingestion (point 1)**  
   - `POST /upload-zip/file`, `GET /upload-zip/{upload_id}/status`  
   - `POST /ingest/github-clone`, `POST /ingest/bitbucket-clone`, `POST /ingest/repo-clone`  
   - *Optional later:* presigned **PUT** to S3 for huge zips; same layout contract.

2. **Auth (point 2)**  
   - Keep a **single** token or session contract at the edge; app exposes **`POST /auth/token`** only for **dev/demo** unless product requires more.  
   - Production: prefer **no bespoke OAuth** in this repo—use **API Gateway + Cognito / ID Anywhere / ALB OIDC**.

3. **Browsing (point 3)**  
   - `GET /ingest/{upload_id}/files`  
   - `GET /ingest/{upload_id}/files/preview` (evolve implementation to read from S3, not stub text)

4. **Jobs (point 4)**  
   - `POST /jobs` — body must reference an **ingested workspace** (e.g. `upload_id`). Persist to **DynamoDB**, return `job_id`.  
   - `GET /jobs/{job_id}` — status from DynamoDB (replace in-memory demo in production).  
   - *Optional pre-flight:* `POST /jobs/estimate` and proceed/discard if product wants cost gating **before** submit.

## Explicitly **out of scope** for this API (later phases / other surfaces)

Do **not** expand the **public** REST surface for these; keep them in **workers + Step Functions** (or a separate “admin” service if needed):

- Static analysis through spec assembly and multi-format export (phases analogous to **5–12** in your deck).  
- **`POST /jobs/{id}/publish-to-kb`**, OpenSearch, RAG chat (separate product API if required).  
- **`PUT /jobs/{id}/rerun`**, chunk retry, diff, outputs—keep as **internal** or **v2** once the core four are stable and backed by DynamoDB + SFN.

Existing mock routes under `/jobs/*`, `/kb/*`, `/review/*` can remain for **contract demos**; treat them as **non-normative** until the pipeline is real.

## Step Functions touchpoint

Only **one** outbound integration is required for point **4**: **start execution** of the orchestration state machine (or enqueue to SQS/Lambda that starts it). That call belongs in the **`POST /jobs`** implementation path, not as a separate “SFN API” for operators.

## Summary

**Create and harden APIs for:** ingestion → browse → **submit job** + **read job status**, with **auth at the edge** and **DynamoDB** as the job source of truth.  

**Do not** use this service as the primary surface for deep pipeline control beyond that; use **Step Functions + workers** and keep this API the **thin front door** for points **1–4**.
