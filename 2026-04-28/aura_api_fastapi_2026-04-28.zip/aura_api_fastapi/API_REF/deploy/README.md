# Deploy snippets

## SAM (State machine from local ASL file)

Use `DefinitionUri` pointing at the ASL file in this repo (path relative to your SAM template). Example skeleton:

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31
Parameters:
  AuraApiBaseUrl:
    Type: String
    Default: https://your-api.example.com
Resources:
  AuraIngestRouter:
    Type: AWS::Serverless::StateMachine
    Properties:
      Name: aura-ingest-routing
      DefinitionUri: ../API_REF/stepfunctions/aura_ingest_routing.asl.json
      Policies:
        - AWSLambdaRole
```

Adjust paths and policies for your real **Task** states (Lambda ARNs, DynamoDB table ARNs, `states:InvokeHTTPEndpoint` if using HTTP invoke).

## Terraform

Use `aws_sfn_state_machine` with `definition = file("${path.module}/../API_REF/stepfunctions/aura_minimal_pass.asl.json")` or template the JSON with `templatefile()` for ARNs and URLs.

## Validating ASL

Use the AWS Console “Create state machine” → **Definition** paste, or your IAC pipeline’s Step Functions linter. Field names and `Resource` ARNs must match your region and account after substitution.
