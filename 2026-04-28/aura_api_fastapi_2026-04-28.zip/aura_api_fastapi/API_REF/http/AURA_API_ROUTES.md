# AURA HTTP route map (curated)

## v1 public scope (architecture points 1–4)

**Normative for production:** ingestion (`/upload-zip/*`, `/ingest/*-clone`), browsing (`/ingest/{upload_id}/files*`), job lifecycle entry (`POST /jobs`, `GET /jobs/{job_id}`), plus edge auth.  

**Non-normative / demo until workers land:** most other `/jobs/*`, `/kb/*`, `/review/*` (see `../SCOPE_PUBLIC_API_FIRST_FOUR.md`).

Base URL is your deployment (for example `https://host` or `http://127.0.0.1:8000`). Paths below are **prefix-absolute**.

When `AURA_REQUIRE_AUTH=1`, send header `Authorization: Bearer <jwt>` except on exempt paths (see `app/auth_middleware.py`).

## Meta and health

| Method | Path | Notes |
|--------|------|--------|
| GET | `/health` | Liveness. |
| GET | `/meta` | Deployment hints, proxy/Swagger notes, DynamoDB configured flag. |
| GET | `/docs`, `/redoc` | Swagger / ReDoc when CDN offline mode allows. |
| GET | `/openapi.json` | OpenAPI spec. |

## Auth

| Method | Path | Notes |
|--------|------|--------|
| POST | `/auth/token` | OAuth-shaped demo token. |
| POST | `/auth/build-gci-subject-token` | GCI subject token builder (when enabled). |

## Upload (S3)

| Method | Path | Notes |
|--------|------|--------|
| GET | `/upload-zip/ui` | Browser upload page. |
| POST | `/upload-zip/file` | Multipart field `file` (`.zip`). Expands to S3 `…/source/` + keeps zip under `…/input/`. |
| GET | `/upload-zip/{upload_id}/status` | Upload status. |

## Ingest

| Method | Path | Notes |
|--------|------|--------|
| POST | `/ingest/repo-clone` | JSON `RepoCloneRequest`. |
| POST | `/ingest/bitbucket-clone` | Same shape. |
| POST | `/ingest/github-clone` | Same shape. |
| POST | `/ingest/zip-clone` | Demo / stub workspace. |
| GET | `/ingest/{upload_id}/files` | List files (query `current_path`, `page`, `page_size`). |
| GET | `/ingest/{upload_id}/files/preview` | Query `path=…` (demo content). |

## DynamoDB (HTTP façade)

Requires `AURA_DYNAMODB_TABLE_NAME`. Optional `AURA_DYNAMODB_REGION`.

| Method | Path | Body |
|--------|------|------|
| POST | `/dynamodb/items` | `{"item": { … }}` PutItem. |
| POST | `/dynamodb/items/get` | `{"key": { … }}` GetItem. |
| POST | `/dynamodb/items/query` | `DynamoQueryRequest` JSON. |

## Jobs, KB, review

See `openapi.json` for full models: `/jobs/*`, `/kb/*`, `/review/*`, WebSocket `/ws/jobs/{job_id}`.

## Step Functions alignment

Orchestration that targets this API should use **Lambda** or **HTTP invoke** tasks pointed at the rows above, or native **AWS SDK** tasks for S3/DynamoDB where the API is not required.
