from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import time
import uuid
import zipfile
from pathlib import Path

from botocore.exceptions import BotoCoreError, ClientError, ConnectTimeoutError
from fastapi import APIRouter, File, HTTPException, UploadFile, status
from fastapi.responses import HTMLResponse

from .. import settings
from ..models import (
    UploadConfirmData,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..s3_workspace import aggregate_languages_from_tree, expand_zip_and_upload_to_s3
from ..state import STATE
from . import s3_presign

_READ_CHUNK = 1024 * 1024
_PROGRESS_LOG_INTERVAL_BYTES = 10 * 1024 * 1024
logger = logging.getLogger(__name__)


async def _close_upload_file(file: UploadFile) -> None:
    try:
        await file.close()
    except Exception:
        pass


router = APIRouter(prefix="/upload-zip", tags=["upload-zip"])
_UPLOAD_ZIP_UI_PATH = Path(__file__).with_name("upload_zip.html")


@router.get(
    "/ui",
    response_class=HTMLResponse,
    include_in_schema=False,
    summary="Browser page with Upload button",
)
def upload_zip_button_page() -> HTMLResponse:
    return HTMLResponse(_UPLOAD_ZIP_UI_PATH.read_text(encoding="utf-8"))


def _require_s3_bucket() -> str:
    if not settings.S3_BUCKET:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="S3 uploads are not configured. Set AURA_S3_BUCKET and AWS credentials with s3:PutObject on the upload prefix.",
        )
    return settings.S3_BUCKET


@router.post(
    "/file",
    response_model=UploadConfirmResponse,
    summary="Upload a .zip (multipart/form-data); server streams to S3",
)
async def upload_zip_file(
    file: UploadFile = File(..., description="Zip archive (.zip)"),
) -> UploadConfirmResponse:
    wall_t0 = time.perf_counter()
    bucket = _require_s3_bucket()
    raw_name = (file.filename or "").strip()
    if not raw_name.lower().endswith(".zip"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="filename must end with .zip",
        )
    try:
        safe_name = s3_presign.safe_object_basename(raw_name)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    upload_id = str(uuid.uuid4())
    key = s3_presign.build_upload_key(upload_id, safe_name)
    content_type = (file.content_type or "").strip() or "application/zip"

    tmp_path: str | None = None
    total = 0
    read_deadline = settings.UPLOAD_READ_CHUNK_TIMEOUT_SECONDS
    expand_deadline = settings.UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS
    logger.info(
        "upload_zip begin upload_id=%s safe_name=%s key=%s bucket=%s region=%s "
        "read_chunk_timeout_s=%s expand_s3_timeout_s=%s",
        upload_id,
        safe_name,
        key,
        bucket,
        settings.S3_REGION,
        read_deadline,
        expand_deadline,
    )
    try:
        # Writer is closed before S3 reads the path (required on Windows before reopening the same file).
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            tmp_path = tmp.name
            logger.info(
                "upload_zip disk_write_open upload_id=%s tmp_path=%s chunk_bytes=%s",
                upload_id,
                tmp_path,
                _READ_CHUNK,
            )
            next_progress_log = _PROGRESS_LOG_INTERVAL_BYTES
            chunk_index = 0
            while True:
                try:
                    block = await asyncio.wait_for(file.read(_READ_CHUNK), timeout=read_deadline)
                except asyncio.TimeoutError:
                    raise HTTPException(
                        status_code=status.HTTP_408_REQUEST_TIMEOUT,
                        detail=(
                            "Timed out waiting for the next part of the upload body. "
                            "If the browser never finishes sending, check VPN/proxy body limits, corporate SSL inspection, "
                            "or antivirus throttling large multipart POSTs (often seen on Windows)."
                        ),
                    ) from None
                if not block:
                    break
                chunk_index += 1
                total += len(block)
                if total > settings.S3_MAX_FILE_SIZE_BYTES:
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"file exceeds limit {settings.S3_MAX_FILE_SIZE_BYTES} bytes.",
                    )
                tmp.write(block)
                if total >= next_progress_log:
                    logger.info(
                        "upload_zip body_progress upload_id=%s bytes_received=%s chunks=%s elapsed_s=%.2f",
                        upload_id,
                        total,
                        chunk_index,
                        time.perf_counter() - wall_t0,
                    )
                    while next_progress_log <= total:
                        next_progress_log += _PROGRESS_LOG_INTERVAL_BYTES
            tmp.flush()

        logger.info(
            "upload_zip body_read_done upload_id=%s total_bytes=%s chunks=%s elapsed_s=%.2f",
            upload_id,
            total,
            chunk_index,
            time.perf_counter() - wall_t0,
        )

        if total == 0:
            logger.warning("upload_zip empty_body upload_id=%s", upload_id)
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="empty file.")

        zip_ok = zipfile.is_zipfile(tmp_path)
        logger.info("upload_zip zip_probe upload_id=%s is_zipfile=%s", upload_id, zip_ok)
        if not zip_ok:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="uploaded file is not a valid zip archive.",
            )

        logger.info(
            "upload_zip expand_put_scheduled upload_id=%s deadline_s=%s elapsed_before_s3_s=%.2f",
            upload_id,
            expand_deadline,
            time.perf_counter() - wall_t0,
        )
        try:
            fc, tb, extr_warn, tree, source_prefix, zsize = await asyncio.wait_for(
                asyncio.to_thread(
                    expand_zip_and_upload_to_s3,
                    upload_id=upload_id,
                    zip_path=tmp_path,
                    bucket=bucket,
                    input_key=key,
                    content_type=content_type,
                ),
                timeout=expand_deadline,
            )
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail=(
                    "Timed out while unzipping or uploading files to S3. "
                    "Increase AURA_UPLOAD_ZIP_EXPAND_S3_TIMEOUT_SECONDS for very large archives. "
                    "Also check AWS credentials, bucket region, proxy settings, and "
                    "AWS_EC2_METADATA_DISABLED=true on non-EC2 hosts."
                ),
            ) from None
    except HTTPException as exc:
        log_fn = logger.warning if exc.status_code >= 400 else logger.info
        log_fn(
            "upload_zip http_exception upload_id=%s status=%s detail=%s elapsed_s=%.2f",
            upload_id,
            exc.status_code,
            exc.detail,
            time.perf_counter() - wall_t0,
        )
        raise
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except (ClientError, BotoCoreError, OSError, RuntimeError) as exc:
        logger.exception(
            "upload_zip unexpected_error upload_id=%s elapsed_s=%.2f",
            upload_id,
            time.perf_counter() - wall_t0,
        )
        detail = f"S3 upload failed: {exc}"
        if isinstance(exc, ConnectTimeoutError):
            detail += (
                " (No route to S3: set HTTP_PROXY/HTTPS_PROXY/NO_PROXY in .env, or AURA_HTTP_PROXY/"
                "AURA_HTTPS_PROXY/AURA_NO_PROXY; see .env.example. Wrong proxy port is a common cause.)"
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=detail,
        ) from exc
    finally:
        await _close_upload_file(file)
        if tmp_path:
            try:
                os.unlink(tmp_path)
                logger.debug("upload_zip tmp_removed upload_id=%s path=%s", upload_id, tmp_path)
            except OSError as unlink_err:
                logger.warning(
                    "upload_zip tmp_unlink_failed upload_id=%s path=%s err=%s",
                    upload_id,
                    tmp_path,
                    unlink_err,
                )

    logger.info(
        "upload_zip success upload_id=%s total_bytes=%s total_elapsed_s=%.2f",
        upload_id,
        total,
        time.perf_counter() - wall_t0,
    )

    langs = aggregate_languages_from_tree(tree)
    warnings: list[str] = list(extr_warn)
    source_uri = f"s3://{bucket}/{source_prefix}"
    object_url = s3_presign.object_https_url(bucket, settings.S3_REGION, key)
    total_s3_bytes = zsize + tb
    STATE.ingest_file_trees[upload_id] = tree
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "upload_kind": "zip_expand",
        "file_count": fc,
        "total_size_bytes": total_s3_bytes,
        "detected_languages": langs,
        "s3_path": source_prefix,
        "s3_uri": source_uri,
        "object_url": object_url,
        "bucket": bucket,
        "key": key,
    }

    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=upload_id,
            status="VALIDATED",
            file_count=fc,
            total_size_bytes=total_s3_bytes,
            detected_languages=langs,
            validation_warnings=warnings,
            s3_path=source_prefix,
            s3_uri=source_uri,
            object_url=object_url,
        ),
        errors=[],
    )


@router.get(
    "/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Upload status for an upload_id returned by POST /upload-zip/file",
)
def zip_upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=str(record["status"]),
            file_count=int(record.get("file_count", 0)),
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", "")),
            s3_uri=str(record.get("s3_uri", "")),
            object_url=str(record.get("object_url", "")),
        ),
        errors=[],
    )
