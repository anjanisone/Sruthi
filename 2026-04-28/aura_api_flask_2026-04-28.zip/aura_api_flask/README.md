# AURA API (Flask)

`pip install -r requirements.txt` → `flask --app wsgi run --port 5000` — copy `.env.example` to `.env`.
