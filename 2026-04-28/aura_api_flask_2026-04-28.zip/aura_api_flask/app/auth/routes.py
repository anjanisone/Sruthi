from __future__ import annotations

from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from .. import settings
from ..aws_cli_credentials import load_aws_cli_credentials
from ..c2c_client import C2CError, exchange_with_c2c
from ..gci_build import build_gci_subject_token
from ..gci_sts import GciValidationError, claims_from_sts_identity, verify_aws_get_caller_identity_subject_token
from ..jwt_tokens import mint_access_token
from ..models import (
    AuthTokenData,
    AuthTokenRequest,
    AuthTokenResponse,
    GciSubjectTokenBuildData,
    GciSubjectTokenBuildRequest,
    GciSubjectTokenBuildResponse,
    GrantType,
)

bp = Blueprint("auth", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _http_status_for_c2c(err: C2CError) -> int:
    if err.http_status is None:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status >= 500:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status in (401, 403):
        return err.http_status
    if err.http_status == 400:
        return HTTPStatus.BAD_REQUEST
    return HTTPStatus.BAD_GATEWAY


def _use_c2c_for_token_exchange() -> bool:
    mode = settings.TOKEN_EXCHANGE_MODE
    if mode == "c2c":
        return True
    if mode == "local":
        return False
    return bool(settings.C2C_TOKEN_ENDPOINT)


@bp.post("/auth/token")
def auth_token():
    try:
        payload = AuthTokenRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY

    if payload.grant_type == GrantType.client_credentials:
        if payload.client_id != settings.CLIENT_ID or payload.client_secret != settings.CLIENT_SECRET:
            return jsonify({"detail": "Invalid client credentials."}), HTTPStatus.UNAUTHORIZED
        access_token, expires_in = mint_access_token(
            claims={"sub": f"client:{payload.client_id}", "auth_method": "client_credentials"},
        )
        scope = "read write"
    elif payload.grant_type == GrantType.token_exchange:
        if payload.subject_token_type not in settings.AWS_GET_CALLER_IDENTITY_TOKEN_TYPES:
            return jsonify({"detail": "Unsupported subject_token_type for this server."}), HTTPStatus.BAD_REQUEST
        assert payload.audience is not None and payload.subject_token is not None

        use_c2c = _use_c2c_for_token_exchange()
        if settings.TOKEN_EXCHANGE_MODE == "c2c" and not settings.C2C_TOKEN_ENDPOINT:
            return (
                jsonify({"detail": "Token exchange is configured for C2C but AURA_C2C_TOKEN_ENDPOINT is not set."}),
                HTTPStatus.SERVICE_UNAVAILABLE,
            )

        if use_c2c:
            try:
                body = exchange_with_c2c(
                    audience=payload.audience,
                    subject_token=payload.subject_token,
                    subject_token_type=payload.subject_token_type,
                )
            except C2CError as exc:
                return jsonify({"detail": str(exc)}), _http_status_for_c2c(exc)
            access_token = str(body["access_token"])
            raw_exp = body.get("expires_in")
            expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
            scope = str(body.get("scope") or "read write")
        else:
            try:
                identity = verify_aws_get_caller_identity_subject_token(payload.subject_token)
            except GciValidationError as exc:
                return jsonify({"detail": str(exc)}), HTTPStatus.UNAUTHORIZED
            claims, scope = claims_from_sts_identity(identity, audience=payload.audience)
            access_token, expires_in = mint_access_token(claims=claims, scope=scope)
    else:
        return jsonify({"detail": "Unsupported grant_type."}), HTTPStatus.BAD_REQUEST

    return _j(
        AuthTokenResponse(
            success=True,
            data=AuthTokenData(
                access_token=access_token,
                token_type="Bearer",
                expires_in=expires_in,
                scope=scope,
            ),
            errors=[],
        )
    )


@bp.post("/auth/build-gci-subject-token")
def build_gci_subject_token_route():
    if not settings.ALLOW_GCI_SUBJECT_TOKEN_BUILDER:
        return (
            jsonify(
                {
                    "detail": "GCI builder is disabled. Set AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER=true to enable (dev only)."
                }
            ),
            HTTPStatus.NOT_FOUND,
        )
    try:
        payload = GciSubjectTokenBuildRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY

    access_key_id = payload.access_key_id
    secret_access_key = payload.secret_access_key
    session_token = payload.session_token

    if payload.credential_source == "aws_cli":
        if not settings.ALLOW_GCI_BUILDER_AWS_CLI_CREDS:
            return (
                jsonify(
                    {
                        "detail": "credential_source=aws_cli is disabled. Set AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS=true or use static keys."
                    }
                ),
                HTTPStatus.FORBIDDEN,
            )
        try:
            access_key_id, secret_access_key, session_token = load_aws_cli_credentials(profile=payload.aws_profile)
        except ValueError as exc:
            return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST

    if not access_key_id or not secret_access_key:
        return jsonify({"detail": "access_key_id and secret_access_key are required for static credentials."}), HTTPStatus.BAD_REQUEST

    try:
        token = build_gci_subject_token(
            region=payload.region,
            audience=payload.audience,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            session_token=session_token,
        )
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST
    return _j(
        GciSubjectTokenBuildResponse(
            success=True,
            data=GciSubjectTokenBuildData(subject_token=token),
            errors=[],
        )
    )

