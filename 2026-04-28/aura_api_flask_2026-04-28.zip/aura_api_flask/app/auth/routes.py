from __future__ import annotations

from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from .. import settings
from ..aws_cli_credentials import load_aws_cli_credentials
from ..c2c_client import C2CError, exchange_with_c2c, tls_verify_for_adfs_requests
from ..gci_build import build_gci_subject_token
from ..gci_sts import GciValidationError, claims_from_sts_identity, verify_aws_get_caller_identity_subject_token
from ..jwt_tokens import mint_access_token
from ..outbound.adfs_client import post_adfs_token
from ..outbound.token_provision import TokenProvisionException
from ..models import (
    AdfsClientCredentialsAuthRequest,
    AdfsPasswordAuthRequest,
    AuthTokenData,
    AuthTokenRequest,
    AuthTokenResponse,
    ClientCredentialsAuthRequest,
    GciSubjectTokenBuildData,
    GciSubjectTokenBuildRequest,
    GciSubjectTokenBuildResponse,
    TokenExchangeAuthRequest,
)

bp = Blueprint("auth", __name__)

_IDA_OPTION_A_FORBIDDEN_DETAIL = (
    "adfs_client_credentials disabled (AURA_ENFORCE_IDA_TOKEN_OPTION_A). "
    "Use IDA Bearer, or set AURA_ENFORCE_IDA_TOKEN_OPTION_A=0 for lab."
)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _http_status_for_c2c(err: C2CError) -> int:
    if err.http_status is None:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status >= 500:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status in (401, 403):
        return err.http_status
    if err.http_status == 400:
        return HTTPStatus.BAD_REQUEST
    return HTTPStatus.BAD_GATEWAY


def _use_c2c_for_token_exchange() -> bool:
    mode = settings.TOKEN_EXCHANGE_MODE
    if mode == "c2c":
        return True
    if mode == "local":
        return False
    return bool(settings.C2C_TOKEN_ENDPOINT)


@bp.post("/auth/token")
def auth_token():
    try:
        payload = AuthTokenRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY

    if isinstance(payload, ClientCredentialsAuthRequest):
        if settings.ALLOW_CLIENT_CREDENTIALS_NO_SECRET:
            if payload.client_id != settings.CLIENT_ID:
                return jsonify({"detail": "client_id must match AURA_CLIENT_ID (no-secret dev mode)."}), HTTPStatus.UNAUTHORIZED
        else:
            if (payload.client_secret or "") != settings.CLIENT_SECRET or payload.client_id != settings.CLIENT_ID:
                return (
                    jsonify(
                        {
                            "detail": "Bad client_id/client_secret, or set AURA_ALLOW_CLIENT_CREDENTIALS_NO_SECRET=1.",
                        }
                    ),
                    HTTPStatus.UNAUTHORIZED,
                )
        access_token, expires_in = mint_access_token(
            claims={"sub": f"client:{payload.client_id}", "auth_method": "client_credentials"},
        )
        scope = "read write"
    elif isinstance(payload, TokenExchangeAuthRequest):
        if payload.subject_token_type not in settings.AWS_GET_CALLER_IDENTITY_TOKEN_TYPES:
            return jsonify({"detail": "Unsupported subject_token_type for this server."}), HTTPStatus.BAD_REQUEST
        use_c2c = _use_c2c_for_token_exchange()
        if settings.TOKEN_EXCHANGE_MODE == "c2c" and not settings.C2C_TOKEN_ENDPOINT:
            return (
                jsonify({"detail": "Token exchange is configured for C2C but AURA_C2C_TOKEN_ENDPOINT is not set."}),
                HTTPStatus.SERVICE_UNAVAILABLE,
            )

        if use_c2c:
            try:
                body = exchange_with_c2c(
                    audience=payload.audience,
                    subject_token=payload.subject_token,
                    subject_token_type=payload.subject_token_type,
                )
            except C2CError as exc:
                return jsonify({"detail": str(exc)}), _http_status_for_c2c(exc)
            access_token = str(body["access_token"])
            raw_exp = body.get("expires_in")
            expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
            scope = str(body.get("scope") or "read write")
        else:
            try:
                identity = verify_aws_get_caller_identity_subject_token(payload.subject_token)
            except GciValidationError as exc:
                return jsonify({"detail": str(exc)}), HTTPStatus.UNAUTHORIZED
            claims, scope = claims_from_sts_identity(identity, audience=payload.audience)
            access_token, expires_in = mint_access_token(claims=claims, scope=scope)
    elif isinstance(payload, AdfsClientCredentialsAuthRequest):
        if settings.ENFORCE_IDA_TOKEN_OPTION_A:
            return jsonify({"detail": _IDA_OPTION_A_FORBIDDEN_DETAIL}), HTTPStatus.FORBIDDEN
        token_url = settings.ida_adfs_token_endpoint()
        resource = (payload.resource or settings.ida_client_credentials_resource_uri() or "").strip()
        if not token_url:
            return (
                jsonify(
                    {
                        "detail": "Set AURA_ADFS_TOKEN_ENDPOINT (e.g. https://idauatg2.jpmorganchase.com/adfs/oauth2/token) "
                        "or AURA_C2C_TOKEN_ENDPOINT."
                    }
                ),
                HTTPStatus.SERVICE_UNAVAILABLE,
            )
        if not resource:
            return (
                jsonify(
                    {
                        "detail": "Set resource in the body or AURA_ADFS_RESOURCE_URI / AURA_IDA_RESOURCE_URI "
                        "(JPMC:URI:RS-… so ADFS issues Role claims)."
                    }
                ),
                HTTPStatus.SERVICE_UNAVAILABLE,
            )
        scope = (payload.adfs_scope or "user_impersonation").strip() or "user_impersonation"
        form = {
            "grant_type": "client_credentials",
            "client_id": str(payload.client_id),
            "client_secret": str(payload.client_secret),
            "resource": resource,
            "scope": scope,
        }
        try:
            body = post_adfs_token(
                token_endpoint=token_url,
                form=form,
                timeout_seconds=settings.ADFS_HTTP_TIMEOUT_SECONDS,
                verify=tls_verify_for_adfs_requests(),
            )
        except TokenProvisionException as exc:
            return jsonify({"detail": str(exc)}), HTTPStatus.BAD_GATEWAY
        access_token = str(body["access_token"])
        raw_exp = body.get("expires_in")
        expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
    elif isinstance(payload, AdfsPasswordAuthRequest):
        if settings.ENFORCE_IDA_TOKEN_OPTION_A:
            return jsonify({"detail": _IDA_OPTION_A_FORBIDDEN_DETAIL}), HTTPStatus.FORBIDDEN
        if not settings.ALLOW_ADFS_PASSWORD_GRANT:
            return (
                jsonify({"detail": "adfs_password disabled. Set AURA_ALLOW_ADFS_PASSWORD_GRANT=1 (lab only)."}),
                HTTPStatus.FORBIDDEN,
            )
        token_url = settings.ida_adfs_token_endpoint()
        resource = (payload.resource or settings.ida_client_credentials_resource_uri() or "").strip()
        if not token_url:
            return jsonify({"detail": "Set AURA_ADFS_TOKEN_ENDPOINT or AURA_C2C_TOKEN_ENDPOINT."}), HTTPStatus.SERVICE_UNAVAILABLE
        if not resource:
            return (
                jsonify({"detail": "Set resource in body or AURA_ADFS_RESOURCE_URI / AURA_IDA_RESOURCE_URI."}),
                HTTPStatus.SERVICE_UNAVAILABLE,
            )
        form = {
            "grant_type": "password",
            "client_id": str(payload.client_id),
            "username": str(payload.username),
            "password": str(payload.password),
            "resource": resource,
        }
        try:
            body = post_adfs_token(
                token_endpoint=token_url,
                form=form,
                timeout_seconds=settings.ADFS_HTTP_TIMEOUT_SECONDS,
                verify=tls_verify_for_adfs_requests(),
            )
        except TokenProvisionException as exc:
            return jsonify({"detail": str(exc)}), HTTPStatus.BAD_GATEWAY
        access_token = str(body["access_token"])
        raw_exp = body.get("expires_in")
        expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
        scope = str(body.get("scope") or "openid")
    else:
        return jsonify({"detail": "Unsupported grant_type."}), HTTPStatus.BAD_REQUEST

    return _j(
        AuthTokenResponse(
            success=True,
            data=AuthTokenData(
                access_token=access_token,
                token_type="Bearer",
                expires_in=expires_in,
                scope=scope,
            ),
            errors=[],
        )
    )


@bp.post("/auth/build-gci-subject-token")
def build_gci_subject_token_route():
    if not settings.ALLOW_GCI_SUBJECT_TOKEN_BUILDER:
        return (
            jsonify(
                {
                    "detail": "GCI builder is disabled. Set AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER=true to enable (dev only)."
                }
            ),
            HTTPStatus.NOT_FOUND,
        )
    try:
        payload = GciSubjectTokenBuildRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY

    access_key_id = payload.access_key_id
    secret_access_key = payload.secret_access_key
    session_token = payload.session_token

    if payload.credential_source == "aws_cli":
        if not settings.ALLOW_GCI_BUILDER_AWS_CLI_CREDS:
            return (
                jsonify(
                    {
                        "detail": "credential_source=aws_cli is disabled. Set AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS=true or use static keys."
                    }
                ),
                HTTPStatus.FORBIDDEN,
            )
        try:
            access_key_id, secret_access_key, session_token = load_aws_cli_credentials(profile=payload.aws_profile)
        except ValueError as exc:
            return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST

    if not access_key_id or not secret_access_key:
        return jsonify({"detail": "access_key_id and secret_access_key are required for static credentials."}), HTTPStatus.BAD_REQUEST

    try:
        token = build_gci_subject_token(
            region=payload.region,
            audience=payload.audience,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            session_token=session_token,
        )
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST
    return _j(
        GciSubjectTokenBuildResponse(
            success=True,
            data=GciSubjectTokenBuildData(subject_token=token),
            errors=[],
        )
    )

