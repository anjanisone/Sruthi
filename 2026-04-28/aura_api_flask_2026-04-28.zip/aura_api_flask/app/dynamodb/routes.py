from __future__ import annotations

import logging
from http import HTTPStatus

from botocore.exceptions import BotoCoreError, ClientError
from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    DynamoGetItemData,
    DynamoGetItemRequest,
    DynamoGetItemResponse,
    DynamoPutItemData,
    DynamoPutItemRequest,
    DynamoPutItemResponse,
    DynamoQueryData,
    DynamoQueryRequest,
    DynamoQueryResponse,
)
from . import ddb

logger = logging.getLogger(__name__)

bp = Blueprint("dynamodb", __name__, url_prefix="/dynamodb")


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _from_client_error(exc: ClientError) -> tuple[dict, int]:
    code, detail = ddb.translate_client_error(exc)
    return jsonify({"detail": detail}), code


@bp.post("/items")
def dynamodb_put_item():
    try:
        payload = DynamoPutItemRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    try:
        ddb.put_item(item=dict(payload.item))
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.SERVICE_UNAVAILABLE
    except ClientError as exc:
        body, status = _from_client_error(exc)
        return body, status
    except BotoCoreError as exc:
        logger.exception("dynamodb PutItem boto core error")
        return jsonify({"detail": f"DynamoDB request failed: {exc}"}), HTTPStatus.SERVICE_UNAVAILABLE
    return _j(DynamoPutItemResponse(success=True, data=DynamoPutItemData(ok=True), errors=[]))


@bp.post("/items/get")
def dynamodb_get_item():
    try:
        payload = DynamoGetItemRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    try:
        item = ddb.get_item(key=dict(payload.key))
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.SERVICE_UNAVAILABLE
    except ClientError as exc:
        body, status = _from_client_error(exc)
        return body, status
    except BotoCoreError as exc:
        logger.exception("dynamodb GetItem boto core error")
        return jsonify({"detail": f"DynamoDB request failed: {exc}"}), HTTPStatus.SERVICE_UNAVAILABLE
    return _j(
        DynamoGetItemResponse(
            success=True,
            data=DynamoGetItemData(item=item, found=item is not None),
            errors=[],
        )
    )


@bp.post("/items/query")
def dynamodb_query():
    try:
        payload = DynamoQueryRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    try:
        items, lek = ddb.query_by_partition_key(
            partition_key_attr=payload.partition_key_attr,
            partition_key_value=payload.partition_key_value,
            sort_key_attr=payload.sort_key_attr,
            sort_key_value=payload.sort_key_value,
            limit=payload.limit,
            scan_index_forward=payload.scan_index_forward,
        )
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.SERVICE_UNAVAILABLE
    except ClientError as exc:
        body, status = _from_client_error(exc)
        return body, status
    except BotoCoreError as exc:
        logger.exception("dynamodb Query boto core error")
        return jsonify({"detail": f"DynamoDB request failed: {exc}"}), HTTPStatus.SERVICE_UNAVAILABLE
    return _j(
        DynamoQueryResponse(
            success=True,
            data=DynamoQueryData(items=items, count=len(items), last_evaluated_key=lek),
            errors=[],
        )
    )
