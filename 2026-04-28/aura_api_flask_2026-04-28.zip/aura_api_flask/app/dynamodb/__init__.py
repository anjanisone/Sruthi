"""DynamoDB HTTP routes live in ``app.dynamodb.routes``."""
