from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class Meta(BaseModel):
    request_id: str = Field(examples=["uuid"])
    timestamp: datetime = Field(default_factory=lambda: datetime.utcnow())


class ErrorCode(str, Enum):
    VALIDATION_ERROR = "VALIDATION_ERROR"
    AUTHENTICATION_REQUIRED = "AUTHENTICATION_REQUIRED"
    FORBIDDEN = "FORBIDDEN"
    NOT_FOUND = "NOT_FOUND"
    JOB_NOT_RESUMABLE = "JOB_NOT_RESUMABLE"
    ESTIMATE_EXPIRED = "ESTIMATE_EXPIRED"
    RATE_LIMITED = "RATE_LIMITED"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    BEDROCK_ERROR = "BEDROCK_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"


class ApiError(BaseModel):
    code: ErrorCode
    message: str
    details: Optional[Dict[str, Any]] = None


class Envelope(BaseModel):
    success: bool = True
    data: Dict[str, Any] = Field(default_factory=dict)
    meta: Meta = Field(default_factory=lambda: Meta(request_id="uuid"))
    errors: List[ApiError] = Field(default_factory=list)


class GrantType(str, Enum):
    client_credentials = "client_credentials"
    token_exchange = "urn:ietf:params:oauth:grant-type:token-exchange"


class AuthTokenRequest(BaseModel):
    grant_type: GrantType = GrantType.client_credentials
    client_id: str | None = Field(default=None, examples=["aura-demo-client"])
    client_secret: str | None = Field(default=None, examples=["aura-demo-secret"])
    audience: str | None = Field(default=None, examples=["https://api.example.com/"])
    subject_token: str | None = Field(default=None)
    subject_token_type: str | None = Field(
        default=None,
        examples=["urn:jpmc:params:identity:token-type:aws-get-caller-identity"],
    )

    @model_validator(mode="after")
    def validate_grant_payload(self) -> "AuthTokenRequest":
        if self.grant_type == GrantType.client_credentials:
            if not self.client_id or not self.client_secret:
                raise ValueError("client_id and client_secret are required for client_credentials.")
        elif self.grant_type == GrantType.token_exchange:
            if not self.audience or not self.subject_token or not self.subject_token_type:
                raise ValueError(
                    "audience, subject_token, and subject_token_type are required for token_exchange."
                )
        return self


class AuthTokenData(BaseModel):
    access_token: str = Field(examples=["jwt_token"])
    token_type: Literal["Bearer"] = "Bearer"
    expires_in: int = Field(examples=[3600])
    scope: str = Field(examples=["read write"])


class AuthTokenResponse(Envelope):
    data: AuthTokenData


class GciSubjectTokenBuildRequest(BaseModel):
    region: str = Field(examples=["us-east-1"])
    audience: str = Field(examples=["https://api.example.com/"])
    credential_source: Literal["static", "aws_cli"] = Field(default="static")
    aws_profile: str | None = Field(default=None)
    access_key_id: str | None = Field(default=None, examples=["AKIA..."])
    secret_access_key: str | None = Field(default=None, examples=["..."])
    session_token: str | None = Field(default=None)

    @model_validator(mode="after")
    def validate_gci_builder_credentials(self) -> "GciSubjectTokenBuildRequest":
        if self.credential_source == "static":
            if not self.access_key_id or not self.secret_access_key:
                raise ValueError("access_key_id and secret_access_key are required when credential_source is static.")
        return self


class GciSubjectTokenBuildData(BaseModel):
    subject_token: str
    subject_token_type_hint: str = Field(
        default="urn:jpmc:params:identity:token-type:aws-get-caller-identity",
    )


class GciSubjectTokenBuildResponse(Envelope):
    data: GciSubjectTokenBuildData


class UploadConfirmData(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["VALIDATED"])
    file_count: int = Field(examples=[150])
    total_size_bytes: int = Field(default=0, examples=[52428800])
    detected_languages: Dict[str, int] = Field(default_factory=dict, examples=[{"java": 80, "python": 50}])
    validation_warnings: List[str] = Field(default_factory=list, examples=[["Skipped empty files"]])
    s3_path: str = Field(
        default="",
        description="Primary workspace: S3 prefix for extracted files (…/source/). The original .zip is also stored under …/input/.",
    )
    s3_uri: str = Field(default="", examples=["s3://my-bucket/jobs/.../uuid/source/"])
    object_url: str = Field(
        default="",
        description="HTTPS URL of the object (GET may require public read or a separate pre-signed GET).",
    )


class UploadConfirmResponse(Envelope):
    data: UploadConfirmData


class RepoCloneRequest(BaseModel):
    repository_url: str = Field(examples=["https://bitbucket.org/org/repo"])
    branch: str = Field(default="main", examples=["main"])
    username: Optional[str] = Field(default=None, examples=["user"])
    app_password: Optional[str] = Field(default=None, examples=["app_password"])
    access_token: Optional[str] = Field(default=None, examples=["ghp_xxxx"])
    include_paths: List[str] = Field(default_factory=list, examples=[["src/"]])
    exclude_paths: List[str] = Field(default_factory=list, examples=[["vendor/"]])


class RepoCloneData(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["CLONING"])
    estimated_time_seconds: int = Field(default=0, examples=[120])
    file_count: int = Field(default=0, description="Files uploaded to S3 under s3_prefix.")
    total_size_bytes: int = Field(default=0, description="Total bytes uploaded to S3.")
    s3_prefix: str = Field(default="", description="S3 prefix for cloned tree, e.g. jobs/{upload_id}/source/")
    s3_uri: str = Field(default="", examples=["s3://my-bucket/jobs/uuid/source/"])


class RepoCloneResponse(Envelope):
    data: RepoCloneData


class ZipCloneRequest(BaseModel):
    file_name: str = Field(examples=["repository.zip"])
    file_size_bytes: int = Field(default=0, examples=[52428800])
    content_type: str = Field(default="application/zip", examples=["application/zip"])


class UploadStatusData(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["COMPLETED"])
    file_count: int = Field(examples=[150])
    total_size_bytes: int = Field(default=0, examples=[52428800])
    detected_languages: Dict[str, int] = Field(default_factory=dict, examples=[{"java": 80, "python": 50}])
    s3_path: str = Field(
        default="",
        examples=["jobs/{upload_id}/source/"],
        description="S3 prefix for extracted tree; see object_url for the uploaded .zip object.",
    )
    s3_uri: str = Field(default="", examples=["s3://my-bucket/jobs/.../source/"])
    object_url: str = Field(
        default="",
        examples=["https://my-bucket.s3.us-east-1.amazonaws.com/.../input/project.zip"],
        description="HTTPS URL for the original .zip under …/input/ (GET may require auth).",
    )


class UploadStatusResponse(Envelope):
    data: UploadStatusData


class DynamoPutItemRequest(BaseModel):
    item: Dict[str, Any] = Field(
        ...,
        description="Full DynamoDB item (must include the table's key attributes). Uses boto3 high-level types.",
    )


class DynamoPutItemData(BaseModel):
    ok: bool = True


class DynamoPutItemResponse(Envelope):
    data: DynamoPutItemData


class DynamoGetItemRequest(BaseModel):
    key: Dict[str, Any] = Field(..., description="Primary key only, e.g. {\"pk\": \"x\"} or {\"pk\": \"x\", \"sk\": \"y\"}.")


class DynamoGetItemData(BaseModel):
    item: Optional[Dict[str, Any]] = None
    found: bool = False


class DynamoGetItemResponse(Envelope):
    data: DynamoGetItemData


class DynamoQueryRequest(BaseModel):
    partition_key_attr: str = Field(..., examples=["pk"])
    partition_key_value: Any = Field(..., examples=["partition-value"])
    sort_key_attr: Optional[str] = Field(default=None, examples=["sk"])
    sort_key_value: Any = Field(default=None, examples=["sort-value"])
    limit: int = Field(default=100, ge=1, le=1000)
    scan_index_forward: bool = True


class DynamoQueryData(BaseModel):
    items: List[Dict[str, Any]] = Field(default_factory=list)
    count: int = 0
    last_evaluated_key: Optional[Dict[str, Any]] = None


class DynamoQueryResponse(Envelope):
    data: DynamoQueryData


class ListJobsQuerySortBy(str, Enum):
    created_at = "created_at"
    updated_at = "updated_at"
    status = "status"


class SortOrder(str, Enum):
    asc = "asc"
    desc = "desc"


class JobSummary(BaseModel):
    job_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    job_name: str = Field(examples=["My Job"])
    status: str = Field(examples=["COMPLETED"])
    phase_completed: int = Field(examples=[6])
    created_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    updated_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    tags: List[str] = Field(default_factory=list, examples=[["demo"]])


class Pagination(BaseModel):
    page: int = 1
    page_size: int = 50
    total_items: int = 0
    total_pages: int = 0


class ListJobsData(BaseModel):
    jobs: List[JobSummary] = Field(default_factory=list)
    pagination: Pagination = Field(default_factory=Pagination)


class ListJobsResponse(Envelope):
    data: ListJobsData


class DeleteJobData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    previous_status: str = Field(examples=["RUNNING"])
    new_status: str = Field(examples=["CANCELLED"])
    cleanup_scheduled: bool = Field(default=True, examples=[True])


class DeleteJobResponse(Envelope):
    data: DeleteJobData


class EstimateConfig(BaseModel):
    selected_paths: List[str] = Field(default_factory=list, examples=[["src/"]])
    excluded_paths: List[str] = Field(default_factory=list, examples=[["tests/"]])
    languages: List[str] = Field(default_factory=list, examples=[["java", "python"]])


class JobsEstimateRequest(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    config: EstimateConfig


class CostEstimateBreakdown(BaseModel):
    phase_4_input_cost: Optional[float] = Field(default=None, examples=[1.0])
    phase_4_output_cost: Optional[float] = Field(default=None, examples=[1.0])


class CostEstimate(BaseModel):
    bedrock_input_tokens: int = Field(examples=[125000])
    bedrock_output_tokens: int = Field(examples=[75000])
    estimated_cost_usd: float = Field(examples=[2.45])
    pricing_model: str = Field(examples=["claude-3-sonnet"])
    breakdown: Optional[CostEstimateBreakdown] = None


class Estimation(BaseModel):
    total_files: int = Field(examples=[150])
    total_lines: int = Field(examples=[45000])
    total_tokens: int = Field(examples=[125000])
    estimated_chunks: int = Field(examples=[25])
    oversized_files: int = Field(examples=[3])
    languages_detected: Dict[str, int] = Field(default_factory=dict, examples=[{"java": 80, "python": 50}])


class TimeEstimate(BaseModel):
    estimated_duration_minutes: int = Field(examples=[15])
    phase_breakdown: Dict[str, int] = Field(default_factory=dict, examples=[{"phase_1": 1, "phase_4": 10}])


class JobsEstimateData(BaseModel):
    estimate_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["ESTIMATED"])
    estimation: Estimation
    cost_estimate: CostEstimate
    time_estimate: TimeEstimate
    phase_1_output_path: Optional[str] = Field(default=None, examples=["jobs/{estimate_id}/phase1/"])
    expires_at: datetime = Field(default_factory=lambda: datetime.utcnow(), examples=[])


class JobsEstimateResponse(Envelope):
    data: JobsEstimateData


class ProceedNotifications(BaseModel):
    notify_on_complete: bool = Field(default=False, examples=[True])
    email: Optional[str] = Field(default=None, examples=["user@company.com"])


class ProceedFromEstimateRequest(BaseModel):
    output_formats: List[str] = Field(default_factory=list, examples=[["pdf", "html", "markdown"]])
    stop_after_phase: Optional[int] = Field(default=None, examples=[None])
    notifications: Optional[ProceedNotifications] = None


class ProceedFromEstimateData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["RUNNING"])
    starting_phase: int = Field(examples=[2])
    skipped_phases: List[int] = Field(default_factory=list, examples=[[1]])
    message: str = Field(
        examples=["Job started from Phase 2 (Phase 1 results reused from estimation)"]
    )


class ProceedFromEstimateResponse(Envelope):
    data: ProceedFromEstimateData


class DiscardEstimateData(BaseModel):
    estimate_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["DISCARDED"])
    cleanup_completed: bool = Field(examples=[True])


class DiscardEstimateResponse(Envelope):
    data: DiscardEstimateData


class RerunType(str, Enum):
    failed_chunks_only = "failed_chunks_only"
    specific_chunks = "specific_chunks"
    from_phase = "from_phase"
    full_rerun = "full_rerun"


class RerunOptions(BaseModel):
    chunk_ids: Optional[List[str]] = Field(default=None, examples=[["chunk_7", "chunk_12"]])
    from_phase: Optional[int] = Field(default=None, examples=[4])
    full_rerun: Optional[bool] = Field(default=None, examples=[False])


class JobRerunRequest(BaseModel):
    rerun_type: RerunType
    options: RerunOptions


class JobRerunData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    rerun_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["RUNNING"])
    rerun_type: RerunType = Field(examples=[RerunType.failed_chunks_only])
    chunks_to_retry: List[str] = Field(default_factory=list, examples=[["chunk_7", "chunk_12"]])
    chunks_from_cache: List[str] = Field(default_factory=list, examples=[["chunk_1", "chunk_2", "..."]])
    starting_phase: int = Field(examples=[4])


class JobRerunResponse(Envelope):
    data: JobRerunData


class ChunkStatusItem(BaseModel):
    chunk_id: str = Field(examples=["chunk_1"])
    status: str = Field(examples=["SUCCESS"])
    files: List[str] = Field(default_factory=list, examples=[["UserController.java", "UserService.java"]])
    token_count: Optional[int] = Field(default=None, examples=[12345])
    processed_at: Optional[datetime] = None
    duration_seconds: Optional[int] = Field(default=None, examples=[42])
    cache_path: Optional[str] = Field(default=None, examples=["jobs/{job_id}/cache/chunk_1.json"])
    error: Optional[str] = Field(default=None, examples=["Bedrock timeout after 3 retries"])
    retry_count: Optional[int] = Field(default=None, examples=[3])
    last_attempt_at: Optional[datetime] = None


class ChunkSummary(BaseModel):
    success: int = 0
    failed: int = 0
    permanently_failed: int = 0
    in_progress: int = 0


class JobChunksData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    total_chunks: int = Field(examples=[25])
    chunk_statuses: List[ChunkStatusItem] = Field(default_factory=list)
    summary: Optional[ChunkSummary] = None


class JobChunksResponse(Envelope):
    data: JobChunksData


class RetryChunksRequest(BaseModel):
    chunk_ids: List[str] = Field(examples=[["chunk_7", "chunk_12"]])
    reset_retry_count: bool = Field(default=False, examples=[True])


class RetryChunksData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    chunks_queued: List[str] = Field(default_factory=list, examples=[["chunk_7", "chunk_12"]])
    status: str = Field(examples=["RETRYING"])


class RetryChunksResponse(Envelope):
    data: RetryChunksData


class ChangeDetectionRequest(BaseModel):
    compare_with_job_id: str = Field(examples=["previous_job_uuid"])


class ChangeSummary(BaseModel):
    files_added: int = Field(examples=[5])
    files_modified: int = Field(examples=[12])
    files_deleted: int = Field(examples=[3])
    total_affected_chunks: int = Field(examples=[8])


class ChangedFile(BaseModel):
    path: str = Field(examples=["src/api/UserController.java"])
    change_type: str = Field(examples=["modified"])
    lines_changed: Optional[int] = Field(default=None, examples=[42])


class ChangeDetectionData(BaseModel):
    current_job_id: str = Field(examples=["uuid"])
    previous_job_id: str = Field(examples=["previous_uuid"])
    changes_detected: bool = Field(examples=[True])
    change_summary: ChangeSummary
    changed_files: List[ChangedFile] = Field(default_factory=list)
    recommendation: str = Field(default="", examples=["Proceed with incremental run"])
    reason: str = Field(default="", examples=["12 files changed affecting 8 chunks"])


class ChangeDetectionResponse(Envelope):
    data: ChangeDetectionData


class JobDiffFormat(str, Enum):
    summary = "summary"
    detailed = "detailed"


class DiffSummary(BaseModel):
    specs_added: int = Field(examples=[5])
    specs_modified: int = Field(examples=[12])
    specs_deleted: int = Field(examples=[3])


class DetailedChange(BaseModel):
    file: str = Field(examples=["UserController.md"])
    change_type: str = Field(examples=["modified"])
    sections_changed: List[str] = Field(default_factory=list, examples=[["API Endpoints", "Dependencies"]])
    diff_preview: str = Field(examples=["- old\n+ new"])


class JobDiffData(BaseModel):
    current_job_id: str = Field(examples=["uuid"])
    previous_job_id: str = Field(examples=["previous_uuid"])
    generated_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    diff_summary: DiffSummary
    detailed_changes: Optional[List[DetailedChange]] = None


class JobDiffResponse(Envelope):
    data: JobDiffData


class ReviewSpecItem(BaseModel):
    file_path: str = Field(examples=["specs/api/UserController.md"])
    original_file: str = Field(examples=["src/api/UserController.java"])
    category: str = Field(examples=["API"])
    size_bytes: int = Field(examples=[12345])
    preview_url: str = Field(examples=["https://presigned-url-to-preview..."])
    edit_url: str = Field(examples=["https://presigned-url-to-edit..."])


class ReviewGetData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["AWAITING_REVIEW"])
    phase_completed: int = Field(examples=[5])
    specs: List[ReviewSpecItem] = Field(default_factory=list)
    review_expires_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    total_specs: int = Field(examples=[45])


class ReviewGetResponse(Envelope):
    data: ReviewGetData


class ReviewUpdateRequest(BaseModel):
    spec_path: str = Field(examples=["specs/api/UserController.md"])
    content: str = Field(examples=["# Updated Markdown Content..."])
    change_reason: str = Field(examples=["Redacted sensitive API keys"])


class ReviewUpdateData(BaseModel):
    spec_path: str = Field(examples=["specs/api/UserController.md"])
    status: str = Field(examples=["UPDATED"])
    updated_at: datetime = Field(default_factory=lambda: datetime.utcnow())


class ReviewUpdateResponse(Envelope):
    data: ReviewUpdateData


class ReviewApproveRequest(BaseModel):
    output_formats: List[str] = Field(default_factory=list, examples=[["pdf", "html"]])
    regenerate_from_phase_4: bool = Field(default=False, examples=[False])


class ReviewApproveData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["RUNNING"])
    current_phase: int = Field(examples=[6])
    output_formats: List[str] = Field(default_factory=list, examples=[["pdf", "html"]])


class ReviewApproveResponse(Envelope):
    data: ReviewApproveData


class ReviewRegenerateRequest(BaseModel):
    reason: str = Field(examples=["Major changes needed"])
    affected_files: List[str] = Field(default_factory=list, examples=[["src/api/UserController.java"]])


class ReviewRegenerateData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["RUNNING"])
    restarting_from_phase: int = Field(examples=[4])


class ReviewRegenerateResponse(Envelope):
    data: ReviewRegenerateData


class OutputTypeSummary(BaseModel):
    count: int = Field(examples=[45])
    total_size_bytes: int = Field(examples=[52428800])
    path: str = Field(examples=["jobs/{job_id}/phase6/pdfs/"])


class OutputReportItem(BaseModel):
    name: str = Field(examples=["summary"])
    format: str = Field(examples=["pdf"])
    url: str = Field(examples=["https://presigned-url..."])


class OutputsData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["COMPLETED"])
    outputs: Dict[str, OutputTypeSummary]
    reports: List[OutputReportItem] = Field(default_factory=list)
    categories: List[str] = Field(default_factory=list, examples=[["API", "Services"]])
    expires_at: datetime = Field(default_factory=lambda: datetime.utcnow())


class OutputsResponse(Envelope):
    data: OutputsData


class DownloadIndividualItem(BaseModel):
    file: str = Field(examples=["UserController.pdf"])
    format: str = Field(examples=["pdf"])
    category: str = Field(examples=["API"])
    url: str = Field(examples=["https://presigned-url-to-file..."])


class DownloadUrls(BaseModel):
    bundle_url: Optional[str] = Field(default=None, examples=["https://presigned-url-to-zip..."])
    individual: List[DownloadIndividualItem] = Field(default_factory=list)


class DownloadData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    download_urls: DownloadUrls
    expires_at: datetime = Field(default_factory=lambda: datetime.utcnow())


class DownloadResponse(Envelope):
    data: DownloadData


class EventType(str, Enum):
    CHUNK_PROGRESS = "CHUNK_PROGRESS"
    ERROR = "ERROR"
    JOB_COMPLETE = "JOB_COMPLETE"


class JobEvent(BaseModel):
    event_id: str = Field(examples=["uuid"])
    type: EventType
    timestamp: datetime = Field(default_factory=lambda: datetime.utcnow())
    data: Dict[str, Any] = Field(default_factory=dict)


class EventsData(BaseModel):
    events: List[JobEvent] = Field(default_factory=list)
    last_event_id: Optional[str] = Field(default=None, examples=["uuid"])
    has_more: bool = Field(default=False, examples=[False])


class EventsResponse(Envelope):
    data: EventsData


class FileListItem(BaseModel):
    name: str = Field(examples=["services"])
    path: str = Field(examples=["src/services/"])
    type: Literal["file", "directory"] = Field(examples=["directory"])
    size_bytes: Optional[int] = Field(default=None, examples=[4096])
    language: Optional[str] = Field(default=None, examples=["java"])
    item_count: Optional[int] = Field(default=None, examples=[12])


class FileListData(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    current_path: str = Field(examples=["src/"])
    items: List[FileListItem] = Field(default_factory=list)
    pagination: Pagination = Field(default_factory=Pagination)


class FileListResponse(Envelope):
    data: FileListData


class FilePreviewData(BaseModel):
    path: str = Field(examples=["src/api/UserController.java"])
    language: str = Field(examples=["java"])
    size_bytes: int = Field(examples=[4096])
    line_count: int = Field(examples=[150])
    content: str = Field(examples=["package com.example..."])
    syntax_highlighted: bool = Field(default=True, examples=[True])
    encoding: str = Field(default="UTF-8", examples=["UTF-8"])


class FilePreviewResponse(Envelope):
    data: FilePreviewData


# --- Job management (submit / detail) ---


class JobSubmitRequest(BaseModel):
    upload_id: str = Field(examples=["uuid"])
    job_name: str = Field(examples=["My conversion job"])
    config: Dict[str, Any] = Field(default_factory=dict, examples=[{"languages": ["java"]}])
    context: Dict[str, Any] = Field(default_factory=dict, examples=[{}])
    notifications: Optional[ProceedNotifications] = None
    tags: List[str] = Field(default_factory=list, examples=[["team-a", "pilot"]])


class JobSubmitData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["QUEUED"])
    created_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    config_hash: str = Field(examples=["sha256:abc..."])
    estimated_phases: int = Field(default=6, examples=[6])


class JobSubmitResponse(Envelope):
    data: JobSubmitData


class JobDetailData(BaseModel):
    job_id: str = Field(examples=["uuid"])
    user_id: str | None = Field(default=None, description="Caller identity extracted from JWT (JPMCIdentifier/SID/FID).")
    status: str = Field(examples=["RUNNING"])
    phase_completed: int = Field(examples=[3])
    current_phase: int = Field(examples=[4])
    progress: float = Field(default=0.45, examples=[0.45])
    eta: Optional[int] = Field(default=600, description="Seconds remaining", examples=[600])
    config: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)


class JobDetailResponse(Envelope):
    data: JobDetailData


class GenerateFormatRequest(BaseModel):
    formats: List[str] = Field(examples=[["docx", "html"]])


class GenerateFormatData(BaseModel):
    status: str = Field(examples=["QUEUED"])
    formats_requested: List[str] = Field(default_factory=list)
    phase: int = Field(examples=[6])
    message: str = Field(examples=["Additional format generation scheduled"])


class GenerateFormatResponse(Envelope):
    data: GenerateFormatData


class PublishToKbRequest(BaseModel):
    kb_config: Optional[Dict[str, Any]] = None
    credential_id: Optional[str] = None
    publish_options: Dict[str, Any] = Field(default_factory=dict)


class PublishToKbData(BaseModel):
    publish_id: str = Field(examples=["uuid"])
    status: str = Field(examples=["PUBLISHING"])
    total_documents: int = Field(examples=[45])
    estimated_timeout: int = Field(examples=[120])


class PublishToKbResponse(Envelope):
    data: PublishToKbData


# --- Knowledge base ---


class KbSummaryItem(BaseModel):
    kb_id: str
    name: str
    document_count: int = 0
    tenant_id: str = ""


class ListKbsData(BaseModel):
    items: List[KbSummaryItem] = Field(default_factory=list)
    pagination: Pagination = Field(default_factory=Pagination)


class ListKbsResponse(Envelope):
    data: ListKbsData


class KbMetadata(BaseModel):
    kb_id: str
    tenant_id: str = ""
    name: str = ""
    description: str = ""
    tags: List[str] = Field(default_factory=list)
    status: str = "ACTIVE"


class KbDetailResponse(Envelope):
    data: KbMetadata


class KbCreateRequest(BaseModel):
    kb_name: str = Field(examples=["Platform KB"])
    tenant_id: str = Field(examples=["tenant-1"])
    description: str = Field(default="", examples=["Main line-of-business KB"])
    tags: List[str] = Field(default_factory=list)


class KbCreateData(BaseModel):
    kb_id: str
    status: str = Field(examples=["CREATING"])


class KbCreateResponse(Envelope):
    data: KbCreateData


class KbValidateRequest(BaseModel):
    tenant_id: str = Field(examples=["tenant-1"])
    token: str = Field(default="", examples=["TBC"])


class KbValidateData(BaseModel):
    valid: bool = True
    permissions: List[str] = Field(default_factory=list, examples=[["read", "write"]])
    expires_at: Optional[datetime] = None


class KbValidateResponse(Envelope):
    data: KbValidateData


class KbTenantsData(BaseModel):
    tenants: List[str] = Field(default_factory=list, examples=[["tenant-1", "tenant-2"]])


class KbTenantsResponse(Envelope):
    data: KbTenantsData


class KbTokenRequest(BaseModel):
    tenant_id: str
    scope: str = Field(default="read", examples=["read"])
    expires_in_hours: int = Field(default=24, examples=[24])


class KbTokenData(BaseModel):
    token: str = Field(examples=["kb.jwt.example"])
    expires_at: datetime = Field(default_factory=lambda: datetime.utcnow())
    scope: str = "read"


class KbTokenResponse(Envelope):
    data: KbTokenData


class KbCredentialStoreRequest(BaseModel):
    tenant_id: str
    kb_id: str
    token: str
    alias: str = Field(default="", examples=["prod-readonly"])


class KbCredentialStoreData(BaseModel):
    credential_id: str
    alias: str = ""
    stored: bool = True


class KbCredentialStoreResponse(Envelope):
    data: KbCredentialStoreData


class KbCredentialItem(BaseModel):
    credential_id: str
    tenant_id: str = ""
    kb_id: str = ""
    alias: str = ""
    expires_soon: bool = False


class KbCredentialListData(BaseModel):
    credentials: List[KbCredentialItem] = Field(default_factory=list)


class KbCredentialListResponse(Envelope):
    data: KbCredentialListData


class KbCredentialDeleteData(BaseModel):
    credential_id: str
    deleted: bool = True


class KbCredentialDeleteResponse(Envelope):
    data: KbCredentialDeleteData

