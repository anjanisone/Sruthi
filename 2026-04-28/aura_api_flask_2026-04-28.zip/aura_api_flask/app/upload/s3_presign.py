from __future__ import annotations

import logging
import os
import re
from typing import Any
from urllib.parse import quote

import boto3
from botocore.client import BaseClient
from botocore.config import Config

from .. import settings

logger = logging.getLogger(__name__)
_proxy_notice_sent = False
_aws_profile_notice_sent = False


def _proxies_from_env() -> dict[str, str] | None:
    """
    Corporate laptops often cannot reach public S3 directly; HTTP(S)_PROXY must be set
    (same idea as devshell / curl). Botocore usually honors env vars, but we also pass
    Config.proxies so behavior is explicit on Windows.
    """
    http = (os.getenv("HTTP_PROXY") or os.getenv("http_proxy") or "").strip()
    https = (os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or "").strip()
    if not http and not https:
        return None
    out: dict[str, str] = {}
    if http:
        out["http"] = http
    if https:
        out["https"] = https
    return out or None


def _s3_boto_config() -> Config:
    kwargs: dict[str, Any] = {
        "connect_timeout": settings.S3_CONNECT_TIMEOUT_SECONDS,
        "read_timeout": settings.S3_READ_TIMEOUT_SECONDS,
        "retries": {"max_attempts": 5, "mode": "standard"},
    }
    proxies = _proxies_from_env()
    if proxies:
        kwargs["proxies"] = proxies
    if settings.BOTO_PROXY_USE_FORWARDING_HTTPS:
        kwargs["proxies_config"] = {"proxy_use_forwarding_for_https": True}
    return Config(**kwargs)


def s3_client() -> BaseClient:
    global _proxy_notice_sent, _aws_profile_notice_sent
    proxies = _proxies_from_env()
    if proxies and not _proxy_notice_sent:
        logger.info(
            "boto3 S3: using HTTP_PROXY/HTTPS_PROXY (or AURA_HTTP_PROXY/AURA_HTTPS_PROXY) for uploads."
        )
        _proxy_notice_sent = True
    profile = (os.getenv("AWS_PROFILE") or os.getenv("AWS_DEFAULT_PROFILE") or "").strip()
    if profile and not _aws_profile_notice_sent:
        logger.info("boto3 S3: using AWS CLI profile %r (set AWS_PROFILE or AURA_AWS_PROFILE).", profile)
        _aws_profile_notice_sent = True
    session = boto3.Session(profile_name=profile) if profile else boto3.Session()
    return session.client("s3", region_name=settings.S3_REGION, config=_s3_boto_config())


def safe_object_basename(file_name: str) -> str:
    base = (file_name or "").strip().replace("\\", "/").split("/")[-1]
    if not base or base in {".", ".."}:
        raise ValueError("file_name must be a non-empty basename.")
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("._") or "upload.bin"
    return cleaned[:200]


def object_https_url(bucket: str, region: str, key: str) -> str:
    encoded = quote(key, safe="/")
    if region == "us-east-1":
        return f"https://{bucket}.s3.amazonaws.com/{encoded}"
    return f"https://{bucket}.s3.{region}.amazonaws.com/{encoded}"


def build_upload_key(upload_id: str, safe_name: str) -> str:
    prefix = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{prefix}/{upload_id}/input/{safe_name}"


def build_workspace_source_prefix(upload_id: str) -> str:
    base = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{base}/{upload_id}/source/"
