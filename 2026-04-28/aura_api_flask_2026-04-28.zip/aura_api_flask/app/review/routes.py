from __future__ import annotations

from datetime import datetime
from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    ReviewApproveData,
    ReviewApproveRequest,
    ReviewApproveResponse,
    ReviewGetData,
    ReviewGetResponse,
    ReviewRegenerateData,
    ReviewRegenerateRequest,
    ReviewRegenerateResponse,
    ReviewUpdateData,
    ReviewUpdateRequest,
    ReviewUpdateResponse,
)
from ..state import STATE

bp = Blueprint("review", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


@bp.get("/jobs/<job_id>/review")
def get_review(job_id: str):
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    specs = rec.get("review_specs", [])
    summary = rec["summary"]
    phase = getattr(summary, "phase_completed", 5)
    return _j(
        ReviewGetResponse(
            success=True,
            data=ReviewGetData(
                job_id=job_id,
                status="AWAITING_REVIEW",
                phase_completed=phase,
                specs=specs,
                review_expires_at=datetime.utcnow(),
                total_specs=len(specs),
            ),
            errors=[],
        )
    )


@bp.put("/jobs/<job_id>/review/spec")
def update_review_spec(job_id: str):
    try:
        payload = ReviewUpdateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    return _j(
        ReviewUpdateResponse(
            success=True,
            data=ReviewUpdateData(spec_path=payload.spec_path, status="UPDATED", updated_at=datetime.utcnow()),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/review/approve")
def approve_review(job_id: str):
    try:
        payload = ReviewApproveRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    return _j(
        ReviewApproveResponse(
            success=True,
            data=ReviewApproveData(
                job_id=job_id,
                status="RUNNING",
                current_phase=6,
                output_formats=payload.output_formats,
            ),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/review/regenerate")
def regenerate_after_review(job_id: str):
    try:
        payload = ReviewRegenerateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    _ = payload
    STATE.seed_job(job_id)
    return _j(
        ReviewRegenerateResponse(
            success=True,
            data=ReviewRegenerateData(job_id=job_id, status="RUNNING", restarting_from_phase=4),
            errors=[],
        )
    )
