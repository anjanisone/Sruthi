from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    KbCreateData,
    KbCreateRequest,
    KbCreateResponse,
    KbCredentialDeleteData,
    KbCredentialDeleteResponse,
    KbCredentialItem,
    KbCredentialListData,
    KbCredentialListResponse,
    KbCredentialStoreData,
    KbCredentialStoreRequest,
    KbCredentialStoreResponse,
    KbDetailResponse,
    KbMetadata,
    KbSummaryItem,
    KbTenantsData,
    KbTenantsResponse,
    KbTokenData,
    KbTokenRequest,
    KbTokenResponse,
    KbValidateData,
    KbValidateRequest,
    KbValidateResponse,
    ListKbsData,
    ListKbsResponse,
    Pagination,
)
from ..state import STATE

bp = Blueprint("kb", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _ensure_kb_seed() -> None:
    if STATE.knowledge_bases:
        return
    STATE.knowledge_bases["kb-demo-1"] = {
        "name": "Demo knowledge base",
        "tenant_id": "tenant-1",
        "description": "Seeded KB",
        "tags": ["demo"],
        "status": "ACTIVE",
        "document_count": 12,
    }


@bp.get("/kb")
def list_kbs():
    tenant_id = request.args.get("tenant_id")
    page = int(request.args.get("page", "1"))
    page_size = int(request.args.get("page_size", "50"))
    _ensure_kb_seed()
    items: list[KbSummaryItem] = []
    for kb_id, rec in STATE.knowledge_bases.items():
        if tenant_id and rec.get("tenant_id") != tenant_id:
            continue
        items.append(
            KbSummaryItem(
                kb_id=kb_id,
                name=str(rec.get("name", "")),
                document_count=int(rec.get("document_count", 0)),
                tenant_id=str(rec.get("tenant_id", "")),
            )
        )
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return _j(
        ListKbsResponse(
            success=True,
            data=ListKbsData(
                items=page_items,
                pagination=Pagination(page=page, page_size=page_size, total_items=total, total_pages=total_pages),
            ),
            errors=[],
        )
    )


@bp.get("/kb/tenants")
def list_tenants():
    _ensure_kb_seed()
    tenants = sorted({str(v.get("tenant_id", "")) for v in STATE.knowledge_bases.values() if v.get("tenant_id")})
    return _j(KbTenantsResponse(success=True, data=KbTenantsData(tenants=tenants), errors=[]))


@bp.post("/kb/token")
def mint_kb_token():
    try:
        payload = KbTokenRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    exp = datetime.utcnow() + timedelta(hours=payload.expires_in_hours)
    return _j(
        KbTokenResponse(
            success=True,
            data=KbTokenData(token=f"kb.{uuid.uuid4()}", expires_at=exp, scope=payload.scope),
            errors=[],
        )
    )


@bp.post("/kb/credentials")
def store_kb_credentials():
    try:
        payload = KbCredentialStoreRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    cred_id = str(uuid.uuid4())
    STATE.kb_credentials[cred_id] = {
        "tenant_id": payload.tenant_id,
        "kb_id": payload.kb_id,
        "alias": payload.alias,
        "stored_at": datetime.utcnow().isoformat(),
    }
    return _j(
        KbCredentialStoreResponse(
            success=True,
            data=KbCredentialStoreData(credential_id=cred_id, alias=payload.alias, stored=True),
            errors=[],
        )
    )


@bp.get("/kb/credentials")
def list_kb_credentials():
    tenant_id = request.args.get("tenant_id")
    rows: list[KbCredentialItem] = []
    for cred_id, rec in STATE.kb_credentials.items():
        if tenant_id and rec.get("tenant_id") != tenant_id:
            continue
        rows.append(
            KbCredentialItem(
                credential_id=cred_id,
                tenant_id=str(rec.get("tenant_id", "")),
                kb_id=str(rec.get("kb_id", "")),
                alias=str(rec.get("alias", "")),
                expires_soon=False,
            )
        )
    return _j(KbCredentialListResponse(success=True, data=KbCredentialListData(credentials=rows), errors=[]))


@bp.delete("/kb/credentials/<credential_id>")
def delete_kb_credential(credential_id: str):
    if credential_id not in STATE.kb_credentials:
        return jsonify({"detail": "Credential not found."}), HTTPStatus.NOT_FOUND
    del STATE.kb_credentials[credential_id]
    return _j(
        KbCredentialDeleteResponse(
            success=True,
            data=KbCredentialDeleteData(credential_id=credential_id, deleted=True),
            errors=[],
        )
    )


@bp.post("/kb")
def create_kb():
    try:
        payload = KbCreateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    _ensure_kb_seed()
    kb_id = str(uuid.uuid4())
    STATE.knowledge_bases[kb_id] = {
        "name": payload.kb_name,
        "tenant_id": payload.tenant_id,
        "description": payload.description,
        "tags": payload.tags,
        "status": "CREATING",
        "document_count": 0,
    }
    return _j(KbCreateResponse(success=True, data=KbCreateData(kb_id=kb_id, status="CREATING"), errors=[]))


@bp.get("/kb/<kb_id>")
def get_kb(kb_id: str):
    tenant_id = request.args.get("tenant_id")
    _ensure_kb_seed()
    rec = STATE.knowledge_bases.get(kb_id)
    if not rec:
        return jsonify({"detail": "KB not found."}), HTTPStatus.NOT_FOUND
    if tenant_id and rec.get("tenant_id") != tenant_id:
        return jsonify({"detail": "KB not found."}), HTTPStatus.NOT_FOUND
    return _j(
        KbDetailResponse(
            success=True,
            data=KbMetadata(
                kb_id=kb_id,
                tenant_id=str(rec.get("tenant_id", "")),
                name=str(rec.get("name", "")),
                description=str(rec.get("description", "")),
                tags=list(rec.get("tags", [])),
                status=str(rec.get("status", "ACTIVE")),
            ),
            errors=[],
        )
    )


@bp.post("/kb/<kb_id>/validate")
def validate_kb(kb_id: str):
    try:
        payload = KbValidateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    _ = payload
    _ensure_kb_seed()
    if kb_id not in STATE.knowledge_bases:
        return jsonify({"detail": "KB not found."}), HTTPStatus.NOT_FOUND
    exp = datetime.utcnow() + timedelta(hours=1)
    return _j(
        KbValidateResponse(
            success=True,
            data=KbValidateData(valid=True, permissions=["read", "write"], expires_at=exp),
            errors=[],
        )
    )
