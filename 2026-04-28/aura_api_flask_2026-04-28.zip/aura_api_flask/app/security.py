from __future__ import annotations

from jwt.exceptions import PyJWTError
from flask import Flask, g, jsonify, request

from . import settings
from .jwt_tokens import decode_access_token
from .user_identity import extract_user_id_from_claims


def _is_exempt_path(path: str) -> bool:
    if path in {"/", "/health", "/favicon.ico", "/meta", "/github/connection"}:
        return True
    if path.startswith("/docs") or path.startswith("/redoc"):
        return True
    if path in {
        "/openapi.json",
        "/auth/token",
        "/auth/build-gci-subject-token",
        "/upload-zip/ui",
    }:
        return True
    return False


def register_auth_hook(app: Flask) -> None:
    @app.before_request
    def _enforce_bearer_jwt() -> tuple | None:
        g.user_claims = None
        g.user_id = None

        authorization = request.headers.get("Authorization") or ""
        if authorization.lower().startswith("bearer "):
            token = authorization.split(" ", 1)[1].strip()
            try:
                claims = decode_access_token(token)
            except Exception:
                claims = None
            g.user_claims = claims
            g.user_id = extract_user_id_from_claims(claims)

        if not settings.REQUIRE_AUTH:
            return None
        if request.method == "OPTIONS" or _is_exempt_path(request.path):
            return None
        if not authorization or not authorization.lower().startswith("bearer "):
            return jsonify({"detail": "Not authenticated"}), 401
        if g.user_claims is None:
            return jsonify({"detail": "Invalid or expired token"}), 401
        return None
