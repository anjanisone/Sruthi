from __future__ import annotations

from http import HTTPStatus
from typing import Any, Dict, Literal, Optional

from flask import Blueprint, g, jsonify, request
from pydantic import BaseModel, Field, ValidationError

from . import sfn

bp = Blueprint("stepfunctions", __name__, url_prefix="/stepfunctions")


class StartExecutionRequest(BaseModel):
    kind: Optional[Literal["ingest", "job"]] = Field(default=None)
    state_machine_arn: Optional[str] = Field(default=None)
    name: Optional[str] = Field(default=None)
    input: Dict[str, Any] = Field(default_factory=dict)


class StopExecutionRequest(BaseModel):
    execution_arn: str
    error: Optional[str] = None
    cause: Optional[str] = None


@bp.post("/executions/start")
def start_execution():
    try:
        payload = StartExecutionRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    user_id = getattr(g, "user_id", None)
    try:
        resp = sfn.start_execution(
            kind=payload.kind,
            state_machine_arn=payload.state_machine_arn,
            name=payload.name,
            input_obj=payload.input,
            user_id=user_id,
        )
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        return jsonify({"detail": detail}), code
    return (
        jsonify(
            {
                "execution_arn": resp.get("executionArn"),
                "state_machine_arn": resp.get("stateMachineArn"),
                "start_date": resp.get("startDate"),
            }
        ),
        HTTPStatus.OK,
    )


@bp.post("/executions/stop")
def stop_execution():
    try:
        payload = StopExecutionRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    try:
        resp = sfn.stop_execution(execution_arn=payload.execution_arn, error=payload.error, cause=payload.cause)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        return jsonify({"detail": detail}), code
    return jsonify({"stop_date": resp.get("stopDate")}), HTTPStatus.OK


@bp.get("/executions/describe")
def describe_execution():
    execution_arn = (request.args.get("execution_arn") or "").strip()
    if not execution_arn:
        return jsonify({"detail": "execution_arn query parameter is required."}), HTTPStatus.BAD_REQUEST
    try:
        d = sfn.describe_execution(execution_arn=execution_arn)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        return jsonify({"detail": detail}), code
    return (
        jsonify(
            {
                "execution_arn": d.get("executionArn"),
                "state_machine_arn": d.get("stateMachineArn"),
                "name": d.get("name"),
                "status": d.get("status"),
                "start_date": d.get("startDate"),
                "stop_date": d.get("stopDate"),
                "input": d.get("input"),
                "output": d.get("output"),
                "error": d.get("error"),
                "cause": d.get("cause"),
            }
        ),
        HTTPStatus.OK,
    )


@bp.get("/executions/result")
def execution_result():
    # Alias for describe
    return describe_execution()


@bp.get("/executions/history")
def execution_history():
    execution_arn = (request.args.get("execution_arn") or "").strip()
    if not execution_arn:
        return jsonify({"detail": "execution_arn query parameter is required."}), HTTPStatus.BAD_REQUEST
    max_results = int(request.args.get("max_results", "1000"))
    reverse_order = (request.args.get("reverse_order", "0").strip().lower() in {"1", "true", "yes", "on"})
    try:
        h = sfn.execution_history(execution_arn=execution_arn, max_results=max_results, reverse_order=reverse_order)
    except Exception as exc:
        code, detail = sfn.translate_error(exc)
        return jsonify({"detail": detail}), code
    return jsonify({"events": h.get("events", []), "next_token": h.get("nextToken")}), HTTPStatus.OK

