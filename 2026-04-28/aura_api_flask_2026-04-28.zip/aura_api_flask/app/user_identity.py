from __future__ import annotations

from typing import Any, Mapping


def extract_user_id_from_claims(claims: Mapping[str, Any] | None) -> str | None:
    if not claims:
        return None

    def _get(key: str) -> Any:
        return claims.get(key) if hasattr(claims, "get") else None

    for k in ("JPMCIdentifier", "jpmcIdentifier", "jpmcidentifier"):
        v = _get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()

    for k in ("sid", "SID", "Sid", "fid", "FID", "Fid"):
        v = _get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()

    for k in ("userId", "user_id", "uid"):
        v = _get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()

    sub = _get("sub")
    if isinstance(sub, str) and sub.strip():
        return sub.strip()
    return None

