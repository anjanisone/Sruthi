from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timedelta
from http import HTTPStatus
from typing import Any, Optional

from flask import Blueprint, g, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    ChangeDetectionData,
    ChangeDetectionRequest,
    ChangeDetectionResponse,
    ChangeSummary,
    ChangedFile,
    CostEstimate,
    CostEstimateBreakdown,
    DeleteJobData,
    DeleteJobResponse,
    DiscardEstimateData,
    DiscardEstimateResponse,
    DownloadData,
    DownloadIndividualItem,
    DownloadResponse,
    DownloadUrls,
    Estimation,
    EventsData,
    EventsResponse,
    GenerateFormatData,
    GenerateFormatRequest,
    GenerateFormatResponse,
    JobChunksData,
    JobChunksResponse,
    JobDetailData,
    JobDetailResponse,
    JobDiffData,
    JobDiffFormat,
    JobDiffResponse,
    DiffSummary,
    JobRerunData,
    JobRerunRequest,
    JobRerunResponse,
    JobsEstimateData,
    JobsEstimateRequest,
    JobsEstimateResponse,
    JobSubmitData,
    JobSubmitRequest,
    JobSubmitResponse,
    JobSummary,
    ListJobsData,
    ListJobsQuerySortBy,
    ListJobsResponse,
    OutputReportItem,
    OutputsData,
    OutputsResponse,
    Pagination,
    ProceedFromEstimateData,
    ProceedFromEstimateRequest,
    ProceedFromEstimateResponse,
    PublishToKbData,
    PublishToKbRequest,
    PublishToKbResponse,
    RetryChunksData,
    RetryChunksRequest,
    RetryChunksResponse,
    SortOrder,
    TimeEstimate,
)
from ..state import STATE

bp = Blueprint("jobs", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _config_hash(cfg: dict[str, Any]) -> str:
    blob = json.dumps(cfg, sort_keys=True, default=str).encode()
    return "sha256:" + hashlib.sha256(blob).hexdigest()[:32]


def _parse_dt(raw: Optional[str]) -> Optional[datetime]:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


@bp.post("/jobs/estimate")
def create_estimate():
    try:
        payload = JobsEstimateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    estimate_id = str(uuid.uuid4())
    now = datetime.utcnow()
    user_id = getattr(g, "user_id", None)
    data = JobsEstimateData(
        estimate_id=estimate_id,
        user_id=user_id,
        status="ESTIMATED",
        estimation=Estimation(
            total_files=150,
            total_lines=45000,
            total_tokens=125000,
            estimated_chunks=25,
            oversized_files=3,
            languages_detected={"java": 80, "python": 50},
        ),
        cost_estimate=CostEstimate(
            bedrock_input_tokens=125000,
            bedrock_output_tokens=75000,
            estimated_cost_usd=2.45,
            pricing_model="claude-3-sonnet",
            breakdown=CostEstimateBreakdown(phase_4_input_cost=1.0, phase_4_output_cost=1.0),
        ),
        time_estimate=TimeEstimate(
            estimated_duration_minutes=15,
            phase_breakdown={"phase_1": 1, "phase_4": 10},
        ),
        phase_1_output_path=f"jobs/{estimate_id}/phase1/",
        expires_at=now + timedelta(hours=24),
    )
    STATE.estimates[estimate_id] = {
        "upload_id": payload.upload_id,
        "config": payload.config.model_dump(),
        "status": "ESTIMATED",
        "data": data,
        "created_at": now,
        "user_id": user_id,
    }
    return _j(JobsEstimateResponse(success=True, data=data, errors=[]))


@bp.post("/jobs/estimates/<estimate_id>/proceed")
def proceed_from_estimate(estimate_id: str):
    try:
        payload = ProceedFromEstimateRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    est = STATE.estimates.get(estimate_id)
    if not est or est.get("status") != "ESTIMATED":
        return jsonify({"detail": "Estimate not found or not active."}), HTTPStatus.NOT_FOUND
    job_id = str(uuid.uuid4())
    user_id = getattr(g, "user_id", None)
    STATE.seed_job(job_id)
    summary = STATE.jobs[job_id]["summary"]
    if isinstance(summary, JobSummary):
        summary.status = "RUNNING"
        summary.phase_completed = payload.stop_after_phase or 1
        summary.job_name = f"Job from estimate {estimate_id[:8]}"
        summary.user_id = user_id
    STATE.jobs[job_id]["user_id"] = user_id
    return _j(
        ProceedFromEstimateResponse(
            success=True,
            data=ProceedFromEstimateData(
                job_id=job_id,
                user_id=user_id,
                status="RUNNING",
                starting_phase=2,
                skipped_phases=[1],
                message="Job started from Phase 2 (Phase 1 results reused from estimation)",
            ),
            errors=[],
        )
    )


@bp.post("/jobs/estimates/<estimate_id>/discard")
def discard_estimate(estimate_id: str):
    est = STATE.estimates.get(estimate_id)
    if not est:
        return jsonify({"detail": "Estimate not found."}), HTTPStatus.NOT_FOUND
    est["status"] = "DISCARDED"
    return _j(
        DiscardEstimateResponse(
            success=True,
            data=DiscardEstimateData(estimate_id=estimate_id, status="DISCARDED", cleanup_completed=True),
            errors=[],
        )
    )


@bp.post("/jobs")
def submit_job():
    try:
        payload = JobSubmitRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    job_id = str(uuid.uuid4())
    now = datetime.utcnow()
    user_id = getattr(g, "user_id", None)
    cfg: dict[str, Any] = {**payload.config, "context": payload.context}
    if payload.notifications:
        cfg["notifications"] = payload.notifications.model_dump()
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    summary = rec["summary"]
    if isinstance(summary, JobSummary):
        summary.job_name = payload.job_name
        summary.status = "QUEUED"
        summary.tags = list(payload.tags)
        summary.phase_completed = 0
        summary.created_at = now
        summary.updated_at = now
        summary.user_id = user_id
    rec["job_config"] = cfg
    rec["user_id"] = user_id
    rec["current_phase"] = 1
    rec["progress"] = 0.0
    rec["eta"] = 900
    return _j(
        JobSubmitResponse(
            success=True,
            data=JobSubmitData(
                job_id=job_id,
                user_id=user_id,
                status="QUEUED",
                created_at=now,
                config_hash=_config_hash(cfg),
                estimated_phases=6,
            ),
            errors=[],
        )
    )


@bp.get("/jobs")
def list_jobs():
    sort_raw = request.args.get("sort_by", ListJobsQuerySortBy.updated_at.value)
    try:
        sort_by = ListJobsQuerySortBy(sort_raw)
    except ValueError:
        sort_by = ListJobsQuerySortBy.updated_at
    order_raw = request.args.get("sort_order", SortOrder.desc.value)
    try:
        sort_order = SortOrder(order_raw)
    except ValueError:
        sort_order = SortOrder.desc
    page = int(request.args.get("page", "1"))
    page_size = int(request.args.get("page_size", "50"))
    status_filter = request.args.get("status")
    tags = request.args.get("tags")
    created_after = request.args.get("created_after")
    created_before = request.args.get("created_before")

    summaries: list[JobSummary] = []
    after = _parse_dt(created_after)
    before = _parse_dt(created_before)
    tag_set = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    for rec in STATE.jobs.values():
        s = rec.get("summary")
        if not isinstance(s, JobSummary):
            continue
        if status_filter and s.status != status_filter:
            continue
        if after and s.created_at < after:
            continue
        if before and s.created_at > before:
            continue
        if tag_set and not all(t in s.tags for t in tag_set):
            continue
        summaries.append(s)

    reverse = sort_order == SortOrder.desc
    if sort_by == ListJobsQuerySortBy.created_at:
        summaries.sort(key=lambda j: j.created_at, reverse=reverse)
    elif sort_by == ListJobsQuerySortBy.status:
        summaries.sort(key=lambda j: j.status, reverse=reverse)
    else:
        summaries.sort(key=lambda j: j.updated_at, reverse=reverse)

    total = len(summaries)
    total_pages = max(1, (total + page_size - 1) // page_size) if total else 1
    start = (page - 1) * page_size
    page_jobs = summaries[start : start + page_size]

    return _j(
        ListJobsResponse(
            success=True,
            data=ListJobsData(
                jobs=page_jobs,
                pagination=Pagination(
                    page=page,
                    page_size=page_size,
                    total_items=total,
                    total_pages=total_pages,
                ),
            ),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>")
def get_job(job_id: str):
    rec = STATE.jobs.get(job_id)
    if not rec:
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    summary = rec["summary"]
    if not isinstance(summary, JobSummary):
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    return _j(
        JobDetailResponse(
            success=True,
            data=JobDetailData(
                job_id=job_id,
                user_id=getattr(summary, "user_id", None) or rec.get("user_id"),
                status=summary.status,
                phase_completed=summary.phase_completed,
                current_phase=int(rec.get("current_phase", summary.phase_completed or 1)),
                progress=float(rec.get("progress", 0.0)),
                eta=rec.get("eta"),
                config=dict(rec.get("job_config", {})),
                tags=list(summary.tags),
            ),
            errors=[],
        )
    )


@bp.delete("/jobs/<job_id>")
def delete_job(job_id: str):
    rec = STATE.jobs.get(job_id)
    if not rec:
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    summary = rec["summary"]
    if not isinstance(summary, JobSummary):
        return jsonify({"detail": "Job not found."}), HTTPStatus.NOT_FOUND
    prev = summary.status
    summary.status = "CANCELLED"
    summary.updated_at = datetime.utcnow()
    return _j(
        DeleteJobResponse(
            success=True,
            data=DeleteJobData(
                job_id=job_id,
                previous_status=prev,
                new_status="CANCELLED",
                cleanup_scheduled=True,
            ),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/rerun")
def rerun_job(job_id: str):
    try:
        payload = JobRerunRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    rid = str(uuid.uuid4())
    return _j(
        JobRerunResponse(
            success=True,
            data=JobRerunData(
                job_id=job_id,
                rerun_id=rid,
                status="RUNNING",
                rerun_type=payload.rerun_type,
                chunks_to_retry=payload.options.chunk_ids or [],
                chunks_from_cache=["chunk_1", "chunk_2"],
                starting_phase=payload.options.from_phase or 4,
            ),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>/chunks")
def get_chunks(job_id: str):
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    chunks = rec.get("chunks", [])
    return _j(
        JobChunksResponse(
            success=True,
            data=JobChunksData(job_id=job_id, total_chunks=len(chunks), chunk_statuses=chunks),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/chunks/retry")
def retry_chunks(job_id: str):
    try:
        payload = RetryChunksRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    return _j(
        RetryChunksResponse(
            success=True,
            data=RetryChunksData(job_id=job_id, chunks_queued=payload.chunk_ids, status="RETRYING"),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/change-detection")
def change_detection(job_id: str):
    try:
        payload = ChangeDetectionRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    return _j(
        ChangeDetectionResponse(
            success=True,
            data=ChangeDetectionData(
                current_job_id=job_id,
                previous_job_id=payload.compare_with_job_id,
                changes_detected=True,
                change_summary=ChangeSummary(
                    files_added=5,
                    files_modified=12,
                    files_deleted=3,
                    total_affected_chunks=8,
                ),
                changed_files=[
                    ChangedFile(path="src/api/UserController.java", change_type="modified", lines_changed=42),
                ],
                recommendation="Proceed with incremental run",
                reason="12 files changed affecting 8 chunks",
            ),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>/diff")
def job_diff(job_id: str):
    fmt_raw = request.args.get("format", JobDiffFormat.summary.value)
    try:
        fmt = JobDiffFormat(fmt_raw)
    except ValueError:
        fmt = JobDiffFormat.summary
    compare_with_job_id = request.args.get("compare_with_job_id")
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    prev = compare_with_job_id or str(rec.get("previous_job_id", "previous_job_uuid"))
    diff = rec.get("diff", {})
    summary = diff.get("summary")
    detailed = diff.get("detailed") if fmt == JobDiffFormat.detailed else None

    if summary is None:
        summary = DiffSummary(specs_added=0, specs_modified=0, specs_deleted=0)
    return _j(
        JobDiffResponse(
            success=True,
            data=JobDiffData(
                current_job_id=job_id,
                previous_job_id=prev,
                diff_summary=summary,
                detailed_changes=detailed,
            ),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>/events")
def job_events(job_id: str):
    STATE.seed_job(job_id)
    evs = STATE.events.get(job_id, [])
    return _j(
        EventsResponse(
            success=True,
            data=EventsData(events=list(evs), last_event_id=evs[-1].event_id if evs else None, has_more=False),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>/outputs")
def list_outputs(job_id: str):
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    outs = rec.get("outputs", {})
    exp = datetime.utcnow() + timedelta(hours=24)
    return _j(
        OutputsResponse(
            success=True,
            data=OutputsData(
                job_id=job_id,
                status="COMPLETED",
                outputs=outs,
                reports=[
                    OutputReportItem(name="executive-summary", format="pdf", url="https://presigned..."),
                ],
                categories=["API", "Services"],
                expires_at=exp,
            ),
            errors=[],
        )
    )


@bp.get("/jobs/<job_id>/download")
def download_outputs(job_id: str):
    STATE.seed_job(job_id)
    rec = STATE.jobs[job_id]
    individuals: list[DownloadIndividualItem] = list(rec.get("download_individual", []))
    exp = datetime.utcnow() + timedelta(hours=24)
    return _j(
        DownloadResponse(
            success=True,
            data=DownloadData(
                job_id=job_id,
                download_urls=DownloadUrls(bundle_url="https://presigned-zip...", individual=individuals),
                expires_at=exp,
            ),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/generate-format")
def generate_format(job_id: str):
    try:
        payload = GenerateFormatRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    STATE.seed_job(job_id)
    return _j(
        GenerateFormatResponse(
            success=True,
            data=GenerateFormatData(
                status="QUEUED",
                formats_requested=payload.formats,
                phase=6,
                message="Additional format generation scheduled",
            ),
            errors=[],
        )
    )


@bp.post("/jobs/<job_id>/publish-to-kb")
def publish_to_kb(job_id: str):
    try:
        payload = PublishToKbRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    _ = payload
    STATE.seed_job(job_id)
    return _j(
        PublishToKbResponse(
            success=True,
            data=PublishToKbData(
                publish_id=str(uuid.uuid4()),
                status="PUBLISHING",
                total_documents=45,
                estimated_timeout=120,
            ),
            errors=[],
        )
    )
