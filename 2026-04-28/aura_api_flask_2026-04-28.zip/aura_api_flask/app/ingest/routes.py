from __future__ import annotations

import logging
import uuid
from http import HTTPStatus

from botocore.exceptions import BotoCoreError, ClientError
from flask import Blueprint, g, jsonify, request
from pydantic import BaseModel, ValidationError

from .. import settings
from ..models import (
    FileListData,
    FileListResponse,
    FilePreviewData,
    FilePreviewResponse,
    Pagination,
    RepoCloneData,
    RepoCloneRequest,
    RepoCloneResponse,
    ZipCloneRequest,
)
from ..s3_workspace import aggregate_languages_from_tree, clone_repo_to_s3
from ..state import STATE

bp = Blueprint("ingest", __name__)
logger = logging.getLogger(__name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _norm_list_path(current_path: str) -> str:
    p = (current_path or "").strip()
    if not p or p == "/":
        return ""
    return p.rstrip("/") + "/"


def _clone_repo_to_workspace(payload: RepoCloneRequest, source: str) -> tuple[RepoCloneResponse | None, tuple | None]:
    bucket = settings.S3_BUCKET
    if not bucket:
        return None, (
            jsonify(
                {
                    "detail": "S3 is not configured. Set AURA_S3_BUCKET and credentials with s3:PutObject on the upload prefix."
                }
            ),
            HTTPStatus.SERVICE_UNAVAILABLE,
        )
    upload_id = str(uuid.uuid4())
    branch = (payload.branch or "main").strip() or "main"
    try:
        fc, tb, warnings, tree, prefix = clone_repo_to_s3(
            bucket=bucket,
            upload_id=upload_id,
            repository_url=(payload.repository_url or "").strip(),
            branch=branch,
            access_token=payload.access_token,
            username=payload.username,
            app_password=payload.app_password,
        )
    except ValueError as exc:
        return None, (jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST)
    except RuntimeError as exc:
        return None, (jsonify({"detail": str(exc)}), HTTPStatus.BAD_GATEWAY)
    except OSError as exc:
        return None, (
            jsonify({"detail": f"git clone could not run (is git installed on PATH?): {exc}"}),
            HTTPStatus.SERVICE_UNAVAILABLE,
        )
    except (ClientError, BotoCoreError) as exc:
        logger.exception("ingest clone S3 failure upload_id=%s", upload_id)
        return None, (jsonify({"detail": f"S3 upload after clone failed: {exc}"}), HTTPStatus.SERVICE_UNAVAILABLE)

    langs = aggregate_languages_from_tree(tree)
    s3_uri = f"s3://{bucket}/{prefix}"
    user_id = getattr(g, "user_id", None)
    STATE.ingest_file_trees[upload_id] = tree
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "upload_kind": "repo_clone",
        "user_id": user_id,
        "file_count": fc,
        "total_size_bytes": tb,
        "detected_languages": langs,
        "s3_path": prefix,
        "s3_uri": s3_uri,
        "object_url": "",
        "bucket": bucket,
        "key": "",
        "source": source,
        "validation_warnings": warnings,
    }
    return (
        RepoCloneResponse(
            success=True,
            data=RepoCloneData(
                upload_id=upload_id,
                user_id=user_id,
                status="COMPLETED",
                estimated_time_seconds=0,
                file_count=fc,
                total_size_bytes=tb,
                s3_prefix=prefix,
                s3_uri=s3_uri,
            ),
            errors=[],
        ),
        None,
    )


def _start_clone(upload_id: str, source: str) -> RepoCloneResponse:
    user_id = getattr(g, "user_id", None)
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0, "source": source, "user_id": user_id}
    STATE.seed_ingest_tree(upload_id)
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, user_id=user_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )


@bp.post("/ingest/repo-clone")
def repo_clone():
    try:
        payload = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    body, err = _clone_repo_to_workspace(payload, "repo_clone")
    if err:
        return err
    return _j(body)


@bp.post("/ingest/bitbucket-clone")
def bitbucket_clone():
    try:
        payload = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    body, err = _clone_repo_to_workspace(payload, "bitbucket")
    if err:
        return err
    return _j(body)


@bp.post("/ingest/github-clone")
def github_clone():
    try:
        payload = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    body, err = _clone_repo_to_workspace(payload, "github")
    if err:
        return err
    return _j(body)


@bp.post("/ingest/zip-clone")
def zip_clone():
    try:
        _ = ZipCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    return _j(_start_clone(str(uuid.uuid4()), "zip"))


@bp.get("/ingest/<upload_id>/files")
def list_ingest_files(upload_id: str):
    current_path = request.args.get("current_path", "")
    page = int(request.args.get("page", "1"))
    page_size = int(request.args.get("page_size", "50"))
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        return jsonify({"detail": "Unknown upload_id."}), HTTPStatus.NOT_FOUND
    STATE.seed_ingest_tree(upload_id)
    key = _norm_list_path(current_path)
    tree = STATE.ingest_file_trees.get(upload_id, {})
    items = list(tree.get(key, []))
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return _j(
        FileListResponse(
            success=True,
            data=FileListData(
                upload_id=upload_id,
                current_path=key if key else "/",
                items=page_items,
                pagination=Pagination(
                    page=page,
                    page_size=page_size,
                    total_items=total,
                    total_pages=total_pages,
                ),
            ),
            errors=[],
        )
    )


@bp.get("/ingest/<upload_id>/files/preview")
def preview_ingest_file(upload_id: str):
    path = request.args.get("path")
    if not path:
        return jsonify({"detail": "path query parameter is required."}), HTTPStatus.BAD_REQUEST
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        return jsonify({"detail": "Unknown upload_id."}), HTTPStatus.NOT_FOUND
    STATE.seed_ingest_tree(upload_id)
    tree = STATE.ingest_file_trees[upload_id]
    target = None
    for lst in tree.values():
        for it in lst:
            if it.path == path and it.type == "file":
                target = it
                break
        if target:
            break
    if target is None:
        return jsonify({"detail": "File not found for path."}), HTTPStatus.NOT_FOUND
    lang = target.language or "text"
    return _j(
        FilePreviewResponse(
            success=True,
            data=FilePreviewData(
                path=target.path,
                language=lang,
                size_bytes=target.size_bytes or 0,
                line_count=42,
                content=f"# Preview for {target.path}\n(package com.example; …)",
                syntax_highlighted=True,
                encoding="UTF-8",
            ),
            errors=[],
        )
    )
