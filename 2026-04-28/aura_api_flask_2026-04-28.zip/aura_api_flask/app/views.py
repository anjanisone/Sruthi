from __future__ import annotations

import requests
from flask import Flask, Response, jsonify

from . import settings

_DOCS_OFFLINE_HTML = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/><title>AURA</title></head>
<body style="font-family:system-ui;margin:2rem"><h1>AURA (Flask)</h1>
<p><a href="/upload-zip/ui">upload</a> · <a href="/meta">meta</a> · <a href="/health">health</a></p></body></html>"""


def register_routes(app: Flask) -> None:
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/meta")
    def deployment_meta():
        return jsonify(
            {
                "service": "flask",
                "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "no_swagger_bundle",
                "dynamodb_table_configured": bool(settings.DYNAMODB_TABLE_NAME),
                "s3_https_proxy": "set" if settings.BOTO_HTTPS_PROXY_CONFIGURED else "unset",
            }
        )

    @app.get("/github/connection")
    def github_connection():
        if not settings.GITHUB_TOKEN:
            return (
                jsonify(
                    {
                        "ok": False,
                        "detail": "Set AURA_GITHUB_TOKEN or GITHUB_TOKEN in .env, then restart the app.",
                    }
                ),
                503,
            )
        try:
            resp = requests.get(
                "https://api.github.com/user",
                headers={
                    "Accept": "application/vnd.github+json",
                    "Authorization": f"Bearer {settings.GITHUB_TOKEN}",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                timeout=30,
            )
        except requests.RequestException as exc:
            return jsonify({"ok": False, "detail": str(exc)}), 502
        if resp.status_code != 200:
            return (
                jsonify(
                    {
                        "ok": False,
                        "status": resp.status_code,
                        "detail": (resp.text or "")[:1000],
                    }
                ),
                401,
            )
        data = resp.json()
        return jsonify(
            {
                "ok": True,
                "login": data.get("login"),
                "id": data.get("id"),
                "name": data.get("name"),
            }
        )

    if settings.DOCS_CDN_OFFLINE:

        @app.get("/docs")
        def docs_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

        @app.get("/redoc")
        def redoc_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

    @app.after_request
    def _cors(resp):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        return resp
