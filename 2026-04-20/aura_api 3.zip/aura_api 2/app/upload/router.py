from __future__ import annotations

import uuid

from botocore.exceptions import ClientError
from fastapi import APIRouter, HTTPException, status

from .. import settings
from ..models import (
    PresignedUrlData,
    PresignedUrlRequest,
    PresignedUrlResponse,
    UploadConfirmData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE
from . import s3_presign

router = APIRouter(tags=["upload"])


@router.post(
    "/upload/presigned-url",
    response_model=PresignedUrlResponse,
    summary="Generate a pre-signed S3 PUT URL; client uploads bytes directly to S3",
)
def create_presigned_url(payload: PresignedUrlRequest) -> PresignedUrlResponse:
    if not settings.S3_BUCKET:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="S3 uploads are not configured. Set AURA_S3_BUCKET and AWS credentials (s3:PutObject on the upload prefix).",
        )
    if payload.file_size_bytes <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="file_size_bytes must be positive.")
    if payload.file_size_bytes > settings.S3_MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"file_size_bytes exceeds limit {settings.S3_MAX_FILE_SIZE_BYTES}.",
        )
    try:
        safe_name = s3_presign.safe_object_basename(payload.file_name)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    upload_id = str(uuid.uuid4())
    key = s3_presign.build_upload_key(upload_id, safe_name)
    bucket = settings.S3_BUCKET
    expires = settings.S3_PRESIGN_EXPIRES_SECONDS
    try:
        url = s3_presign.presigned_put_url(
            bucket=bucket,
            key=key,
            content_type=payload.content_type,
            content_length=payload.file_size_bytes,
            expires_in=expires,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc

    s3_uri = f"s3://{bucket}/{key}"
    object_url = s3_presign.object_https_url(bucket, settings.S3_REGION, key)

    STATE.uploads_status[upload_id] = {
        "status": "UPLOADING",
        "file_count": 0,
        "total_size_bytes": 0,
        "detected_languages": {},
        "s3_path": key,
        "s3_uri": s3_uri,
        "object_url": object_url,
        "bucket": bucket,
        "key": key,
        "content_type": payload.content_type,
        "expected_size": payload.file_size_bytes,
    }

    return PresignedUrlResponse(
        success=True,
        data=PresignedUrlData(
            upload_id=upload_id,
            presigned_url=url,
            expires_in=expires,
            s3_path=key,
            s3_uri=s3_uri,
            object_url=object_url,
            max_file_size_bytes=settings.S3_MAX_FILE_SIZE_BYTES,
        ),
        errors=[],
    )


@router.post(
    "/upload/confirm",
    response_model=UploadConfirmResponse,
    summary="Confirm upload completion (HeadObject in S3) and return validation summary",
)
def confirm_upload(payload: UploadConfirmRequest) -> UploadConfirmResponse:
    rec = STATE.uploads_status.get(payload.upload_id)
    if not rec or not rec.get("bucket") or not rec.get("key"):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    bucket = str(rec["bucket"])
    key = str(rec["key"])
    expected = int(rec.get("expected_size") or 0)

    try:
        head = s3_presign.head_object(bucket=bucket, key=key)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Object not in S3 yet. HTTP PUT the file to presigned_url first, then call confirm again.",
        ) from None
    except ClientError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"S3 HeadObject failed: {exc}",
        ) from exc

    size = int(head["ContentLength"])
    if expected and size != expected:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Uploaded size {size} bytes does not match declared file_size_bytes {expected}.",
        )

    langs: dict[str, int] = {}
    warnings: list[str] = []
    STATE.uploads_status[payload.upload_id] = {
        **rec,
        "status": "COMPLETED",
        "file_count": 1,
        "total_size_bytes": size,
        "detected_languages": langs,
        "s3_path": key,
    }

    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=payload.upload_id,
            status="VALIDATED",
            file_count=1,
            total_size_bytes=size,
            detected_languages=langs,
            validation_warnings=warnings,
            s3_path=key,
            s3_uri=str(rec.get("s3_uri", "")),
            object_url=str(rec.get("object_url", "")),
        ),
        errors=[],
    )


@router.get(
    "/upload/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Check upload status",
)
def upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=str(record["status"]),
            file_count=int(record.get("file_count", 0)),
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", "")),
            s3_uri=str(record.get("s3_uri", "")),
            object_url=str(record.get("object_url", "")),
        ),
        errors=[],
    )
