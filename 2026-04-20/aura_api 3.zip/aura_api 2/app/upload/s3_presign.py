from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import boto3
from botocore.client import BaseClient
from botocore.exceptions import BotoCoreError, ClientError

from .. import settings


def s3_client() -> BaseClient:
    return boto3.client("s3", region_name=settings.S3_REGION)


def safe_object_basename(file_name: str) -> str:
    base = (file_name or "").strip().replace("\\", "/").split("/")[-1]
    if not base or base in {".", ".."}:
        raise ValueError("file_name must be a non-empty basename.")
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("._") or "upload.bin"
    return cleaned[:200]


def object_https_url(bucket: str, region: str, key: str) -> str:
    encoded = quote(key, safe="/")
    if region == "us-east-1":
        return f"https://{bucket}.s3.amazonaws.com/{encoded}"
    return f"https://{bucket}.s3.{region}.amazonaws.com/{encoded}"


def build_upload_key(upload_id: str, safe_name: str) -> str:
    prefix = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{prefix}/{upload_id}/input/{safe_name}"


def presigned_put_url(
    *,
    bucket: str,
    key: str,
    content_type: str,
    content_length: int,
    expires_in: int,
) -> str:
    client = s3_client()
    params: dict[str, Any] = {
        "Bucket": bucket,
        "Key": key,
        "ContentType": content_type,
        "ContentLength": content_length,
    }
    try:
        return client.generate_presigned_url(
            "put_object",
            Params=params,
            ExpiresIn=expires_in,
        )
    except (ClientError, BotoCoreError) as exc:
        raise RuntimeError(f"S3 presign failed: {exc}") from exc


def head_object(*, bucket: str, key: str) -> dict[str, Any]:
    client = s3_client()
    try:
        return client.head_object(Bucket=bucket, Key=key)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in ("404", "NotFound", "NoSuchKey"):
            raise FileNotFoundError("object not in bucket") from exc
        raise
