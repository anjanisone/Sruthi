from __future__ import annotations

import os
from typing import FrozenSet


def _truthy(name: str, default: str = "") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


JWT_SECRET: str = os.getenv(
    "AURA_JWT_SECRET",
    "dev-only-change-me-please-use-AURA_JWT_SECRET-in-real-envs",
)
JWT_ALGORITHM: str = os.getenv("AURA_JWT_ALGORITHM", "HS256")
JWT_EXPIRES_SECONDS: int = int(os.getenv("AURA_JWT_EXPIRES_SECONDS", "3600"))

REQUIRE_AUTH: bool = _truthy("AURA_REQUIRE_AUTH")

CLIENT_ID: str = os.getenv("AURA_CLIENT_ID", "aura-demo-client")
CLIENT_SECRET: str = os.getenv("AURA_CLIENT_SECRET", "aura-demo-secret")

AWS_GET_CALLER_IDENTITY_TOKEN_TYPES: FrozenSet[str] = frozenset(
    {
        "urn:jpmc:params:identity:token-type:aws-get-caller-identity",
        "urn:aura:params:identity:token-type:aws-get-caller-identity",
    }
)

STS_POST_BODY_DEFAULT: str = "Action=GetCallerIdentity&Version=2011-06-15"


def _optional_str(name: str) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    stripped = raw.strip()
    return stripped or None


C2C_TOKEN_ENDPOINT: str | None = _optional_str("AURA_C2C_TOKEN_ENDPOINT")
C2C_REQUESTED_TOKEN_TYPE: str = os.getenv(
    "AURA_C2C_REQUESTED_TOKEN_TYPE",
    "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
)
C2C_TIMEOUT_SECONDS: int = int(os.getenv("AURA_C2C_TIMEOUT_SECONDS", "45"))
C2C_VERIFY_SSL: bool = not _truthy("AURA_C2C_INSECURE_SKIP_TLS_VERIFY")
C2C_SSL_CA_BUNDLE: str | None = _optional_str("AURA_C2C_SSL_CA_BUNDLE")

ADFS_HTTP_TIMEOUT_SECONDS: int = int(os.getenv("AURA_ADFS_HTTP_TIMEOUT_SECONDS", "45"))

TOKEN_EXCHANGE_MODE: str = os.getenv("AURA_TOKEN_EXCHANGE_MODE", "local").strip().lower()

ALLOW_GCI_SUBJECT_TOKEN_BUILDER: bool = _truthy("AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER")

ALLOW_GCI_BUILDER_AWS_CLI_CREDS: bool = _truthy("AURA_ALLOW_GCI_BUILDER_AWS_CLI_CREDS", "true")

# Direct-to-S3 uploads (pre-signed PUT). Requires IAM permission: s3:PutObject, s3:HeadObject on prefix.
S3_BUCKET: str | None = _optional_str("AURA_S3_BUCKET")
S3_REGION: str = (
    (_optional_str("AURA_S3_REGION") or _optional_str("AWS_DEFAULT_REGION") or "us-east-1").strip()
)
S3_UPLOAD_PREFIX: str = os.getenv("AURA_S3_UPLOAD_PREFIX", "jobs").strip().strip("/") or "jobs"
S3_PRESIGN_EXPIRES_SECONDS: int = int(os.getenv("AURA_S3_PRESIGN_EXPIRES_SECONDS", "3600"))
S3_MAX_FILE_SIZE_BYTES: int = int(os.getenv("AURA_S3_MAX_FILE_SIZE_BYTES", "524288000"))
