# AURA API (FastAPI)

Demo API with in-memory state. Run:

```bash
cd aura_api && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt && uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

## S3 zip upload (pre-signed PUT)

The API does **not** accept the file body. It returns a **pre-signed S3 PUT URL**; your browser, app, or `curl` uploads bytes **directly to S3**.

**Configure**

- `AURA_S3_BUCKET` — target bucket (required for uploads).
- `AURA_S3_REGION` or `AWS_DEFAULT_REGION` — e.g. `us-east-1`.
- `AURA_S3_UPLOAD_PREFIX` — optional, default `jobs` (keys look like `jobs/<upload_id>/input/<file>`).
- AWS credentials in the usual places (`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`, instance role, SSO profile, etc.). The principal needs `s3:PutObject` and `s3:HeadObject` on `arn:aws:s3:::<bucket>/<prefix>/*`.

**Flow**

1. **`POST /upload/presigned-url`** — JSON: `file_name`, `content_type` (must match the later PUT), `file_size_bytes` (**exact** byte size of the file on disk). Response: `upload_id`, `presigned_url`, `s3_path` (key), `s3_uri`, `object_url`, `expires_in`. Server stores this upload in memory as `UPLOADING`.
2. **`PUT presigned_url`** — Send the **raw file bytes** with **`Content-Type`** and **`Content-Length`** matching step 1 (the signature binds to those values). The file lands in S3 at `s3_uri` / `object_url`.
3. **`POST /upload/confirm`** — Body: `{ "upload_id": "<same id>" }`. Server runs **`HeadObject`** on S3: object must exist and **`ContentLength`** must equal the `file_size_bytes` from step 1. Response includes `status` (`VALIDATED`), `total_size_bytes`, plus **`s3_path`**, **`s3_uri`**, **`object_url`** again so clients do not have to keep step 1’s payload. In-memory status becomes **`COMPLETED`**.
4. **`GET /upload/{upload_id}/status`** — Poll or re-fetch state for that `upload_id`. Returns `status` (`UPLOADING` until you PUT to S3, then **`COMPLETED`** after confirm), `total_size_bytes`, `s3_path`, **`s3_uri`**, **`object_url`**, `detected_languages`, etc. **`404`** if this server never issued that id (in-memory only; restart clears it). Ingest/clone ids from other routes have status here too but may leave `s3_uri` / `object_url` empty.

**Response fields (presign)**

- `presigned_url` — use this for the HTTP PUT upload.
- `s3_uri` — `s3://bucket/key` after upload.
- `object_url` — HTTPS URL of the object (GET may still return 403 unless the bucket/object allows read or you use a separate pre-signed GET).

**Example (`curl`)**

```bash
ZIP=/absolute/path/to/project.zip
SIZE=$(wc -c < "$ZIP" | tr -d ' ')

RESP=$(curl -s -X POST http://127.0.0.1:8000/upload/presigned-url \
  -H 'Content-Type: application/json' \
  -d "{\"file_name\":\"project.zip\",\"content_type\":\"application/zip\",\"file_size_bytes\":$SIZE}")

# Parse presigned_url and upload_id with jq, then:
# curl -X PUT "$PUT_URL" -H "Content-Type: application/zip" --data-binary @"$ZIP"
# curl -s -X POST http://127.0.0.1:8000/upload/confirm -H 'Content-Type: application/json' \
#   -d "{\"upload_id\":\"$UPLOAD_ID\"}"
```

Env vars: other `AURA_*` keys are in `app/settings.py`. Defaults: token exchange is `local` (STS replay, no C2C URL).

Shipped next to this folder: `aura_api.zip` (this tree) and `aura_api_flask.zip` (Flask twin from `2026-04-17` snapshot for reference).
