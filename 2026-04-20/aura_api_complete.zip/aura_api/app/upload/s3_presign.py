from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import boto3
from botocore.client import BaseClient
from botocore.exceptions import BotoCoreError, ClientError

from .. import settings


def s3_client() -> BaseClient:
    return boto3.client("s3", region_name=settings.S3_REGION)


def safe_object_basename(file_name: str) -> str:
    base = (file_name or "").strip().replace("\\", "/").split("/")[-1]
    if not base or base in {".", ".."}:
        raise ValueError("file_name must be a non-empty basename.")
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("._") or "upload.bin"
    return cleaned[:200]


def object_https_url(bucket: str, region: str, key: str) -> str:
    encoded = quote(key, safe="/")
    if region == "us-east-1":
        return f"https://{bucket}.s3.amazonaws.com/{encoded}"
    return f"https://{bucket}.s3.{region}.amazonaws.com/{encoded}"


def build_upload_key(upload_id: str, safe_name: str) -> str:
    prefix = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{prefix}/{upload_id}/input/{safe_name}"


def head_object(*, bucket: str, key: str) -> dict[str, Any]:
    client = s3_client()
    try:
        return client.head_object(Bucket=bucket, Key=key)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in ("404", "NotFound", "NoSuchKey"):
            raise FileNotFoundError("object not in bucket") from exc
        raise


def create_multipart_upload(*, bucket: str, key: str, content_type: str) -> str:
    client = s3_client()
    try:
        resp = client.create_multipart_upload(
            Bucket=bucket,
            Key=key,
            ContentType=content_type,
        )
        return str(resp["UploadId"])
    except (ClientError, BotoCoreError) as exc:
        raise RuntimeError(f"S3 CreateMultipartUpload failed: {exc}") from exc


def presigned_upload_part_url(
    *,
    bucket: str,
    key: str,
    s3_upload_id: str,
    part_number: int,
    expires_in: int,
) -> str:
    client = s3_client()
    try:
        return client.generate_presigned_url(
            "upload_part",
            Params={
                "Bucket": bucket,
                "Key": key,
                "UploadId": s3_upload_id,
                "PartNumber": part_number,
            },
            ExpiresIn=expires_in,
        )
    except (ClientError, BotoCoreError) as exc:
        raise RuntimeError(f"S3 presigned UploadPart failed: {exc}") from exc


def complete_multipart_upload(
    *,
    bucket: str,
    key: str,
    s3_upload_id: str,
    parts: list[tuple[int, str]],
) -> dict[str, Any]:
    client = s3_client()
    sorted_parts = sorted(parts, key=lambda p: p[0])
    multipart: dict[str, Any] = {
        "Parts": [{"PartNumber": num, "ETag": etag} for num, etag in sorted_parts],
    }
    try:
        return client.complete_multipart_upload(
            Bucket=bucket,
            Key=key,
            UploadId=s3_upload_id,
            MultipartUpload=multipart,
        )
    except (ClientError, BotoCoreError) as exc:
        raise RuntimeError(f"S3 CompleteMultipartUpload failed: {exc}") from exc


def abort_multipart_upload(*, bucket: str, key: str, s3_upload_id: str) -> None:
    client = s3_client()
    try:
        client.abort_multipart_upload(Bucket=bucket, Key=key, UploadId=s3_upload_id)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in ("NoSuchUpload",):
            return
        raise
