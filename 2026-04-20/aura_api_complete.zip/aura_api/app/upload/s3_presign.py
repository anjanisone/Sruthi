from __future__ import annotations

import re
from urllib.parse import quote

import boto3
from botocore.client import BaseClient

from .. import settings


def s3_client() -> BaseClient:
    return boto3.client("s3", region_name=settings.S3_REGION)


def safe_object_basename(file_name: str) -> str:
    base = (file_name or "").strip().replace("\\", "/").split("/")[-1]
    if not base or base in {".", ".."}:
        raise ValueError("file_name must be a non-empty basename.")
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("._") or "upload.bin"
    return cleaned[:200]


def object_https_url(bucket: str, region: str, key: str) -> str:
    encoded = quote(key, safe="/")
    if region == "us-east-1":
        return f"https://{bucket}.s3.amazonaws.com/{encoded}"
    return f"https://{bucket}.s3.{region}.amazonaws.com/{encoded}"


def build_upload_key(upload_id: str, safe_name: str) -> str:
    prefix = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{prefix}/{upload_id}/input/{safe_name}"
