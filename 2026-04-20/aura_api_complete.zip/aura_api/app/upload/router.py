from __future__ import annotations

import os
import tempfile
import uuid
import zipfile
from pathlib import Path

from botocore.exceptions import ClientError
from fastapi import APIRouter, File, HTTPException, UploadFile, status
from fastapi.responses import HTMLResponse

from .. import settings
from ..models import (
    UploadConfirmData,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE
from . import s3_presign

_READ_CHUNK = 1024 * 1024

router = APIRouter(prefix="/upload-zip", tags=["upload-zip"])
_UPLOAD_ZIP_UI_PATH = Path(__file__).with_name("upload_zip.html")


@router.get(
    "/ui",
    response_class=HTMLResponse,
    include_in_schema=False,
    summary="Browser page with Upload button",
)
def upload_zip_button_page() -> HTMLResponse:
    return HTMLResponse(_UPLOAD_ZIP_UI_PATH.read_text(encoding="utf-8"))


def _require_s3_bucket() -> str:
    if not settings.S3_BUCKET:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="S3 uploads are not configured. Set AURA_S3_BUCKET and AWS credentials with s3:PutObject on the upload prefix.",
        )
    return settings.S3_BUCKET


@router.post(
    "/file",
    response_model=UploadConfirmResponse,
    summary="Upload a .zip (multipart/form-data); server streams to S3",
)
async def upload_zip_file(
    file: UploadFile = File(..., description="Zip archive (.zip)"),
) -> UploadConfirmResponse:
    bucket = _require_s3_bucket()
    raw_name = (file.filename or "").strip()
    if not raw_name.lower().endswith(".zip"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="filename must end with .zip",
        )
    try:
        safe_name = s3_presign.safe_object_basename(raw_name)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    upload_id = str(uuid.uuid4())
    key = s3_presign.build_upload_key(upload_id, safe_name)
    content_type = (file.content_type or "").strip() or "application/zip"
    s3_uri = f"s3://{bucket}/{key}"
    object_url = s3_presign.object_https_url(bucket, settings.S3_REGION, key)

    tmp_path: str | None = None
    total = 0
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            tmp_path = tmp.name
            while True:
                block = await file.read(_READ_CHUNK)
                if not block:
                    break
                total += len(block)
                if total > settings.S3_MAX_FILE_SIZE_BYTES:
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"file exceeds limit {settings.S3_MAX_FILE_SIZE_BYTES} bytes.",
                    )
                tmp.write(block)
            tmp.flush()

        if total == 0:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="empty file.")

        if not zipfile.is_zipfile(tmp_path):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="uploaded file is not a valid zip archive.",
            )

        client = s3_presign.s3_client()
        with open(tmp_path, "rb") as body:
            client.upload_fileobj(
                body,
                bucket,
                key,
                ExtraArgs={"ContentType": content_type},
            )
    except HTTPException:
        raise
    except (ClientError, OSError, RuntimeError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"S3 upload failed: {exc}",
        ) from exc
    finally:
        await file.close()
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    langs: dict[str, int] = {}
    warnings: list[str] = []
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "upload_kind": "zip_direct",
        "file_count": 1,
        "total_size_bytes": total,
        "detected_languages": langs,
        "s3_path": key,
        "s3_uri": s3_uri,
        "object_url": object_url,
        "bucket": bucket,
        "key": key,
    }

    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=upload_id,
            status="VALIDATED",
            file_count=1,
            total_size_bytes=total,
            detected_languages=langs,
            validation_warnings=warnings,
            s3_path=key,
            s3_uri=s3_uri,
            object_url=object_url,
        ),
        errors=[],
    )


@router.get(
    "/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Upload status for an upload_id returned by POST /upload-zip/file",
)
def zip_upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=str(record["status"]),
            file_count=int(record.get("file_count", 0)),
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", "")),
            s3_uri=str(record.get("s3_uri", "")),
            object_url=str(record.get("object_url", "")),
        ),
        errors=[],
    )
