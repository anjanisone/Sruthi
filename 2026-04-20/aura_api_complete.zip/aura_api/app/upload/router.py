from __future__ import annotations

import math
import uuid

from botocore.exceptions import ClientError
from fastapi import APIRouter, HTTPException, status

from .. import settings
from ..models import (
    MultipartUploadedPart,
    UploadConfirmData,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
    ZipMultipartAbortData,
    ZipMultipartAbortRequest,
    ZipMultipartAbortResponse,
    ZipMultipartCompleteRequest,
    ZipMultipartInitData,
    ZipMultipartInitRequest,
    ZipMultipartInitResponse,
    ZipMultipartPartUrlData,
    ZipMultipartPartUrlRequest,
    ZipMultipartPartUrlResponse,
)
from ..state import STATE
from . import s3_presign

_MIN_PART_WHEN_MULTIPLE = 5 * 1024 * 1024
_MAX_PARTS = 10000

router = APIRouter(prefix="/upload-zip", tags=["upload-zip"])


def _require_s3_bucket() -> str:
    if not settings.S3_BUCKET:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="S3 uploads are not configured. Set AURA_S3_BUCKET and AWS credentials (multipart: CreateMultipartUpload, UploadPart, CompleteMultipartUpload, AbortMultipartUpload).",
        )
    return settings.S3_BUCKET


def _part_plan(file_size_bytes: int, part_size_bytes: int) -> int:
    if part_size_bytes <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="part_size_bytes must be positive.")
    part_count = math.ceil(file_size_bytes / part_size_bytes)
    if part_count > _MAX_PARTS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Would need {part_count} parts; maximum is {_MAX_PARTS}. Increase part_size_bytes.",
        )
    if part_count > 1 and part_size_bytes < _MIN_PART_WHEN_MULTIPLE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="When more than one part is required, part_size_bytes must be at least 5 MiB (AWS S3).",
        )
    return part_count


def _get_zip_multipart_record(upload_id: str) -> dict:
    rec = STATE.uploads_status.get(upload_id)
    if not rec or rec.get("upload_kind") != "zip_multipart":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id or not a zip multipart upload.")
    return rec


def _require_uploading(rec: dict) -> None:
    if rec.get("status") != "UPLOADING":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="This multipart upload is not in UPLOADING state (already completed, aborted, or finished).",
        )


@router.post(
    "/multipart/init",
    response_model=ZipMultipartInitResponse,
    summary="Start S3 multipart upload for a zip; returns part plan and S3 UploadId",
)
def zip_multipart_init(payload: ZipMultipartInitRequest) -> ZipMultipartInitResponse:
    bucket = _require_s3_bucket()
    if payload.file_size_bytes <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="file_size_bytes must be positive.")
    if payload.file_size_bytes > settings.S3_MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"file_size_bytes exceeds limit {settings.S3_MAX_FILE_SIZE_BYTES}.",
        )
    try:
        safe_name = s3_presign.safe_object_basename(payload.file_name)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    part_count = _part_plan(payload.file_size_bytes, payload.part_size_bytes)
    upload_id = str(uuid.uuid4())
    key = s3_presign.build_upload_key(upload_id, safe_name)
    expires = settings.S3_PRESIGN_EXPIRES_SECONDS

    try:
        s3_mpu_id = s3_presign.create_multipart_upload(
            bucket=bucket,
            key=key,
            content_type=payload.content_type,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc

    s3_uri = f"s3://{bucket}/{key}"
    object_url = s3_presign.object_https_url(bucket, settings.S3_REGION, key)

    STATE.uploads_status[upload_id] = {
        "status": "UPLOADING",
        "upload_kind": "zip_multipart",
        "file_count": 0,
        "total_size_bytes": 0,
        "detected_languages": {},
        "s3_path": key,
        "s3_uri": s3_uri,
        "object_url": object_url,
        "bucket": bucket,
        "key": key,
        "content_type": payload.content_type,
        "expected_size": payload.file_size_bytes,
        "part_size_bytes": payload.part_size_bytes,
        "part_count": part_count,
        "s3_multipart_upload_id": s3_mpu_id,
    }

    return ZipMultipartInitResponse(
        success=True,
        data=ZipMultipartInitData(
            upload_id=upload_id,
            s3_multipart_upload_id=s3_mpu_id,
            s3_path=key,
            s3_uri=s3_uri,
            object_url=object_url,
            part_size_bytes=payload.part_size_bytes,
            part_count=part_count,
            expires_in=expires,
            max_file_size_bytes=settings.S3_MAX_FILE_SIZE_BYTES,
        ),
        errors=[],
    )


@router.post(
    "/multipart/part-url",
    response_model=ZipMultipartPartUrlResponse,
    summary="Pre-signed S3 URL to HTTP PUT one part of the zip",
)
def zip_multipart_part_url(payload: ZipMultipartPartUrlRequest) -> ZipMultipartPartUrlResponse:
    _require_s3_bucket()
    rec = _get_zip_multipart_record(payload.upload_id)
    _require_uploading(rec)
    part_count = int(rec["part_count"])
    if payload.part_number < 1 or payload.part_number > part_count:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"part_number must be between 1 and {part_count} for this upload.",
        )
    bucket = str(rec["bucket"])
    key = str(rec["key"])
    s3_mpu_id = str(rec["s3_multipart_upload_id"])
    expires = settings.S3_PRESIGN_EXPIRES_SECONDS
    try:
        url = s3_presign.presigned_upload_part_url(
            bucket=bucket,
            key=key,
            s3_upload_id=s3_mpu_id,
            part_number=payload.part_number,
            expires_in=expires,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc

    return ZipMultipartPartUrlResponse(
        success=True,
        data=ZipMultipartPartUrlData(
            presigned_url=url,
            part_number=payload.part_number,
            expires_in=expires,
        ),
        errors=[],
    )


def _normalize_parts(parts: list[MultipartUploadedPart]) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    for p in parts:
        etag = p.etag.strip()
        if not etag:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Each part must include a non-empty etag.")
        out.append((p.part_number, etag))
    return out


@router.post(
    "/multipart/complete",
    response_model=UploadConfirmResponse,
    summary="Complete S3 multipart upload after all part PUTs succeeded",
)
def zip_multipart_complete(payload: ZipMultipartCompleteRequest) -> UploadConfirmResponse:
    rec = _get_zip_multipart_record(payload.upload_id)
    _require_uploading(rec)
    bucket = str(rec["bucket"])
    key = str(rec["key"])
    s3_mpu_id = str(rec["s3_multipart_upload_id"])
    part_count = int(rec["part_count"])
    expected = set(range(1, part_count + 1))
    normalized = _normalize_parts(list(payload.parts))
    got = {num for num, _ in normalized}
    if got != expected or len(normalized) != part_count:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provide exactly one etag per part for part_numbers 1 through {part_count} (no duplicates).",
        )

    try:
        s3_presign.complete_multipart_upload(
            bucket=bucket,
            key=key,
            s3_upload_id=s3_mpu_id,
            parts=normalized,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    try:
        head = s3_presign.head_object(bucket=bucket, key=key)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="CompleteMultipartUpload returned but HeadObject did not find the object.",
        ) from None
    except ClientError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=f"S3 HeadObject failed: {exc}") from exc

    size = int(head["ContentLength"])
    expected_size = int(rec.get("expected_size") or 0)
    if expected_size and size != expected_size:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Assembled object size {size} does not match declared file_size_bytes {expected_size}.",
        )

    langs: dict[str, int] = {}
    warnings: list[str] = []
    STATE.uploads_status[payload.upload_id] = {
        **rec,
        "status": "COMPLETED",
        "file_count": 1,
        "total_size_bytes": size,
        "detected_languages": langs,
        "s3_path": key,
    }

    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=payload.upload_id,
            status="VALIDATED",
            file_count=1,
            total_size_bytes=size,
            detected_languages=langs,
            validation_warnings=warnings,
            s3_path=key,
            s3_uri=str(rec.get("s3_uri", "")),
            object_url=str(rec.get("object_url", "")),
        ),
        errors=[],
    )


@router.post(
    "/multipart/abort",
    response_model=ZipMultipartAbortResponse,
    summary="Abort in-progress S3 multipart upload",
)
def zip_multipart_abort(payload: ZipMultipartAbortRequest) -> ZipMultipartAbortResponse:
    rec = _get_zip_multipart_record(payload.upload_id)
    _require_uploading(rec)
    bucket = str(rec["bucket"])
    key = str(rec["key"])
    s3_mpu_id = str(rec["s3_multipart_upload_id"])
    try:
        s3_presign.abort_multipart_upload(bucket=bucket, key=key, s3_upload_id=s3_mpu_id)
    except ClientError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=f"S3 AbortMultipartUpload failed: {exc}") from exc

    STATE.uploads_status[payload.upload_id] = {
        "status": "ABORTED",
        "upload_kind": "zip_multipart",
        "file_count": 0,
        "total_size_bytes": 0,
        "detected_languages": {},
        "s3_path": "",
        "s3_uri": "",
        "object_url": "",
    }

    return ZipMultipartAbortResponse(
        success=True,
        data=ZipMultipartAbortData(upload_id=payload.upload_id, aborted=True),
        errors=[],
    )


@router.get(
    "/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Check zip multipart upload status",
)
def zip_upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=str(record["status"]),
            file_count=int(record.get("file_count", 0)),
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", "")),
            s3_uri=str(record.get("s3_uri", "")),
            object_url=str(record.get("object_url", "")),
        ),
        errors=[],
    )
