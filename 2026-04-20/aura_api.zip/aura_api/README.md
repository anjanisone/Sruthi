# AURA API (FastAPI)

Demo API with in-memory state. Run:

```bash
cd aura_api && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt && uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

Env vars: `AURA_*` in `app/settings.py`. Defaults: token exchange is `local` (STS replay, no C2C URL).

Shipped next to this folder: `aura_api.zip` (this tree) and `aura_api_flask.zip` (Flask twin from `2026-04-17` snapshot for reference).
