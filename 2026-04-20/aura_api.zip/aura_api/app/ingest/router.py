from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException, Query, status

from ..models import (
    FileListData,
    FileListResponse,
    FilePreviewData,
    FilePreviewResponse,
    Pagination,
    RepoCloneData,
    RepoCloneRequest,
    RepoCloneResponse,
    ZipCloneRequest,
)
from ..state import STATE

router = APIRouter(tags=["ingest"])


def _norm_list_path(current_path: str) -> str:
    p = (current_path or "").strip()
    if not p or p == "/":
        return ""
    return p.rstrip("/") + "/"


def _start_clone(upload_id: str, source: str) -> RepoCloneResponse:
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0, "source": source}
    STATE.seed_ingest_tree(upload_id)
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )


@router.post(
    "/ingest/repo-clone",
    response_model=RepoCloneResponse,
    summary="Generic repository clone (Bitbucket/GitHub compatible shape)",
)
def repo_clone(payload: RepoCloneRequest) -> RepoCloneResponse:
    _ = payload
    return _start_clone(str(uuid.uuid4()), "repo_clone")


@router.post(
    "/ingest/bitbucket-clone",
    response_model=RepoCloneResponse,
    summary="Clone from Bitbucket into an upload workspace",
)
def bitbucket_clone(payload: RepoCloneRequest) -> RepoCloneResponse:
    _ = payload
    return _start_clone(str(uuid.uuid4()), "bitbucket")


@router.post(
    "/ingest/github-clone",
    response_model=RepoCloneResponse,
    summary="Clone from GitHub into an upload workspace",
)
def github_clone(payload: RepoCloneRequest) -> RepoCloneResponse:
    _ = payload
    return _start_clone(str(uuid.uuid4()), "github")


@router.post(
    "/ingest/zip-clone",
    response_model=RepoCloneResponse,
    summary="Ingest a direct zip upload (same workspace shape as repo clones)",
)
def zip_clone(payload: ZipCloneRequest) -> RepoCloneResponse:
    _ = payload
    return _start_clone(str(uuid.uuid4()), "zip")


@router.get(
    "/ingest/{upload_id}/files",
    response_model=FileListResponse,
    summary="Browse files for an upload / clone workspace (code browsing)",
)
def list_ingest_files(
    upload_id: str,
    current_path: str = Query("", description="Directory path to list (e.g. src/ or empty for root)"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> FileListResponse:
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    STATE.seed_ingest_tree(upload_id)
    key = _norm_list_path(current_path)
    tree = STATE.ingest_file_trees.get(upload_id, {})
    items = list(tree.get(key, []))
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return FileListResponse(
        success=True,
        data=FileListData(
            upload_id=upload_id,
            current_path=key if key else "/",
            items=page_items,
            pagination=Pagination(
                page=page,
                page_size=page_size,
                total_items=total,
                total_pages=total_pages,
            ),
        ),
        errors=[],
    )


@router.get(
    "/ingest/{upload_id}/files/preview",
    response_model=FilePreviewResponse,
    summary="Preview a single file from the ingest workspace (code browsing)",
)
def preview_ingest_file(
    upload_id: str,
    path: str = Query(..., description="File path relative to repo root (e.g. src/api/UserController.java)"),
) -> FilePreviewResponse:
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown upload_id.")
    STATE.seed_ingest_tree(upload_id)
    tree = STATE.ingest_file_trees[upload_id]
    target = None
    for lst in tree.values():
        for it in lst:
            if it.path == path and it.type == "file":
                target = it
                break
        if target:
            break
    if target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found for path.")
    lang = target.language or "text"
    return FilePreviewResponse(
        success=True,
        data=FilePreviewData(
            path=target.path,
            language=lang,
            size_bytes=target.size_bytes or 0,
            line_count=42,
            content=f"# Preview for {target.path}\n(package com.example; …)",
            syntax_highlighted=True,
            encoding="UTF-8",
        ),
        errors=[],
    )
