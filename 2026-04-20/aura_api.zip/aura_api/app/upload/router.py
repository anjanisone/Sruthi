from fastapi import APIRouter

from ..models import (
    PresignedUrlData,
    PresignedUrlRequest,
    PresignedUrlResponse,
    UploadConfirmData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE

router = APIRouter(tags=["upload"])


@router.post(
    "/upload/presigned-url",
    response_model=PresignedUrlResponse,
    summary="Generate a pre-signed S3 URL for direct code upload",
)
def create_presigned_url(payload: PresignedUrlRequest) -> PresignedUrlResponse:
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "UPLOADING", "file_count": 0}
    return PresignedUrlResponse(
        success=True,
        data=PresignedUrlData(
            upload_id=upload_id,
            presigned_url="https://s3.amazonaws.com/...",
            expires_in=3600,
            s3_path=f"jobs/{upload_id}/input/",
            max_file_size_bytes=524288000,
        ),
        errors=[],
    )


@router.post(
    "/upload/confirm",
    response_model=UploadConfirmResponse,
    summary="Confirm upload completion and trigger validation",
)
def confirm_upload(payload: UploadConfirmRequest) -> UploadConfirmResponse:
    langs = {"java": 80, "python": 50}
    STATE.uploads_status[payload.upload_id] = {
        "status": "COMPLETED",
        "file_count": 150,
        "total_size_bytes": 52428800,
        "detected_languages": langs,
        "s3_path": f"jobs/{payload.upload_id}/input/",
    }
    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=payload.upload_id,
            status="VALIDATED",
            file_count=150,
            total_size_bytes=52428800,
            detected_languages=langs,
            validation_warnings=[],
        ),
        errors=[],
    )


@router.get(
    "/upload/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Check upload/clone status",
)
def upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id) or {
        "status": "CLONING",
        "file_count": 150,
        "total_size_bytes": 52428800,
        "detected_languages": {"java": 80},
        "s3_path": f"jobs/{upload_id}/input/",
    }
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=record["status"],
            file_count=record["file_count"],
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", f"jobs/{upload_id}/input/")),
        ),
        errors=[],
    )
