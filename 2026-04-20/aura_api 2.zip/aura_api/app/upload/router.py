import uuid
import zipfile
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile, status

from ..models import (
    LocalZipUploadData,
    LocalZipUploadResponse,
    PresignedUrlData,
    PresignedUrlRequest,
    PresignedUrlResponse,
    UploadConfirmData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE

router = APIRouter(tags=["upload"])

# On-disk staging for local dev: multipart zip uploads (not used by the mocked S3 presign flow).
_LOCAL_UPLOAD_ROOT = Path(__file__).resolve().parent.parent / ".local_uploads"
_CHUNK = 1024 * 1024


@router.post(
    "/upload/local-zip",
    response_model=LocalZipUploadResponse,
    summary="Upload a zip file from disk (local dev; saves under .local_uploads/)",
)
async def upload_local_zip(file: UploadFile = File(..., description="Zip archive from your machine")) -> LocalZipUploadResponse:
    name = (file.filename or "").strip().lower()
    if not name.endswith(".zip"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="filename must end with .zip",
        )
    upload_id = str(uuid.uuid4())
    dest_dir = _LOCAL_UPLOAD_ROOT / upload_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / "upload.zip"
    total = 0
    try:
        with dest_path.open("wb") as out:
            while True:
                chunk = await file.read(_CHUNK)
                if not chunk:
                    break
                total += len(chunk)
                out.write(chunk)
    except OSError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"failed to write upload: {exc}",
        ) from exc
    finally:
        await file.close()

    if not zipfile.is_zipfile(dest_path):
        dest_path.unlink(missing_ok=True)
        try:
            dest_dir.rmdir()
        except OSError:
            pass
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="uploaded bytes are not a valid zip file",
        )

    try:
        with zipfile.ZipFile(dest_path) as zf:
            zip_entry_count = len(zf.infolist())
    except zipfile.BadZipFile:
        dest_path.unlink(missing_ok=True)
        try:
            dest_dir.rmdir()
        except OSError:
            pass
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="corrupt or unreadable zip file",
        ) from None

    abs_path = str(dest_path.resolve())
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "file_count": zip_entry_count,
        "total_size_bytes": total,
        "s3_path": abs_path,
    }
    return LocalZipUploadResponse(
        success=True,
        data=LocalZipUploadData(
            upload_id=upload_id,
            saved_path=abs_path,
            size_bytes=total,
            zip_entry_count=zip_entry_count,
        ),
        errors=[],
    )


@router.post(
    "/upload/presigned-url",
    response_model=PresignedUrlResponse,
    summary="Generate a pre-signed S3 URL for direct code upload",
)
def create_presigned_url(payload: PresignedUrlRequest) -> PresignedUrlResponse:
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "UPLOADING", "file_count": 0}
    return PresignedUrlResponse(
        success=True,
        data=PresignedUrlData(
            upload_id=upload_id,
            presigned_url="https://s3.amazonaws.com/...",
            expires_in=3600,
            s3_path=f"jobs/{upload_id}/input/",
            max_file_size_bytes=524288000,
        ),
        errors=[],
    )


@router.post(
    "/upload/confirm",
    response_model=UploadConfirmResponse,
    summary="Confirm upload completion and trigger validation",
)
def confirm_upload(payload: UploadConfirmRequest) -> UploadConfirmResponse:
    langs = {"java": 80, "python": 50}
    STATE.uploads_status[payload.upload_id] = {
        "status": "COMPLETED",
        "file_count": 150,
        "total_size_bytes": 52428800,
        "detected_languages": langs,
        "s3_path": f"jobs/{payload.upload_id}/input/",
    }
    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(
            upload_id=payload.upload_id,
            status="VALIDATED",
            file_count=150,
            total_size_bytes=52428800,
            detected_languages=langs,
            validation_warnings=[],
        ),
        errors=[],
    )


@router.get(
    "/upload/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Check upload/clone status",
)
def upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id) or {
        "status": "CLONING",
        "file_count": 150,
        "total_size_bytes": 52428800,
        "detected_languages": {"java": 80},
        "s3_path": f"jobs/{upload_id}/input/",
    }
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(
            upload_id=upload_id,
            status=record["status"],
            file_count=record["file_count"],
            total_size_bytes=int(record.get("total_size_bytes", 0)),
            detected_languages=dict(record.get("detected_languages", {})),
            s3_path=str(record.get("s3_path", f"jobs/{upload_id}/input/")),
        ),
        errors=[],
    )
