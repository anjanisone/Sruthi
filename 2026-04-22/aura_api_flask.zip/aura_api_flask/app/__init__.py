from __future__ import annotations

from flask import Flask, Response, request

from .outbound.token_provider_factory import create_outbound_token_provider
from .security import register_auth_hook


def create_app() -> Flask:
    app = Flask(__name__)
    app.json.sort_keys = False
    app.outbound_token_provider = create_outbound_token_provider()

    register_auth_hook(app)

    @app.before_request
    def _options_preflight() -> Response | None:
        if request.method == "OPTIONS":
            return Response(status=204)
        return None

    from .auth.routes import bp as auth_bp
    from .ingest import bp as ingest_bp
    from .jobs import bp as jobs_bp
    from .kb import bp as kb_bp
    from .review import bp as review_bp
    from .upload.routes import bp as upload_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(kb_bp)
    app.register_blueprint(ingest_bp)
    app.register_blueprint(review_bp)

    from .views import register_routes

    register_routes(app)
    return app
