from __future__ import annotations

import logging
import os
import tempfile
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from http import HTTPStatus
from pathlib import Path

from botocore.exceptions import ClientError, ConnectTimeoutError
from flask import Blueprint, Response, jsonify, request
from pydantic import BaseModel

from .. import settings
from ..models import (
    UploadConfirmData,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
)
from ..state import STATE
from . import s3_presign

_READ_CHUNK = 1024 * 1024
_PROGRESS_LOG_INTERVAL_BYTES = 10 * 1024 * 1024
logger = logging.getLogger(__name__)
_UPLOAD_ZIP_UI_PATH = Path(__file__).with_name("upload_zip.html")
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="s3upload")

bp = Blueprint("upload_zip", __name__, url_prefix="/upload-zip")


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _upload_body_to_s3(*, upload_id: str, tmp_path: str, bucket: str, key: str, content_type: str) -> None:
    t0 = time.perf_counter()
    logger.info(
        "upload_zip s3_thread_start upload_id=%s bucket=%s key=%s tmp_path=%s",
        upload_id,
        bucket,
        key,
        tmp_path,
    )
    client = s3_presign.s3_client()
    with open(tmp_path, "rb") as body:
        client.upload_fileobj(
            body,
            bucket,
            key,
            ExtraArgs={"ContentType": content_type},
        )
    logger.info(
        "upload_zip s3_thread_done upload_id=%s duration_s=%.3f",
        upload_id,
        time.perf_counter() - t0,
    )


@bp.get("/ui")
def upload_zip_ui():
    return Response(_UPLOAD_ZIP_UI_PATH.read_text(encoding="utf-8"), mimetype="text/html; charset=utf-8")


@bp.post("/file")
def upload_zip_file():
    wall_t0 = time.perf_counter()
    bucket = settings.S3_BUCKET
    if not bucket:
        return (
            jsonify(
                {
                    "detail": "S3 uploads are not configured. Set AURA_S3_BUCKET and AWS credentials with s3:PutObject on the upload prefix."
                }
            ),
            HTTPStatus.SERVICE_UNAVAILABLE,
        )

    f = request.files.get("file")
    if not f or not (f.filename or "").strip():
        return jsonify({"detail": "missing multipart field 'file'"}), HTTPStatus.BAD_REQUEST

    raw_name = (f.filename or "").strip()
    if not raw_name.lower().endswith(".zip"):
        return jsonify({"detail": "filename must end with .zip"}), HTTPStatus.BAD_REQUEST
    try:
        safe_name = s3_presign.safe_object_basename(raw_name)
    except ValueError as exc:
        return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST

    upload_id = str(uuid.uuid4())
    key = s3_presign.build_upload_key(upload_id, safe_name)
    content_type = (f.content_type or "").strip() or "application/zip"
    s3_uri = f"s3://{bucket}/{key}"
    object_url = s3_presign.object_https_url(bucket, settings.S3_REGION, key)

    tmp_path: str | None = None
    total = 0
    read_deadline = settings.UPLOAD_READ_CHUNK_TIMEOUT_SECONDS
    s3_deadline = settings.UPLOAD_S3_PUT_TIMEOUT_SECONDS
    logger.info(
        "upload_zip begin upload_id=%s safe_name=%s key=%s bucket=%s region=%s read_chunk_timeout_s=%s s3_put_timeout_s=%s",
        upload_id,
        safe_name,
        key,
        bucket,
        settings.S3_REGION,
        read_deadline,
        s3_deadline,
    )

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            tmp_path = tmp.name
            logger.info(
                "upload_zip disk_write_open upload_id=%s tmp_path=%s chunk_bytes=%s",
                upload_id,
                tmp_path,
                _READ_CHUNK,
            )
            next_progress_log = _PROGRESS_LOG_INTERVAL_BYTES
            chunk_index = 0
            while True:
                t_chunk = time.perf_counter()
                block = f.read(_READ_CHUNK)
                if time.perf_counter() - t_chunk > read_deadline:
                    return (
                        jsonify(
                            {
                                "detail": (
                                    "Timed out waiting for the next part of the upload body. "
                                    "If the browser never finishes sending, check VPN/proxy body limits, corporate SSL inspection, "
                                    "or antivirus throttling large multipart POSTs (often seen on Windows)."
                                )
                            }
                        ),
                        HTTPStatus.REQUEST_TIMEOUT,
                    )
                if not block:
                    break
                chunk_index += 1
                total += len(block)
                if total > settings.S3_MAX_FILE_SIZE_BYTES:
                    return (
                        jsonify({"detail": f"file exceeds limit {settings.S3_MAX_FILE_SIZE_BYTES} bytes."}),
                        HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                    )
                tmp.write(block)
                if total >= next_progress_log:
                    logger.info(
                        "upload_zip body_progress upload_id=%s bytes_received=%s chunks=%s elapsed_s=%.2f",
                        upload_id,
                        total,
                        chunk_index,
                        time.perf_counter() - wall_t0,
                    )
                    while next_progress_log <= total:
                        next_progress_log += _PROGRESS_LOG_INTERVAL_BYTES
            tmp.flush()

        logger.info(
            "upload_zip body_read_done upload_id=%s total_bytes=%s chunks=%s elapsed_s=%.2f",
            upload_id,
            total,
            chunk_index,
            time.perf_counter() - wall_t0,
        )

        if total == 0:
            logger.warning("upload_zip empty_body upload_id=%s", upload_id)
            return jsonify({"detail": "empty file."}), HTTPStatus.BAD_REQUEST

        zip_ok = zipfile.is_zipfile(tmp_path)
        logger.info("upload_zip zip_probe upload_id=%s is_zipfile=%s", upload_id, zip_ok)
        if not zip_ok:
            return jsonify({"detail": "uploaded file is not a valid zip archive."}), HTTPStatus.BAD_REQUEST

        logger.info(
            "upload_zip s3_put_scheduled upload_id=%s deadline_s=%s elapsed_before_s3_s=%.2f",
            upload_id,
            s3_deadline,
            time.perf_counter() - wall_t0,
        )
        fut = _executor.submit(
            _upload_body_to_s3,
            upload_id=upload_id,
            tmp_path=tmp_path,
            bucket=bucket,
            key=key,
            content_type=content_type,
        )
        try:
            fut.result(timeout=s3_deadline)
        except FuturesTimeout:
            return (
                jsonify(
                    {
                        "detail": (
                            "Timed out while transferring the file to S3. "
                            "Check AWS credentials, bucket region (AURA_S3_REGION / AWS_DEFAULT_REGION), network path, "
                            "HTTP_PROXY/HTTPS_PROXY if on a corporate network, "
                            "and set AWS_EC2_METADATA_DISABLED=true on non-EC2 hosts to avoid long instance-metadata waits."
                        )
                    }
                ),
                HTTPStatus.GATEWAY_TIMEOUT,
            )
    except (ClientError, OSError, RuntimeError) as exc:
        logger.exception(
            "upload_zip unexpected_error upload_id=%s elapsed_s=%.2f",
            upload_id,
            time.perf_counter() - wall_t0,
        )
        detail = f"S3 upload failed: {exc}"
        if isinstance(exc, ConnectTimeoutError):
            detail += (
                " (No route to S3: set HTTP_PROXY/HTTPS_PROXY/NO_PROXY in .env, or AURA_HTTP_PROXY/"
                "AURA_HTTPS_PROXY/AURA_NO_PROXY; see .env.example. Wrong proxy port is a common cause.)"
            )
        return jsonify({"detail": detail}), HTTPStatus.SERVICE_UNAVAILABLE
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
                logger.debug("upload_zip tmp_removed upload_id=%s path=%s", upload_id, tmp_path)
            except OSError as unlink_err:
                logger.warning(
                    "upload_zip tmp_unlink_failed upload_id=%s path=%s err=%s",
                    upload_id,
                    tmp_path,
                    unlink_err,
                )

    logger.info(
        "upload_zip success upload_id=%s total_bytes=%s total_elapsed_s=%.2f",
        upload_id,
        total,
        time.perf_counter() - wall_t0,
    )

    langs: dict[str, int] = {}
    warnings: list[str] = []
    STATE.uploads_status[upload_id] = {
        "status": "COMPLETED",
        "upload_kind": "zip_direct",
        "file_count": 1,
        "total_size_bytes": total,
        "detected_languages": langs,
        "s3_path": key,
        "s3_uri": s3_uri,
        "object_url": object_url,
        "bucket": bucket,
        "key": key,
    }

    return (
        _j(
            UploadConfirmResponse(
                success=True,
                data=UploadConfirmData(
                    upload_id=upload_id,
                    status="VALIDATED",
                    file_count=1,
                    total_size_bytes=total,
                    detected_languages=langs,
                    validation_warnings=warnings,
                    s3_path=key,
                    s3_uri=s3_uri,
                    object_url=object_url,
                ),
                errors=[],
            )
        ),
        HTTPStatus.OK,
    )


@bp.get("/<upload_id>/status")
def zip_upload_status(upload_id: str):
    record = STATE.uploads_status.get(upload_id)
    if not record:
        return jsonify({"detail": "Unknown upload_id."}), HTTPStatus.NOT_FOUND
    return (
        _j(
            UploadStatusResponse(
                success=True,
                data=UploadStatusData(
                    upload_id=upload_id,
                    status=str(record["status"]),
                    file_count=int(record.get("file_count", 0)),
                    total_size_bytes=int(record.get("total_size_bytes", 0)),
                    detected_languages=dict(record.get("detected_languages", {})),
                    s3_path=str(record.get("s3_path", "")),
                    s3_uri=str(record.get("s3_uri", "")),
                    object_url=str(record.get("object_url", "")),
                ),
                errors=[],
            )
        ),
        HTTPStatus.OK,
    )
