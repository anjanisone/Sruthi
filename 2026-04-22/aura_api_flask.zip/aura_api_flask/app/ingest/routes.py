from __future__ import annotations

import uuid
from http import HTTPStatus

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ValidationError

from ..models import (
    FileListData,
    FileListResponse,
    FilePreviewData,
    FilePreviewResponse,
    Pagination,
    RepoCloneData,
    RepoCloneRequest,
    RepoCloneResponse,
    ZipCloneRequest,
)
from ..state import STATE

bp = Blueprint("ingest", __name__)


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _norm_list_path(current_path: str) -> str:
    p = (current_path or "").strip()
    if not p or p == "/":
        return ""
    return p.rstrip("/") + "/"


def _start_clone(upload_id: str, source: str) -> RepoCloneResponse:
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0, "source": source}
    STATE.seed_ingest_tree(upload_id)
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )


@bp.post("/ingest/repo-clone")
def repo_clone():
    try:
        _ = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    return _j(_start_clone(str(uuid.uuid4()), "repo_clone"))


@bp.post("/ingest/bitbucket-clone")
def bitbucket_clone():
    try:
        _ = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    return _j(_start_clone(str(uuid.uuid4()), "bitbucket"))


@bp.post("/ingest/github-clone")
def github_clone():
    try:
        _ = RepoCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    return _j(_start_clone(str(uuid.uuid4()), "github"))


@bp.post("/ingest/zip-clone")
def zip_clone():
    try:
        _ = ZipCloneRequest.model_validate(request.get_json() or {})
    except ValidationError as exc:
        return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
    return _j(_start_clone(str(uuid.uuid4()), "zip"))


@bp.get("/ingest/<upload_id>/files")
def list_ingest_files(upload_id: str):
    current_path = request.args.get("current_path", "")
    page = int(request.args.get("page", "1"))
    page_size = int(request.args.get("page_size", "50"))
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        return jsonify({"detail": "Unknown upload_id."}), HTTPStatus.NOT_FOUND
    STATE.seed_ingest_tree(upload_id)
    key = _norm_list_path(current_path)
    tree = STATE.ingest_file_trees.get(upload_id, {})
    items = list(tree.get(key, []))
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    page_items = items[start : start + page_size]
    return _j(
        FileListResponse(
            success=True,
            data=FileListData(
                upload_id=upload_id,
                current_path=key if key else "/",
                items=page_items,
                pagination=Pagination(
                    page=page,
                    page_size=page_size,
                    total_items=total,
                    total_pages=total_pages,
                ),
            ),
            errors=[],
        )
    )


@bp.get("/ingest/<upload_id>/files/preview")
def preview_ingest_file(upload_id: str):
    path = request.args.get("path")
    if not path:
        return jsonify({"detail": "path query parameter is required."}), HTTPStatus.BAD_REQUEST
    if upload_id not in STATE.uploads_status and upload_id not in STATE.ingest_file_trees:
        return jsonify({"detail": "Unknown upload_id."}), HTTPStatus.NOT_FOUND
    STATE.seed_ingest_tree(upload_id)
    tree = STATE.ingest_file_trees[upload_id]
    target = None
    for lst in tree.values():
        for it in lst:
            if it.path == path and it.type == "file":
                target = it
                break
        if target:
            break
    if target is None:
        return jsonify({"detail": "File not found for path."}), HTTPStatus.NOT_FOUND
    lang = target.language or "text"
    return _j(
        FilePreviewResponse(
            success=True,
            data=FilePreviewData(
                path=target.path,
                language=lang,
                size_bytes=target.size_bytes or 0,
                line_count=42,
                content=f"# Preview for {target.path}\n(package com.example; …)",
                syntax_highlighted=True,
                encoding="UTF-8",
            ),
            errors=[],
        )
    )
