from __future__ import annotations

from flask import Flask, Response, jsonify

from . import settings

_DOCS_OFFLINE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>AURA API — docs (offline)</title></head>
<body style="font-family:system-ui,sans-serif;max-width:40rem;margin:2rem;line-height:1.5">
<h1>AURA API (Flask)</h1>
<p><strong>CDN-free mode.</strong> Interactive OpenAPI is not bundled; use JSON below or import into Postman.</p>
<ul>
  <li><a href="/meta"><code>GET /meta</code></a> — deployment / troubleshooting JSON</li>
  <li><a href="/upload-zip/ui"><code>GET /upload-zip/ui</code></a> — Zip upload page</li>
  <li><a href="/health"><code>GET /health</code></a></li>
</ul>
<p>To mirror FastAPI behavior, set <code>AURA_DOCS_CDN_OFFLINE=0</code> only if you add a hosted Swagger bundle later.</p>
</body></html>"""


def register_routes(app: Flask) -> None:
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/meta")
    def deployment_meta():
        return jsonify(
            {
                "service": "flask",
                "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "no_swagger_bundle",
                "if_docs_spins": (
                    "Flask build does not serve swagger-ui-dist by default; use /meta and curl/Postman against routes."
                ),
                "upload_logs": "Server logs: logger app.upload.routes, message prefix upload_zip",
                "upload_ui": "/upload-zip/ui",
                "upload_api": "POST /upload-zip/file",
                "s3_https_proxy": "set" if settings.BOTO_HTTPS_PROXY_CONFIGURED else "unset",
                "s3_connecttimeout_hint": (
                    "ConnectTimeout to S3: set HTTPS_PROXY/HTTP_PROXY/NO_PROXY in .env, or AURA_HTTPS_PROXY aliases; "
                    "see .env.example. Do not list s3.amazonaws.com in NO_PROXY unless IT requires it."
                ),
            }
        )

    if settings.DOCS_CDN_OFFLINE:

        @app.get("/docs")
        def docs_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

        @app.get("/redoc")
        def redoc_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

    @app.after_request
    def _cors(resp):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        return resp
