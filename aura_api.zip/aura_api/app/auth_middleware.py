from __future__ import annotations

from jwt.exceptions import PyJWTError
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from . import settings
from .jwt_tokens import decode_access_token


def _is_exempt_path(path: str) -> bool:
    if path in {"/", "/health", "/favicon.ico"}:
        return True
    if path.startswith("/docs") or path.startswith("/redoc"):
        return True
    if path in {"/openapi.json", "/auth/token"}:
        return True
    return False


class AuthEnforcementMiddleware(BaseHTTPMiddleware):
    """When AURA_REQUIRE_AUTH is enabled, require a valid Bearer JWT on all routes except docs and token."""

    async def dispatch(self, request: Request, call_next):
        if not settings.REQUIRE_AUTH:
            return await call_next(request)

        if request.method == "OPTIONS" or _is_exempt_path(request.url.path):
            return await call_next(request)

        authorization = request.headers.get("Authorization")
        if not authorization or not authorization.lower().startswith("bearer "):
            return JSONResponse({"detail": "Not authenticated"}, status_code=401)

        token = authorization.split(" ", 1)[1].strip()
        try:
            decode_access_token(token)
        except PyJWTError:
            return JSONResponse({"detail": "Invalid or expired token"}, status_code=401)

        return await call_next(request)
