from fastapi import FastAPI

from .routers import auth, events, files, jobs, outputs, repo, review, upload


app = FastAPI(
    title="AURA API",
    version="0.1.0",
    description="Documentation-first FastAPI prototype of the endpoints captured in Sruthi/6 API Plan screenshots.",
)

app.include_router(auth.router)
app.include_router(upload.router)
app.include_router(repo.router)
app.include_router(files.router)
app.include_router(jobs.router)
app.include_router(review.router)
app.include_router(outputs.router)
app.include_router(events.router)

