from datetime import datetime

from fastapi import APIRouter, Path

from ..models import (
    ReviewApproveRequest,
    ReviewApproveResponse,
    ReviewApproveData,
    ReviewGetResponse,
    ReviewGetData,
    ReviewRegenerateRequest,
    ReviewRegenerateResponse,
    ReviewRegenerateData,
    ReviewUpdateRequest,
    ReviewUpdateResponse,
    ReviewUpdateData,
)
from ..state import STATE

router = APIRouter(tags=["review"])


@router.get(
    "/jobs/{job_id}/review",
    response_model=ReviewGetResponse,
    summary="Get markdown specs for review after Phase 5",
)
def get_review_specs(job_id: str) -> ReviewGetResponse:
    STATE.seed_job(job_id)
    return ReviewGetResponse(
        success=True,
        data=ReviewGetData(
            job_id=job_id,
            status="AWAITING_REVIEW",
            phase_completed=5,
            specs=STATE.jobs[job_id]["review_specs"],
            review_expires_at=datetime.utcnow(),
            total_specs=45,
        ),
        errors=[],
    )


@router.put(
    "/jobs/{job_id}/review/{spec_path:path}",
    response_model=ReviewUpdateResponse,
    summary="Update a markdown spec during review",
)
def update_review_spec(
    job_id: str,
    payload: ReviewUpdateRequest,
    spec_path: str = Path(..., description="Spec path (URL-encoded)"),
) -> ReviewUpdateResponse:
    _ = job_id, payload
    return ReviewUpdateResponse(
        success=True,
        data=ReviewUpdateData(spec_path=spec_path, status="UPDATED"),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/review/approve",
    response_model=ReviewApproveResponse,
    summary="Approve reviewed markdown and continue to Phase 6",
)
def approve_review(job_id: str, payload: ReviewApproveRequest) -> ReviewApproveResponse:
    return ReviewApproveResponse(
        success=True,
        data=ReviewApproveData(job_id=job_id, status="RUNNING", current_phase=6, output_formats=payload.output_formats),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/review/regenerate",
    response_model=ReviewRegenerateResponse,
    summary="Request regeneration from Phase 4 after review",
)
def regenerate_from_review(job_id: str, payload: ReviewRegenerateRequest) -> ReviewRegenerateResponse:
    _ = payload
    return ReviewRegenerateResponse(
        success=True,
        data=ReviewRegenerateData(job_id=job_id, status="RUNNING", restarting_from_phase=4),
        errors=[],
    )

