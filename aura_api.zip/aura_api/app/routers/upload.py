from fastapi import APIRouter

from ..models import (
    PresignedUrlRequest,
    PresignedUrlResponse,
    PresignedUrlData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadConfirmData,
    UploadStatusResponse,
    UploadStatusData,
)
from ..state import STATE

router = APIRouter(tags=["upload"])


@router.post(
    "/upload/presigned-url",
    response_model=PresignedUrlResponse,
    summary="Generate a pre-signed S3 URL for direct code upload",
)
def create_presigned_url(payload: PresignedUrlRequest) -> PresignedUrlResponse:
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "UPLOADING", "file_count": 0}
    return PresignedUrlResponse(
        success=True,
        data=PresignedUrlData(
            upload_id=upload_id,
            presigned_url="https://s3.amazonaws.com/...",
            expires_in=3600,
            s3_path=f"jobs/{upload_id}/input/",
            max_file_size_bytes=524288000,
        ),
        errors=[],
    )


@router.post(
    "/upload/confirm",
    response_model=UploadConfirmResponse,
    summary="Confirm upload completion and trigger validation",
)
def confirm_upload(payload: UploadConfirmRequest) -> UploadConfirmResponse:
    STATE.uploads_status[payload.upload_id] = {"status": "COMPLETED", "file_count": 150}
    return UploadConfirmResponse(
        success=True,
        data=UploadConfirmData(upload_id=payload.upload_id, status="VALIDATED", file_count=150),
        errors=[],
    )


@router.get(
    "/upload/{upload_id}/status",
    response_model=UploadStatusResponse,
    summary="Check upload/clone status",
)
def upload_status(upload_id: str) -> UploadStatusResponse:
    record = STATE.uploads_status.get(upload_id) or {"status": "CLONING", "file_count": 150}
    return UploadStatusResponse(
        success=True,
        data=UploadStatusData(upload_id=upload_id, status=record["status"], file_count=record["file_count"]),
        errors=[],
    )

