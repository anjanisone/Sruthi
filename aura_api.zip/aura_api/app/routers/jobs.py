from datetime import datetime

from fastapi import APIRouter, Query

from ..models import (
    ChangeDetectionRequest,
    ChangeDetectionResponse,
    ChangeDetectionData,
    ChangeSummary,
    ChangedFile,
    DeleteJobResponse,
    DeleteJobData,
    DiscardEstimateResponse,
    DiscardEstimateData,
    JobChunksResponse,
    JobChunksData,
    JobDiffFormat,
    JobDiffResponse,
    JobDiffData,
    JobsEstimateRequest,
    JobsEstimateResponse,
    JobsEstimateData,
    ListJobsQuerySortBy,
    ListJobsResponse,
    ListJobsData,
    Pagination,
    ProceedFromEstimateRequest,
    ProceedFromEstimateResponse,
    ProceedFromEstimateData,
    RetryChunksRequest,
    RetryChunksResponse,
    RetryChunksData,
    JobRerunRequest,
    JobRerunResponse,
    JobRerunData,
    ChunkSummary,
)
from ..state import STATE

router = APIRouter(tags=["jobs"])


@router.get("/jobs", response_model=ListJobsResponse, summary="List jobs (with sorting + pagination)")
def list_jobs(
    sort_by: ListJobsQuerySortBy = Query(default=ListJobsQuerySortBy.created_at),
    sort_order: str = Query(default="desc", pattern="^(asc|desc)$"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=500),
) -> ListJobsResponse:
    _ = sort_by, sort_order
    STATE.seed_job("uuid")
    jobs = [STATE.jobs["uuid"]["summary"]]
    return ListJobsResponse(
        success=True,
        data=ListJobsData(
            jobs=jobs,
            pagination=Pagination(page=page, page_size=page_size, total_items=len(jobs), total_pages=1),
        ),
        errors=[],
    )


@router.delete("/jobs/{job_id}", response_model=DeleteJobResponse, summary="Cancel a running job or delete a completed job")
def delete_job(job_id: str) -> DeleteJobResponse:
    STATE.seed_job(job_id)
    prev = STATE.jobs[job_id]["summary"].status
    new = "CANCELLED" if prev == "RUNNING" else "DELETED"
    return DeleteJobResponse(
        success=True,
        data=DeleteJobData(job_id=job_id, previous_status=prev, new_status=new),
        errors=[],
    )


@router.post("/jobs/estimate", response_model=JobsEstimateResponse, summary="Run Phase 1 only and return cost estimation")
def estimate_job(payload: JobsEstimateRequest) -> JobsEstimateResponse:
    estimate_id = "uuid"
    STATE.estimates[estimate_id] = {"upload_id": payload.upload_id, "created_at": datetime.utcnow()}
    return JobsEstimateResponse(
        success=True,
        data=JobsEstimateData(
            estimate_id=estimate_id,
            status="ESTIMATED",
            estimation={
                "total_files": 150,
                "total_lines": 45000,
                "total_tokens": 125000,
                "estimated_chunks": 25,
                "oversized_files": 3,
                "languages_detected": {"java": 80, "python": 50, "javascript": 20},
            },
            cost_estimate={
                "bedrock_input_tokens": 125000,
                "bedrock_output_tokens": 75000,
                "estimated_cost_usd": 2.45,
                "pricing_model": "claude-3-sonnet",
                "breakdown": {"phase_4_input_cost": 1.0, "phase_4_output_cost": 1.0},
            },
            time_estimate={
                "estimated_duration_minutes": 15,
                "phase_breakdown": {"phase_1": 1, "phase_2": 1, "phase_3": 1, "phase_4": 10, "phase_5": 1},
            },
            phase_1_output_path=f"jobs/{estimate_id}/phase1/",
        ),
        errors=[],
    )


@router.post(
    "/jobs/estimate/{estimate_id}/proceed",
    response_model=ProceedFromEstimateResponse,
    summary="Continue from estimation to full job (skips Phase 1)",
)
def proceed_from_estimate(estimate_id: str, payload: ProceedFromEstimateRequest) -> ProceedFromEstimateResponse:
    _ = payload
    job_id = "uuid"
    STATE.seed_job(job_id)
    return ProceedFromEstimateResponse(
        success=True,
        data=ProceedFromEstimateData(
            job_id=job_id,
            status="RUNNING",
            starting_phase=2,
            skipped_phases=[1],
            message="Job started from Phase 2 (Phase 1 results reused from estimation)",
        ),
        errors=[],
    )


@router.delete(
    "/jobs/estimate/{estimate_id}",
    response_model=DiscardEstimateResponse,
    summary="Discard an estimate and cleanup (timeframed retention per spec)",
)
def discard_estimate(estimate_id: str) -> DiscardEstimateResponse:
    STATE.estimates.pop(estimate_id, None)
    return DiscardEstimateResponse(
        success=True,
        data=DiscardEstimateData(estimate_id=estimate_id, status="DISCARDED", cleanup_completed=True),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/rerun",
    response_model=JobRerunResponse,
    summary="Re-run job (failed chunks, specific chunks, from phase, or full rerun)",
)
def rerun_job(job_id: str, payload: JobRerunRequest) -> JobRerunResponse:
    STATE.seed_job(job_id)
    options = payload.options
    chunks = options.chunk_ids or ["chunk_7", "chunk_12"]
    starting_phase = options.from_phase or 4
    return JobRerunResponse(
        success=True,
        data=JobRerunData(
            job_id=job_id,
            rerun_id="uuid",
            status="RUNNING",
            rerun_type=payload.rerun_type,
            chunks_to_retry=chunks,
            chunks_from_cache=["chunk_1", "chunk_2", "..."],
            starting_phase=starting_phase,
        ),
        errors=[],
    )


@router.get("/jobs/{job_id}/chunks", response_model=JobChunksResponse, summary="Get detailed chunk status for Phase 4")
def get_chunks(job_id: str) -> JobChunksResponse:
    STATE.seed_job(job_id)
    chunk_statuses = STATE.jobs[job_id]["chunks"]
    summary = ChunkSummary(
        success=sum(1 for c in chunk_statuses if c.status == "SUCCESS"),
        failed=sum(1 for c in chunk_statuses if c.status == "FAILED"),
        permanently_failed=sum(1 for c in chunk_statuses if c.status == "PERMANENTLY_FAILED"),
        in_progress=sum(1 for c in chunk_statuses if c.status == "IN_PROGRESS"),
    )
    return JobChunksResponse(
        success=True,
        data=JobChunksData(job_id=job_id, total_chunks=len(chunk_statuses), chunk_statuses=chunk_statuses, summary=summary),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/retry-chunks",
    response_model=RetryChunksResponse,
    summary="Manually retry specific failed chunks (Case 6: Manual Retry Selection)",
)
def retry_chunks(job_id: str, payload: RetryChunksRequest) -> RetryChunksResponse:
    _ = payload
    STATE.seed_job(job_id)
    return RetryChunksResponse(
        success=True,
        data=RetryChunksData(job_id=job_id, chunks_queued=payload.chunk_ids, status="RETRYING"),
        errors=[],
    )


@router.post(
    "/jobs/{job_id}/change-detection",
    response_model=ChangeDetectionResponse,
    summary="Compare with previous job and detect changes",
)
def change_detection(job_id: str, payload: ChangeDetectionRequest) -> ChangeDetectionResponse:
    return ChangeDetectionResponse(
        success=True,
        data=ChangeDetectionData(
            current_job_id=job_id,
            previous_job_id=payload.compare_with_job_id,
            changes_detected=True,
            change_summary=ChangeSummary(files_added=5, files_modified=12, files_deleted=3, total_affected_chunks=8),
            changed_files=[
                ChangedFile(path="src/api/UserController.java", change_type="modified", lines_changed=42),
            ],
        ),
        errors=[],
    )


@router.get(
    "/jobs/{job_id}/diff",
    response_model=JobDiffResponse,
    summary="Show what changed from the last run (Diff Against Previous)",
)
def job_diff(
    job_id: str,
    compare_with: str = Query(..., description="Previous job id to compare against"),
    format: JobDiffFormat = Query(default=JobDiffFormat.summary),
) -> JobDiffResponse:
    STATE.seed_job(job_id)
    detailed = STATE.jobs[job_id]["diff"]["detailed"] if format == JobDiffFormat.detailed else None
    return JobDiffResponse(
        success=True,
        data=JobDiffData(
            current_job_id=job_id,
            previous_job_id=compare_with,
            diff_summary=STATE.jobs[job_id]["diff"]["summary"],
            detailed_changes=detailed,
        ),
        errors=[],
    )

