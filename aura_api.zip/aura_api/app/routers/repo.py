from fastapi import APIRouter

from ..models import RepoCloneRequest, RepoCloneResponse, RepoCloneData
from ..state import STATE

router = APIRouter(tags=["repo"])


@router.post("/repo/bitbucket", response_model=RepoCloneResponse, summary="Clone Bitbucket repository to S3")
def clone_bitbucket(payload: RepoCloneRequest) -> RepoCloneResponse:
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0}
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )


@router.post("/repo/github", response_model=RepoCloneResponse, summary="Clone GitHub repository to S3")
def clone_github(payload: RepoCloneRequest) -> RepoCloneResponse:
    upload_id = "uuid"
    STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0}
    return RepoCloneResponse(
        success=True,
        data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
        errors=[],
    )

