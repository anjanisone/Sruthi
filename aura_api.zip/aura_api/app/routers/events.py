from datetime import datetime

from fastapi import APIRouter, Query

from ..models import EventsResponse, EventsData, EventType, JobEvent
from ..state import STATE

router = APIRouter(tags=["events"])


@router.get(
    "/jobs/{job_id}/events",
    response_model=EventsResponse,
    summary="Polling endpoint for job events (alternative to WebSocket)",
)
def poll_events(
    job_id: str,
    since: str | None = Query(default=None, description="ISO8601 timestamp"),
    event_types: str | None = Query(default=None, description="Comma-separated event types to filter"),
) -> EventsResponse:
    _ = since
    STATE.seed_job(job_id)
    events = STATE.events.get(job_id, [])
    if event_types:
        allowed = {t.strip() for t in event_types.split(",") if t.strip()}
        events = [e for e in events if e.type in allowed]  # type: ignore[comparison-overlap]

    if not events:
        events = [
            JobEvent(
                event_id="uuid",
                type=EventType.JOB_COMPLETE,
                timestamp=datetime.utcnow(),
                data={"job_id": job_id, "status": "COMPLETED", "duration_seconds": 123, "output_summary": {}},
            )
        ]

    return EventsResponse(success=True, data=EventsData(events=events, last_event_id=events[-1].event_id, has_more=False), errors=[])

