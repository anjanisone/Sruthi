from fastapi import APIRouter, Query

from ..models import FileListResponse, FileListData, FileListItem, FilePreviewResponse, FilePreviewData

router = APIRouter(tags=["files"])


@router.get(
    "/uploads/{upload_id}/files",
    response_model=FileListResponse,
    summary="List files/directories for an upload",
)
def list_files(
    upload_id: str,
    current_path: str = Query(default="src/", description="Directory path to list", examples=["src/"]),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=500),
) -> FileListResponse:
    return FileListResponse(
        success=True,
        data=FileListData(
            upload_id=upload_id,
            current_path=current_path,
            items=[
                FileListItem(
                    name="UserController.java",
                    path="src/api/UserController.java",
                    type="file",
                    size_bytes=4096,
                    language="java",
                ),
                FileListItem(
                    name="services",
                    path="src/services/",
                    type="directory",
                    item_count=12,
                ),
            ],
            pagination={"page": page, "page_size": page_size, "total_items": 150, "total_pages": 3},
        ),
        errors=[],
    )


@router.get(
    "/files/{path:path}",
    response_model=FilePreviewResponse,
    summary="Preview individual file content",
)
def preview_file(
    path: str,
    upload_id: str = Query(..., description="Upload identifier"),
    line_start: int | None = Query(default=None, ge=1),
    line_end: int | None = Query(default=None, ge=1),
) -> FilePreviewResponse:
    _ = upload_id, line_start, line_end
    return FilePreviewResponse(
        success=True,
        data=FilePreviewData(
            path=path,
            language="java",
            size_bytes=4096,
            line_count=150,
            content="package com.example...",
            syntax_highlighted=True,
            encoding="UTF-8",
        ),
        errors=[],
    )

