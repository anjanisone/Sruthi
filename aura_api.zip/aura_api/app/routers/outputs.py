from fastapi import APIRouter, Query

from ..models import DownloadResponse, DownloadData, DownloadUrls, OutputsResponse, OutputsData
from ..state import STATE

router = APIRouter(tags=["outputs"])


@router.get(
    "/jobs/{job_id}/outputs",
    response_model=OutputsResponse,
    summary="List all generated outputs",
)
def list_outputs(job_id: str) -> OutputsResponse:
    STATE.seed_job(job_id)
    return OutputsResponse(
        success=True,
        data=OutputsData(job_id=job_id, status="COMPLETED", outputs=STATE.jobs[job_id]["outputs"]),
        errors=[],
    )


@router.get(
    "/jobs/{job_id}/download",
    response_model=DownloadResponse,
    summary="Get download URLs for outputs",
)
def download_outputs(
    job_id: str,
    format: str = Query(default="all", pattern="^(pdf|html|txt|markdown|all)$"),
    category: str | None = Query(default=None),
    bundle: bool = Query(default=False),
) -> DownloadResponse:
    STATE.seed_job(job_id)
    individual = STATE.jobs[job_id]["download_individual"]
    if category is not None:
        individual = [i for i in individual if i.category == category]
    if format != "all":
        individual = [i for i in individual if i.format == format]

    return DownloadResponse(
        success=True,
        data=DownloadData(
            job_id=job_id,
            download_urls=DownloadUrls(
                bundle_url="https://presigned-url-to-zip..." if bundle else None,
                individual=individual,
            ),
        ),
        errors=[],
    )

