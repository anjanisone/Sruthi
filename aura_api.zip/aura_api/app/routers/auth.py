from fastapi import APIRouter

from ..models import AuthTokenRequest, AuthTokenResponse, AuthTokenData

router = APIRouter(tags=["auth"])


@router.post("/auth/token", response_model=AuthTokenResponse, summary="Exchange credentials for API token")
def auth_token(payload: AuthTokenRequest) -> AuthTokenResponse:
    return AuthTokenResponse(
        success=True,
        data=AuthTokenData(
            access_token="jwt_token",
            token_type="Bearer",
            expires_in=3600,
            scope="read write",
        ),
        errors=[],
    )

