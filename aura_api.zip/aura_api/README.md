# AURA API (FastAPI) — Endpoint Documentation Prototype

This project is a lightweight FastAPI implementation that mirrors the **endpoint shapes** (paths, request bodies, response envelopes) captured in the `Sruthi/6` “API Plan” screenshots.

## Run locally

```bash
cd "aura_api"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then open:
- **Swagger UI**: `http://127.0.0.1:8000/docs`
- **OpenAPI JSON**: `http://127.0.0.1:8000/openapi.json`

## Notes

- This is **documentation-first**: endpoints return example-shaped payloads and maintain minimal in-memory state for demo purposes.
- Authentication is included as an endpoint (`POST /auth/token`) but **auth enforcement is not implemented** (by design for rapid prototyping).

