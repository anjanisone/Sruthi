from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.responses import HTMLResponse

from . import settings
from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .ingest.router import router as ingest_router
from .jobs.router import router as jobs_router
from .kb.router import router as kb_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .review.router import router as review_router
from .upload.router import router as upload_router

_DOCS_OFFLINE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>AURA API — docs (offline)</title></head>
<body style="font-family:system-ui,sans-serif;max-width:40rem;margin:2rem;line-height:1.5">
<h1>AURA API</h1>
<p><strong>CDN-free mode.</strong> Default Swagger UI loads JavaScript from <code>cdn.jsdelivr.net</code>, which is
often blocked on corporate Windows laptops—so <code>/docs</code> can spin forever even when the API is fine.</p>
<ul>
  <li><a href="/openapi.json"><code>GET /openapi.json</code></a> — OpenAPI spec (import into Postman / Insomnia)</li>
  <li><a href="/upload-zip/ui"><code>GET /upload-zip/ui</code></a> — Zip upload page</li>
  <li><a href="/meta"><code>GET /meta</code></a> — Troubleshooting JSON</li>
  <li><a href="/health"><code>GET /health</code></a></li>
</ul>
<p>To use interactive Swagger again on an open network, unset <code>AURA_DOCS_CDN_OFFLINE</code> and restart.</p>
</body></html>"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.outbound_token_provider = create_outbound_token_provider()
    logging.info(
        "AURA hints: upload logs use prefix 'upload_zip' (logger app.upload.router). "
        "Swagger UI loads in the browser from AURA_SWAGGER_UI_DIST_CDN (see /meta); server HTTP_PROXY does not affect that. "
        "If /docs never finishes but /openapi.json is 200, set AURA_DOCS_CDN_OFFLINE=1 or point AURA_SWAGGER_UI_DIST_CDN to an allowed mirror. "
        "If uvicorn --reload flaps under OneDrive, omit --reload or use --reload-delay 2."
    )
    yield


app = FastAPI(
    title="AURA API",
    version="0.2.3",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
)

_cdn = settings.SWAGGER_UI_DIST_CDN

if settings.DOCS_CDN_OFFLINE:

    @app.get("/docs", include_in_schema=False)
    async def docs_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)

    @app.get("/redoc", include_in_schema=False)
    async def redoc_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)
else:

    @app.get("/docs", include_in_schema=False)
    async def swagger_ui() -> HTMLResponse:
        return get_swagger_ui_html(
            openapi_url=app.openapi_url,
            title=f"{app.title} — Swagger UI",
            swagger_js_url=f"{_cdn}/swagger-ui-bundle.js",
            swagger_css_url=f"{_cdn}/swagger-ui.css",
            swagger_favicon_url=f"{_cdn}/favicon-32x32.png",
        )

    @app.get("/redoc", include_in_schema=False)
    async def redoc_html() -> HTMLResponse:
        return get_redoc_html(
            openapi_url=app.openapi_url,
            title=f"{app.title} — ReDoc",
            redoc_js_url=settings.REDOC_STANDALONE_JS,
        )

app.add_middleware(AuthEnforcementMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(upload_router)
app.include_router(ingest_router)
app.include_router(kb_router)
app.include_router(jobs_router)
app.include_router(review_router)


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok"}


@app.get("/meta", tags=["meta"])
def deployment_meta() -> dict:
    return {
        "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "swagger_custom_cdn",
        "swagger_ui_dist_cdn": settings.SWAGGER_UI_DIST_CDN,
        "redoc_js": settings.REDOC_STANDALONE_JS,
        "swagger_browser_note": (
            "Swagger JS/CSS load in the browser, not in Python. Corporate aProxy/Zscaler must allow that host, "
            "or set the OS/browser system proxy. Server-side HTTP_PROXY/HTTPS_PROXY in .env helps boto3/S3 only."
        ),
        "if_docs_spins": (
            "If /openapi.json is 200 but /docs spins: (1) Point AURA_SWAGGER_UI_DIST_CDN / AURA_REDOC_STANDALONE_JS "
            "to an internal artifact mirror IT allows. (2) Or set AURA_DOCS_CDN_OFFLINE=1. (3) Or use Postman with /openapi.json."
        ),
        "upload_logs": "Server logs: logger app.upload.router, message prefix upload_zip",
        "upload_ui": "/upload-zip/ui",
        "upload_api": "POST /upload-zip/file",
        "reload_onedrive": "If server restarts in a loop under OneDrive, run uvicorn without --reload or use --reload-delay 2",
        "s3_https_proxy": "set" if settings.BOTO_HTTPS_PROXY_CONFIGURED else "unset",
        "s3_connecttimeout_hint": (
            "If uploads fail with ConnectTimeout to s3.amazonaws.com, set HTTPS_PROXY/HTTP_PROXY and NO_PROXY "
            "in .env, or AURA_HTTPS_PROXY/AURA_HTTP_PROXY/AURA_NO_PROXY (see .env.example). "
            "Do not list s3.amazonaws.com or *.amazonaws.com in NO_PROXY unless IT requires it."
        ),
    }


@app.websocket("/ws/jobs/{job_id}")
async def job_events_websocket(websocket: WebSocket, job_id: str) -> None:
    await websocket.accept()
    try:
        await websocket.send_json(
            {"event": "phase", "job_id": job_id, "phase": 1, "message": "stream_open"}
        )
        await websocket.send_json(
            {"event": "chunk", "job_id": job_id, "chunk_id": "chunk_1", "status": "SUCCESS"}
        )
        await websocket.send_json({"event": "complete", "job_id": job_id, "ok": True})
    except WebSocketDisconnect:
        return
