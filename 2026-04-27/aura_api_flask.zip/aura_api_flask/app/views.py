from __future__ import annotations

import requests
from flask import Flask, Response, jsonify

from . import settings

_DOCS_OFFLINE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>AURA API — docs (offline)</title></head>
<body style="font-family:system-ui,sans-serif;max-width:40rem;margin:2rem;line-height:1.5">
<h1>AURA API (Flask)</h1>
<p><strong>CDN-free mode.</strong> Interactive OpenAPI is not bundled; use JSON below or import into Postman.</p>
<ul>
  <li><a href="/meta"><code>GET /meta</code></a> — deployment / troubleshooting JSON</li>
  <li><a href="/upload-zip/ui"><code>GET /upload-zip/ui</code></a> — Zip upload page</li>
  <li><a href="/health"><code>GET /health</code></a></li>
</ul>
<p>This tree is <strong>Flask-only</strong> (no FastAPI / no CDN). Use Postman, curl, or your client against the JSON routes.</p>
</body></html>"""


def register_routes(app: Flask) -> None:
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/meta")
    def deployment_meta():
        return jsonify(
            {
                "service": "flask",
                "client_howto": "Use Postman, curl, or any HTTP client. FastAPI build adds interactive /docs with configurable CDN (see AURA_SWAGGER_UI_DIST_CDN in .env.example).",
                "swagger_ui_dist_cdn": settings.SWAGGER_UI_DIST_CDN,
                "redoc_js": settings.REDOC_STANDALONE_JS,
                "swagger_browser_note": (
                    "Any interactive Swagger UI loads assets in the browser; configure OS/browser proxy (aProxy) "
                    "or an internal mirror URL. Server HTTP_PROXY in .env is for boto3/S3 only."
                ),
                "aws_profile": settings.AWS_PROFILE_RESOLVED or "default_chain",
                "github_token": "set" if settings.GITHUB_TOKEN_CONFIGURED else "unset",
                "github_check": "GET /github/connection (uses AURA_GITHUB_TOKEN; respects corporate HTTP(S)_PROXY).",
                "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "no_swagger_bundle",
                "if_docs_spins": (
                    "Set AURA_DOCS_CDN_OFFLINE=1 for a small local /docs page, or use /meta and route URLs directly in Postman."
                ),
                "upload_logs": "Server logs: logger app.upload.routes, message prefix upload_zip",
                "upload_ui": "/upload-zip/ui",
                "upload_api": "POST /upload-zip/file (form field file=@archive.zip; same field name as browser UI)",
                "s3_https_proxy": "set" if settings.BOTO_HTTPS_PROXY_CONFIGURED else "unset",
                "s3_connecttimeout_hint": (
                    "ConnectTimeout to S3: set HTTPS_PROXY/HTTP_PROXY/NO_PROXY in .env, or AURA_HTTPS_PROXY aliases; "
                    "see .env.example. Do not list s3.amazonaws.com in NO_PROXY unless IT requires it."
                ),
            }
        )

    @app.get("/github/connection")
    def github_connection():
        if not settings.GITHUB_TOKEN:
            return (
                jsonify(
                    {
                        "ok": False,
                        "detail": "Set AURA_GITHUB_TOKEN or GITHUB_TOKEN in .env, then restart the app.",
                    }
                ),
                503,
            )
        try:
            resp = requests.get(
                "https://api.github.com/user",
                headers={
                    "Accept": "application/vnd.github+json",
                    "Authorization": f"Bearer {settings.GITHUB_TOKEN}",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                timeout=30,
            )
        except requests.RequestException as exc:
            return jsonify({"ok": False, "detail": str(exc)}), 502
        if resp.status_code != 200:
            return (
                jsonify(
                    {
                        "ok": False,
                        "status": resp.status_code,
                        "detail": (resp.text or "")[:1000],
                    }
                ),
                401,
            )
        data = resp.json()
        return jsonify(
            {
                "ok": True,
                "login": data.get("login"),
                "id": data.get("id"),
                "name": data.get("name"),
            }
        )

    if settings.DOCS_CDN_OFFLINE:

        @app.get("/docs")
        def docs_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

        @app.get("/redoc")
        def redoc_offline():
            return Response(_DOCS_OFFLINE_HTML, mimetype="text/html; charset=utf-8")

    @app.after_request
    def _cors(resp):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        return resp
