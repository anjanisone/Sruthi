from __future__ import annotations

import re
from urllib.parse import quote

import boto3
from botocore.client import BaseClient
from botocore.config import Config

from .. import settings

# Avoid hanging on EC2 instance metadata when developing locally without IAM role.
_S3_CONFIG = Config(
    connect_timeout=15,
    read_timeout=600,
    retries={"max_attempts": 5, "mode": "standard"},
)


def s3_client() -> BaseClient:
    return boto3.client("s3", region_name=settings.S3_REGION, config=_S3_CONFIG)


def safe_object_basename(file_name: str) -> str:
    base = (file_name or "").strip().replace("\\", "/").split("/")[-1]
    if not base or base in {".", ".."}:
        raise ValueError("file_name must be a non-empty basename.")
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("._") or "upload.bin"
    return cleaned[:200]


def object_https_url(bucket: str, region: str, key: str) -> str:
    encoded = quote(key, safe="/")
    if region == "us-east-1":
        return f"https://{bucket}.s3.amazonaws.com/{encoded}"
    return f"https://{bucket}.s3.{region}.amazonaws.com/{encoded}"


def build_upload_key(upload_id: str, safe_name: str) -> str:
    prefix = settings.S3_UPLOAD_PREFIX.strip().strip("/")
    return f"{prefix}/{upload_id}/input/{safe_name}"
