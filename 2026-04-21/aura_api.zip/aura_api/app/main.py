from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from . import settings
from .auth_middleware import AuthEnforcementMiddleware
from .auth.router import router as auth_router
from .ingest.router import router as ingest_router
from .jobs.router import router as jobs_router
from .kb.router import router as kb_router
from .outbound.token_provider_factory import create_outbound_token_provider
from .review.router import router as review_router
from .upload.router import router as upload_router

_DOCS_OFFLINE_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>AURA API — docs (offline)</title></head>
<body style="font-family:system-ui,sans-serif;max-width:40rem;margin:2rem;line-height:1.5">
<h1>AURA API</h1>
<p><strong>CDN-free mode.</strong> Default Swagger UI loads JavaScript from <code>cdn.jsdelivr.net</code>, which is
often blocked on corporate Windows laptops—so <code>/docs</code> can spin forever even when the API is fine.</p>
<ul>
  <li><a href="/openapi.json"><code>GET /openapi.json</code></a> — OpenAPI spec (import into Postman / Insomnia)</li>
  <li><a href="/upload-zip/ui"><code>GET /upload-zip/ui</code></a> — Zip upload page</li>
  <li><a href="/meta"><code>GET /meta</code></a> — Troubleshooting JSON</li>
  <li><a href="/health"><code>GET /health</code></a></li>
</ul>
<p>To use interactive Swagger again on an open network, unset <code>AURA_DOCS_CDN_OFFLINE</code> and restart.</p>
</body></html>"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.outbound_token_provider = create_outbound_token_provider()
    logging.info(
        "AURA hints: upload logs use prefix 'upload_zip' (logger app.upload.router). "
        "If /docs never finishes in the browser but /openapi.json is 200, try AURA_DOCS_CDN_OFFLINE=1. "
        "If uvicorn --reload flaps under OneDrive, omit --reload or use --reload-delay 2."
    )
    yield


app = FastAPI(
    title="AURA API",
    version="0.2.3",
    lifespan=lifespan,
    docs_url=None if settings.DOCS_CDN_OFFLINE else "/docs",
    redoc_url=None if settings.DOCS_CDN_OFFLINE else "/redoc",
)

if settings.DOCS_CDN_OFFLINE:

    @app.get("/docs", include_in_schema=False)
    async def docs_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)

    @app.get("/redoc", include_in_schema=False)
    async def redoc_offline() -> HTMLResponse:
        return HTMLResponse(_DOCS_OFFLINE_HTML)

app.add_middleware(AuthEnforcementMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(upload_router)
app.include_router(ingest_router)
app.include_router(kb_router)
app.include_router(jobs_router)
app.include_router(review_router)


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok"}


@app.get("/meta", tags=["meta"])
def deployment_meta() -> dict:
    return {
        "docs_mode": "offline_no_cdn" if settings.DOCS_CDN_OFFLINE else "default_swagger_cdn",
        "swagger_ui_cdn": "https://cdn.jsdelivr.net/npm/swagger-ui-dist/ (required in default /docs unless blocked)",
        "if_docs_spins": (
            "Browser often waits on blocked CDN JS after /openapi.json returns 200. "
            "Set AURA_DOCS_CDN_OFFLINE=1 and restart for a no-CDN /docs, or import /openapi.json into Postman."
        ),
        "upload_logs": "Server logs: logger app.upload.router, message prefix upload_zip",
        "upload_ui": "/upload-zip/ui",
        "upload_api": "POST /upload-zip/file",
        "reload_onedrive": "If server restarts in a loop under OneDrive, run uvicorn without --reload or use --reload-delay 2",
    }


@app.websocket("/ws/jobs/{job_id}")
async def job_events_websocket(websocket: WebSocket, job_id: str) -> None:
    await websocket.accept()
    try:
        await websocket.send_json(
            {"event": "phase", "job_id": job_id, "phase": 1, "message": "stream_open"}
        )
        await websocket.send_json(
            {"event": "chunk", "job_id": job_id, "chunk_id": "chunk_1", "status": "SUCCESS"}
        )
        await websocket.send_json({"event": "complete", "job_id": job_id, "ok": True})
    except WebSocketDisconnect:
        return
