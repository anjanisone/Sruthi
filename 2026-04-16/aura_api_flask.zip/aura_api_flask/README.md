# AURA API (Flask) — twin of `Sruthi/aura_api`

Same routes, request/response shapes, in-memory `STATE`, auth (`POST /auth/token`, optional `AURA_REQUIRE_AUTH`), and outbound token provider wiring as the FastAPI project. Shared code is **copied** into `app/` so this folder runs standalone.

## Run locally

```bash
cd "aura_api_flask"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
flask --app wsgi run --port 5000
```

Health check: `GET http://127.0.0.1:5000/health`

Environment variables match `Sruthi/aura_api` (`AURA_*`). See that project’s `README.md` and `TODO.md`.

## Notes

- There is **no** built-in OpenAPI UI (use FastAPI `aura_api` for `/docs`, or add Flask-Swagger separately).
- When you change behaviour in one stack, update the other (or introduce a shared package later).
