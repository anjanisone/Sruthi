from __future__ import annotations

import os
from typing import FrozenSet


def _truthy(name: str, default: str = "") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


JWT_SECRET: str = os.getenv(
    "AURA_JWT_SECRET",
    "dev-only-change-me-please-use-AURA_JWT_SECRET-in-real-envs",
)
JWT_ALGORITHM: str = os.getenv("AURA_JWT_ALGORITHM", "HS256")
JWT_EXPIRES_SECONDS: int = int(os.getenv("AURA_JWT_EXPIRES_SECONDS", "3600"))

REQUIRE_AUTH: bool = _truthy("AURA_REQUIRE_AUTH")

CLIENT_ID: str = os.getenv("AURA_CLIENT_ID", "aura-demo-client")
CLIENT_SECRET: str = os.getenv("AURA_CLIENT_SECRET", "aura-demo-secret")

# Subject token types accepted for RFC 8693-style exchange (Sruthi/ref screenshots).
AWS_GET_CALLER_IDENTITY_TOKEN_TYPES: FrozenSet[str] = frozenset(
    {
        "urn:jpmc:params:identity:token-type:aws-get-caller-identity",
        "urn:aura:params:identity:token-type:aws-get-caller-identity",
    }
)

STS_POST_BODY_DEFAULT: str = "Action=GetCallerIdentity&Version=2011-06-15"


def _optional_str(name: str) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    stripped = raw.strip()
    return stripped or None


# Sruthi/ref: server-side proxy to the C2C token URL (getTokenFromC2C).
C2C_TOKEN_ENDPOINT: str | None = _optional_str("AURA_C2C_TOKEN_ENDPOINT")
C2C_REQUESTED_TOKEN_TYPE: str = os.getenv(
    "AURA_C2C_REQUESTED_TOKEN_TYPE",
    "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
)
C2C_TIMEOUT_SECONDS: int = int(os.getenv("AURA_C2C_TIMEOUT_SECONDS", "45"))
C2C_VERIFY_SSL: bool = not _truthy("AURA_C2C_INSECURE_SKIP_TLS_VERIFY")
C2C_SSL_CA_BUNDLE: str | None = _optional_str("AURA_C2C_SSL_CA_BUNDLE")

# Outbound ADFS HTTP client (Java HttpClient parity in outbound/*).
ADFS_HTTP_TIMEOUT_SECONDS: int = int(os.getenv("AURA_ADFS_HTTP_TIMEOUT_SECONDS", "45"))

# token_exchange: "c2c" = require C2C URL | "local" = STS replay + mint JWT | "auto" = C2C if URL set else local
TOKEN_EXCHANGE_MODE: str = os.getenv("AURA_TOKEN_EXCHANGE_MODE", "auto").strip().lower()

# Dev-only: expose POST /auth/build-gci-subject-token (never enable in production).
ALLOW_GCI_SUBJECT_TOKEN_BUILDER: bool = _truthy("AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER")
