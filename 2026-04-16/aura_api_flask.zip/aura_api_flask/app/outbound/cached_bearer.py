from __future__ import annotations

import threading
from datetime import datetime, timedelta, timezone
from typing import Optional

from .token_provision import TokenProvisionException


class CachedBearerMixin:
    """
    Java parity: synchronized getToken / invalidate with REFRESH_BUFFER_SECONDS (default 600s).
    Subclasses implement _fetch_new_token() -> tuple[str, int] (access_token, expires_in seconds).
    """

    REFRESH_BUFFER_SECONDS = 600

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._cached_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None

    def get_token(self) -> str:
        with self._lock:
            if self._is_token_valid():
                return self._cached_token or ""
            access_token, expires_in = self._fetch_new_token()
            self._cached_token = access_token
            self._token_expires_at = datetime.now(timezone.utc) + timedelta(seconds=int(expires_in))
            return access_token

    def invalidate(self) -> None:
        with self._lock:
            self._cached_token = None
            self._token_expires_at = None

    def _is_token_valid(self) -> bool:
        if self._cached_token is None or self._token_expires_at is None:
            return False
        now = datetime.now(timezone.utc)
        return now + timedelta(seconds=self.REFRESH_BUFFER_SECONDS) < self._token_expires_at

    def _fetch_new_token(self) -> tuple[str, int]:
        raise NotImplementedError
