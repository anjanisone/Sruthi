from __future__ import annotations

import os
from enum import Enum
from pathlib import Path
from typing import Optional

from .c2c_client_secret_provider import C2cClientSecretTokenProvider
from .cert_based_token_provider import CertBasedTokenProvider
from .token_provision import TokenProvisionException, TokenProvider


class OutboundAuthMethod(str, Enum):
    none = "none"
    cert = "cert"
    c2c_secret = "c2c_secret"


def _optional_path(name: str) -> Path | None:
    raw = os.getenv(name)
    if not raw or not raw.strip():
        return None
    return Path(raw.strip())


def _adfs_verify_arg() -> bool | str:
    bundle = os.getenv("AURA_ADFS_SSL_CA_BUNDLE", "").strip()
    if bundle:
        return bundle
    if os.getenv("AURA_ADFS_INSECURE_SKIP_TLS_VERIFY", "").strip().lower() in {"1", "true", "yes", "on"}:
        return False
    return True


def create_outbound_token_provider() -> Optional[TokenProvider]:
    """
    Factory parity with Java TokenProviderFactory + AuthMethod (CERT vs C2C).

    - cert: CertBasedTokenProvider (JWT client assertion).
    - c2c_secret: dev/lab analogue of C2C SDK (client_id + client_secret + resource + scope).
    """
    raw = (os.getenv("AURA_OUTBOUND_AUTH_METHOD", OutboundAuthMethod.none.value).strip().lower() or "none")
    try:
        method = OutboundAuthMethod(raw)
    except ValueError as exc:
        raise TokenProvisionException(
            f"Invalid AURA_OUTBOUND_AUTH_METHOD={raw!r}. Use none, cert, or c2c_secret."
        ) from exc

    if method == OutboundAuthMethod.none:
        return None

    token_endpoint = os.getenv("AURA_ADFS_TOKEN_ENDPOINT", "").strip()
    client_id = os.getenv("AURA_ADFS_CLIENT_ID", "").strip()
    resource_uri = os.getenv("AURA_ADFS_RESOURCE_URI", "").strip()
    if not token_endpoint or not client_id or not resource_uri:
        raise TokenProvisionException(
            "AURA_ADFS_TOKEN_ENDPOINT, AURA_ADFS_CLIENT_ID, and AURA_ADFS_RESOURCE_URI are required when outbound auth is enabled."
        )

    timeout = int(os.getenv("AURA_ADFS_HTTP_TIMEOUT_SECONDS", "45"))
    verify = _adfs_verify_arg()

    if method == OutboundAuthMethod.cert:
        cert_path = _optional_path("AURA_ADFS_CLIENT_CERT_PEM")
        key_path = _optional_path("AURA_ADFS_CLIENT_KEY_PEM")
        if cert_path is None or key_path is None:
            raise TokenProvisionException(
                "CERT mode requires AURA_ADFS_CLIENT_CERT_PEM and AURA_ADFS_CLIENT_KEY_PEM (PEM file paths)."
            )
        key_password = os.getenv("AURA_ADFS_CLIENT_KEY_PASSWORD") or None
        return CertBasedTokenProvider(
            token_endpoint=token_endpoint,
            client_id=client_id,
            resource_uri=resource_uri,
            cert_pem_path=cert_path,
            private_key_pem_path=key_path,
            private_key_password=key_password,
            timeout_seconds=timeout,
            verify_tls=verify,
        )

    if method == OutboundAuthMethod.c2c_secret:
        client_secret = os.getenv("AURA_C2C_CLIENT_SECRET", "").strip()
        if not client_secret:
            raise TokenProvisionException(
                "c2c_secret mode requires AURA_C2C_CLIENT_SECRET (lab analogue of the Java C2C SDK)."
            )
        return C2cClientSecretTokenProvider(
            token_endpoint=token_endpoint,
            client_id=client_id,
            client_secret=client_secret,
            resource_uri=resource_uri,
            timeout_seconds=timeout,
            verify_tls=verify,
        )

    return None
