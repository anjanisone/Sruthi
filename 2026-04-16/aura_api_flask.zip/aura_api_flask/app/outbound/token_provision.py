from __future__ import annotations

from typing import Protocol, runtime_checkable


class TokenProvisionException(RuntimeError):
    """Raised when an outbound bearer token cannot be obtained (Java: TokenProvisionException)."""


@runtime_checkable
class TokenProvider(Protocol):
    """Java TokenProvider: returns a bearer string for downstream API calls."""

    def get_token(self) -> str: ...

    def invalidate(self) -> None: ...
