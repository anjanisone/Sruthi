from __future__ import annotations

from .. import settings as app_settings
from .adfs_client import post_adfs_token
from .cached_bearer import CachedBearerMixin
from .token_provision import TokenProvisionException


class C2cClientSecretTokenProvider(CachedBearerMixin):
    """
    Lightweight stand-in for Java C2CTokenProvider when the JPMC AWS→ADFS SDK is not available.

    Uses plain OAuth2 client_credentials against ADFS with client_secret + resource + scope.
    Suitable for non-prod / lab only; production Java flow uses AwsToAdfsOAuth2ClientCredentialsGrantTokenProvider.
    """

    GRANT_TYPE = "client_credentials"
    SCOPE = "user_impersonation"

    def __init__(
        self,
        *,
        token_endpoint: str,
        client_id: str,
        client_secret: str,
        resource_uri: str,
        timeout_seconds: int | None = None,
        verify_tls: bool | str = True,
    ) -> None:
        super().__init__()
        if not client_secret:
            raise TokenProvisionException("client_secret is required for C2cClientSecretTokenProvider.")
        self._token_endpoint = token_endpoint
        self._client_id = client_id
        self._client_secret = client_secret
        self._resource_uri = resource_uri
        self._timeout_seconds = timeout_seconds or app_settings.ADFS_HTTP_TIMEOUT_SECONDS
        self._verify_tls = verify_tls

    def _fetch_new_token(self) -> tuple[str, int]:
        form = {
            "grant_type": self.GRANT_TYPE,
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "resource": self._resource_uri,
            "scope": self.SCOPE,
        }
        body = post_adfs_token(
            token_endpoint=self._token_endpoint,
            form=form,
            timeout_seconds=self._timeout_seconds,
            verify=self._verify_tls,
        )
        access_token = str(body["access_token"])
        expires_in = int(body.get("expires_in") or app_settings.JWT_EXPIRES_SECONDS)
        return access_token, expires_in
