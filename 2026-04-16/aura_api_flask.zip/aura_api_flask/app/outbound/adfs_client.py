from __future__ import annotations

from typing import Any, Dict

import requests

from .token_provision import TokenProvisionException


def post_adfs_token(*, token_endpoint: str, form: Dict[str, str], timeout_seconds: int = 45, verify: bool | str = True) -> Dict[str, Any]:
    try:
        resp = requests.post(
            token_endpoint,
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=timeout_seconds,
            verify=verify,
        )
    except requests.RequestException as exc:
        raise TokenProvisionException(f"IO error requesting bearer token from ADFS: {exc}") from exc

    try:
        body = resp.json()
    except ValueError as exc:
        raise TokenProvisionException(
            f"ADFS returned non-JSON (HTTP {resp.status_code}): {resp.text[:500]}"
        ) from exc

    if resp.status_code < 200 or resp.status_code >= 300:
        msg = body.get("error_description") or body.get("error") or resp.reason
        raise TokenProvisionException(f"ADFS token request failed (HTTP {resp.status_code}): {msg}")

    if not isinstance(body, dict) or "access_token" not in body:
        raise TokenProvisionException("ADFS response missing access_token.")

    return body
