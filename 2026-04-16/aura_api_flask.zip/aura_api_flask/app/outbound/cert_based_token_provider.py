from __future__ import annotations

from pathlib import Path

from .. import settings as app_settings
from .adfs_client import post_adfs_token
from .cached_bearer import CachedBearerMixin
from .jwt_assertion import build_adfs_client_assertion_jwt
from .token_provision import TokenProvisionException


class CertBasedTokenProvider(CachedBearerMixin):
    """
    Java CertBasedTokenProvider parity:
    grant_type=client_credentials, scope=user_impersonation,
    client_assertion_type=jwt-bearer, client_assertion=RS256 JWT, resource=<resourceUri>.
    """

    GRANT_TYPE = "client_credentials"
    SCOPE = "user_impersonation"
    CLIENT_ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"

    def __init__(
        self,
        *,
        token_endpoint: str,
        client_id: str,
        resource_uri: str,
        cert_pem_path: Path,
        private_key_pem_path: Path,
        private_key_password: str | None = None,
        timeout_seconds: int | None = None,
        verify_tls: bool | str = True,
    ) -> None:
        super().__init__()
        self._token_endpoint = token_endpoint
        self._client_id = client_id
        self._resource_uri = resource_uri
        self._cert_pem_path = cert_pem_path
        self._private_key_pem_path = private_key_pem_path
        self._private_key_password = private_key_password
        self._timeout_seconds = timeout_seconds or app_settings.ADFS_HTTP_TIMEOUT_SECONDS
        self._verify_tls = verify_tls

    def _fetch_new_token(self) -> tuple[str, int]:
        try:
            assertion = build_adfs_client_assertion_jwt(
                client_id=self._client_id,
                token_endpoint_audience=self._token_endpoint,
                cert_pem_path=self._cert_pem_path,
                private_key_pem_path=self._private_key_pem_path,
                private_key_password=self._private_key_password,
            )
        except Exception as exc:
            raise TokenProvisionException(f"Failed to build client assertion JWT: {exc}") from exc

        form = {
            "grant_type": self.GRANT_TYPE,
            "client_id": self._client_id,
            "client_assertion_type": self.CLIENT_ASSERTION_TYPE,
            "client_assertion": assertion,
            "resource": self._resource_uri,
            "scope": self.SCOPE,
        }
        body = post_adfs_token(
            token_endpoint=self._token_endpoint,
            form=form,
            timeout_seconds=self._timeout_seconds,
            verify=self._verify_tls,
        )
        access_token = str(body["access_token"])
        expires_in = int(body.get("expires_in") or app_settings.JWT_EXPIRES_SECONDS)
        return access_token, expires_in
