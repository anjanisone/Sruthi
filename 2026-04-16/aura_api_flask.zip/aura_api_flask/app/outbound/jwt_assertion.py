from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict
from uuid import uuid4

import jwt
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.serialization import load_pem_private_key


def _sha1_thumbprint_upper(cert_pem: bytes) -> str:
    cert = x509.load_pem_x509_certificate(cert_pem)
    return cert.fingerprint(hashes.SHA1()).hex().upper()


def build_adfs_client_assertion_jwt(
    *,
    client_id: str,
    token_endpoint_audience: str,
    cert_pem_path: Path,
    private_key_pem_path: Path,
    private_key_password: str | None = None,
    lifetime_seconds: int = 5 * 60,
) -> str:
    """
    Java JwtBuilder parity: RS256 client_assertion for ADFS token endpoint.

    Header kid = SHA-1 thumbprint of the client cert (uppercase hex).
    Claims iss/sub = client_id, aud = token endpoint URL, iat/exp (5 min), jti = UUID.
    """
    cert_pem = cert_pem_path.read_bytes()
    key_pem = private_key_pem_path.read_bytes()
    kid = _sha1_thumbprint_upper(cert_pem)

    private_key = load_pem_private_key(key_pem, password=private_key_password.encode() if private_key_password else None)
    if private_key is None:
        raise ValueError("Could not load private key PEM.")

    now = datetime.now(timezone.utc)
    exp = now + timedelta(seconds=lifetime_seconds)
    payload: Dict[str, Any] = {
        "iss": client_id,
        "sub": client_id,
        "aud": token_endpoint_audience,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
        "jti": str(uuid4()),
    }
    token = jwt.encode(payload, private_key, algorithm="RS256", headers={"kid": kid})
    if isinstance(token, bytes):
        return token.decode("utf-8")
    return token
