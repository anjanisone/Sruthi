from __future__ import annotations

from flask import Flask, jsonify


def register_routes(app: Flask) -> None:
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})
