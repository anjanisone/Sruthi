from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict
from uuid import uuid4

import jwt

from . import settings


def mint_access_token(*, claims: Dict[str, Any], scope: str = "read write") -> tuple[str, int]:
    now = datetime.now(timezone.utc)
    exp_seconds = settings.JWT_EXPIRES_SECONDS
    payload: Dict[str, Any] = {
        "sub": claims.get("sub", "unknown"),
        "scope": scope,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=exp_seconds)).timestamp()),
        "jti": str(uuid4()),
        **{k: v for k, v in claims.items() if k not in {"sub", "scope", "iat", "exp", "jti"}},
    }
    token = jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    if isinstance(token, bytes):
        token = token.decode("utf-8")
    return token, exp_seconds


def decode_access_token(token: str) -> Dict[str, Any]:
    return jwt.decode(
        token,
        settings.JWT_SECRET,
        algorithms=[settings.JWT_ALGORITHM],
        options={"require": ["exp", "iat", "sub"]},
    )
