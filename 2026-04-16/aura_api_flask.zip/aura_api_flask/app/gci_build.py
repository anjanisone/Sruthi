"""
Build GetCallerIdentity (GCI) subject tokens (Sruthi/ref SigV4 STS POST).

Same algorithm as ``Sruthi/c2c/gci_token.py``; embedded here so ``aura_api_flask`` stays self-contained.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _sign(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _get_signature_key(secret_key: str, date_stamp: str, region_name: str, service_name: str) -> bytes:
    k_date = _sign(("AWS4" + secret_key).encode("utf-8"), date_stamp)
    k_region = _sign(k_date, region_name)
    k_service = _sign(k_region, service_name)
    return _sign(k_service, "aws4_request")


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_gci_subject_token(
    region: str,
    audience: str,
    access_key_id: str,
    secret_access_key: str,
    session_token: Optional[str] = None,
) -> str:
    """
    Return base64(JSON) of ``{"uri": sts_https, "headers": {...}}`` for C2C ``subject_token``.
    """
    if not region or not audience or not access_key_id or not secret_access_key:
        raise ValueError("region, audience, access_key_id, and secret_access_key are required.")

    method = "POST"
    service = "sts"
    host = f"sts.{region}.amazonaws.com"
    endpoint = f"https://{host}"
    request_parameters = "Action=GetCallerIdentity&Version=2011-06-15"
    body_bytes = request_parameters.encode("utf-8")
    content_type = "application/x-www-form-urlencoded; charset=utf-8"
    content_length = str(len(body_bytes))

    now = datetime.now(timezone.utc)
    amzdate = now.strftime("%Y%m%dT%H%M%SZ")
    datestamp = now.strftime("%Y%m%d")

    header_map: Dict[str, str] = {
        "content-length": content_length,
        "content-type": content_type,
        "host": host,
        "x-amz-date": amzdate,
        "x-jpmc-audience": audience,
    }
    if session_token:
        header_map["x-amz-security-token"] = session_token

    canonical_uri = "/"
    canonical_querystring = ""
    canonical_headers = "".join(f"{k}:{header_map[k]}\n" for k in sorted(header_map))
    signed_headers = ";".join(sorted(header_map.keys()))
    payload_hash = _sha256_hex(body_bytes)
    canonical_request = (
        f"{method}\n{canonical_uri}\n{canonical_querystring}\n"
        f"{canonical_headers}\n{signed_headers}\n{payload_hash}"
    )

    algorithm = "AWS4-HMAC-SHA256"
    credential_scope = f"{datestamp}/{region}/{service}/aws4_request"
    string_to_sign = (
        f"{algorithm}\n{amzdate}\n{credential_scope}\n"
        f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    )

    signing_key = _get_signature_key(secret_access_key, datestamp, region, service)
    signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization_header = (
        f"{algorithm} Credential={access_key_id}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )

    headers: Dict[str, List[str]] = {
        "Authorization": [authorization_header],
        "Content-Length": [content_length],
        "Content-Type": [content_type],
        "Host": [host],
        "X-Amz-Date": [amzdate],
        "X-Jpmc-Audience": [audience],
    }
    if session_token:
        headers["X-Amz-Security-Token"] = [session_token]

    gci_token: Dict[str, Any] = {"uri": endpoint, "headers": headers}
    return base64.b64encode(json.dumps(gci_token, separators=(",", ":")).encode("utf-8")).decode("utf-8")
