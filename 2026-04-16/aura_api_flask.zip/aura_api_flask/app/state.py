from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from .models import (
    ChunkStatusItem,
    DetailedChange,
    DiffSummary,
    DownloadIndividualItem,
    EventType,
    FileListItem,
    JobEvent,
    JobSummary,
    OutputTypeSummary,
    ReviewSpecItem,
)


def _demo_file_tree() -> Dict[str, List[FileListItem]]:
    """Normalized directory path (trailing slash for dirs, '' for root) -> listing."""
    return {
        "": [
            FileListItem(name="src", path="src/", type="directory", item_count=2),
            FileListItem(name="README.md", path="README.md", type="file", size_bytes=1200, language="markdown"),
        ],
        "src/": [
            FileListItem(name="api", path="src/api/", type="directory", item_count=1),
            FileListItem(name="main.py", path="src/main.py", type="file", size_bytes=2048, language="python"),
        ],
        "src/api/": [
            FileListItem(
                name="UserController.java",
                path="src/api/UserController.java",
                type="file",
                size_bytes=4096,
                language="java",
            ),
        ],
    }


@dataclass
class InMemoryState:
    uploads_status: Dict[str, Dict] = field(default_factory=dict)
    estimates: Dict[str, Dict] = field(default_factory=dict)
    jobs: Dict[str, Dict] = field(default_factory=dict)
    events: Dict[str, List[JobEvent]] = field(default_factory=dict)
    ingest_file_trees: Dict[str, Dict[str, List[FileListItem]]] = field(default_factory=dict)
    knowledge_bases: Dict[str, Dict] = field(default_factory=dict)
    kb_credentials: Dict[str, Dict] = field(default_factory=dict)

    def seed_job(self, job_id: str) -> None:
        now = datetime.utcnow()
        if job_id not in self.jobs:
            self.jobs[job_id] = {
                "summary": JobSummary(
                    job_id=job_id,
                    job_name="Demo Job",
                    status="COMPLETED",
                    phase_completed=6,
                    created_at=now,
                    updated_at=now,
                    tags=["demo"],
                ),
                "chunks": [
                    ChunkStatusItem(
                        chunk_id="chunk_1",
                        status="SUCCESS",
                        files=["UserController.java", "UserService.java"],
                        token_count=12345,
                        processed_at=now,
                        duration_seconds=42,
                        cache_path=f"jobs/{job_id}/cache/chunk_1.json",
                    ),
                    ChunkStatusItem(
                        chunk_id="chunk_7",
                        status="FAILED",
                        files=["BigFile.java"],
                        error="Bedrock timeout after 3 retries",
                        retry_count=3,
                        last_attempt_at=now,
                    ),
                ],
                "review_specs": [
                    ReviewSpecItem(
                        file_path="specs/api/UserController.md",
                        original_file="src/api/UserController.java",
                        category="API",
                        size_bytes=12345,
                        preview_url="https://presigned-url-to-preview...",
                        edit_url="https://presigned-url-to-edit...",
                    )
                ],
                "outputs": {
                    "pdf": OutputTypeSummary(
                        count=45,
                        total_size_bytes=52428800,
                        path=f"jobs/{job_id}/phase6/pdfs/",
                    ),
                    "html": OutputTypeSummary(
                        count=45,
                        total_size_bytes=12428800,
                        path=f"jobs/{job_id}/phase6/html/",
                    ),
                    "markdown": OutputTypeSummary(
                        count=45,
                        total_size_bytes=2428800,
                        path=f"jobs/{job_id}/phase6/pages/",
                    ),
                },
                "download_individual": [
                    DownloadIndividualItem(
                        file="UserController.pdf",
                        format="pdf",
                        category="API",
                        url="https://presigned-url-to-file...",
                    )
                ],
                "diff": {
                    "summary": DiffSummary(specs_added=5, specs_modified=12, specs_deleted=3),
                    "detailed": [
                        DetailedChange(
                            file="UserController.md",
                            change_type="modified",
                            sections_changed=["API Endpoints", "Dependencies"],
                            diff_preview="- old\n+ new",
                        )
                    ],
                },
                "job_config": {},
                "current_phase": 6,
                "progress": 1.0,
                "eta": None,
                "previous_job_id": "previous_job_uuid",
            }

        if job_id not in self.events:
            self.events[job_id] = [
                JobEvent(
                    event_id="uuid",
                    type=EventType.CHUNK_PROGRESS,
                    data={"status": "SUCCESS", "completed": 45, "total": 120, "eta_seconds": 600},
                )
            ]

    def seed_ingest_tree(self, upload_id: str) -> None:
        if upload_id not in self.ingest_file_trees:
            self.ingest_file_trees[upload_id] = _demo_file_tree()


STATE = InMemoryState()

