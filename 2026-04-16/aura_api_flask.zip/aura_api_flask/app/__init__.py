from __future__ import annotations

import json

from flask import Flask
from flask_sock import Sock

from .outbound.token_provider_factory import create_outbound_token_provider
from .security import register_auth_hook

sock = Sock()


def create_app() -> Flask:
    app = Flask(__name__)
    app.json.sort_keys = False
    app.outbound_token_provider = create_outbound_token_provider()

    register_auth_hook(app)
    sock.init_app(app)

    from .auth.routes import bp as auth_bp
    from .ingest.routes import bp as ingest_bp
    from .jobs.routes import bp as jobs_bp
    from .kb.routes import bp as kb_bp
    from .review.routes import bp as review_bp
    from .upload.routes import bp as upload_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(ingest_bp)
    app.register_blueprint(kb_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(review_bp)

    @sock.route("/ws/jobs/<job_id>")
    def job_events_websocket(ws, job_id: str) -> None:
        ws.send(json.dumps({"event": "phase", "job_id": job_id, "phase": 1, "message": "stream_open"}))
        ws.send(
            json.dumps({"event": "chunk", "job_id": job_id, "chunk_id": "chunk_1", "status": "SUCCESS"})
        )
        ws.send(json.dumps({"event": "complete", "job_id": job_id, "ok": True}))

    from .views import register_routes

    register_routes(app)
    return app
