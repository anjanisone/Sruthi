# TODO

- **Full Java `C2CTokenProvider` parity**: same as `Sruthi/aura_api/TODO.md` — wire the real JPMC AWS→ADFS SDK (or internal service) when available; this Flask app mirrors the FastAPI behaviour and shares the same gap.
