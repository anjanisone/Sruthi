from __future__ import annotations

from datetime import datetime
from http import HTTPStatus

from flask import Flask, jsonify, request
from pydantic import BaseModel, ValidationError

from . import settings
from .c2c_client import C2CError, exchange_with_c2c
from .gci_build import build_gci_subject_token
from .gci_sts import GciValidationError, claims_from_sts_identity, verify_aws_get_caller_identity_subject_token
from .jwt_tokens import mint_access_token
from .models import (
    AuthTokenData,
    AuthTokenRequest,
    AuthTokenResponse,
    GciSubjectTokenBuildData,
    GciSubjectTokenBuildRequest,
    GciSubjectTokenBuildResponse,
    ChangeDetectionData,
    ChangeDetectionRequest,
    ChangeDetectionResponse,
    ChangeSummary,
    ChangedFile,
    ChunkSummary,
    DeleteJobData,
    DeleteJobResponse,
    DiscardEstimateData,
    DiscardEstimateResponse,
    DownloadData,
    DownloadResponse,
    DownloadUrls,
    Estimation,
    CostEstimate,
    CostEstimateBreakdown,
    EventType,
    FileListData,
    FileListItem,
    FileListResponse,
    FilePreviewData,
    FilePreviewResponse,
    GrantType,
    JobChunksData,
    JobChunksResponse,
    JobDiffData,
    JobDiffFormat,
    JobDiffResponse,
    JobEvent,
    JobRerunData,
    JobRerunRequest,
    JobRerunResponse,
    JobsEstimateData,
    JobsEstimateRequest,
    JobsEstimateResponse,
    ListJobsData,
    ListJobsQuerySortBy,
    ListJobsResponse,
    Pagination,
    PresignedUrlRequest,
    PresignedUrlResponse,
    PresignedUrlData,
    ProceedFromEstimateData,
    ProceedFromEstimateRequest,
    ProceedFromEstimateResponse,
    RepoCloneRequest,
    RepoCloneResponse,
    RepoCloneData,
    RetryChunksData,
    RetryChunksRequest,
    RetryChunksResponse,
    ReviewApproveData,
    ReviewApproveRequest,
    ReviewApproveResponse,
    ReviewGetData,
    ReviewGetResponse,
    ReviewRegenerateData,
    ReviewRegenerateRequest,
    ReviewRegenerateResponse,
    ReviewUpdateData,
    ReviewUpdateRequest,
    ReviewUpdateResponse,
    TimeEstimate,
    UploadConfirmData,
    UploadConfirmRequest,
    UploadConfirmResponse,
    UploadStatusData,
    UploadStatusResponse,
    OutputsData,
    OutputsResponse,
    EventsData,
    EventsResponse,
)
from .state import STATE


def _j(model: BaseModel):
    return jsonify(model.model_dump(mode="json"))


def _http_status_for_c2c(err: C2CError) -> int:
    if err.http_status is None:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status >= 500:
        return HTTPStatus.BAD_GATEWAY
    if err.http_status in (401, 403):
        return err.http_status
    if err.http_status == 400:
        return HTTPStatus.BAD_REQUEST
    return HTTPStatus.BAD_GATEWAY


def _use_c2c_for_token_exchange() -> bool:
    mode = settings.TOKEN_EXCHANGE_MODE
    if mode == "c2c":
        return True
    if mode == "local":
        return False
    return bool(settings.C2C_TOKEN_ENDPOINT)


def register_routes(app: Flask) -> None:
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.post("/auth/token")
    def auth_token():
        try:
            payload = AuthTokenRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY

        if payload.grant_type == GrantType.client_credentials:
            if payload.client_id != settings.CLIENT_ID or payload.client_secret != settings.CLIENT_SECRET:
                return jsonify({"detail": "Invalid client credentials."}), HTTPStatus.UNAUTHORIZED
            access_token, expires_in = mint_access_token(
                claims={"sub": f"client:{payload.client_id}", "auth_method": "client_credentials"},
            )
            scope = "read write"
        elif payload.grant_type == GrantType.token_exchange:
            if payload.subject_token_type not in settings.AWS_GET_CALLER_IDENTITY_TOKEN_TYPES:
                return jsonify({"detail": "Unsupported subject_token_type for this server."}), HTTPStatus.BAD_REQUEST
            assert payload.audience is not None and payload.subject_token is not None

            use_c2c = _use_c2c_for_token_exchange()
            if settings.TOKEN_EXCHANGE_MODE == "c2c" and not settings.C2C_TOKEN_ENDPOINT:
                return (
                    jsonify({"detail": "Token exchange is configured for C2C but AURA_C2C_TOKEN_ENDPOINT is not set."}),
                    HTTPStatus.SERVICE_UNAVAILABLE,
                )

            if use_c2c:
                try:
                    body = exchange_with_c2c(
                        audience=payload.audience,
                        subject_token=payload.subject_token,
                        subject_token_type=payload.subject_token_type,
                    )
                except C2CError as exc:
                    return jsonify({"detail": str(exc)}), _http_status_for_c2c(exc)
                access_token = str(body["access_token"])
                raw_exp = body.get("expires_in")
                expires_in = int(raw_exp) if raw_exp is not None else settings.JWT_EXPIRES_SECONDS
                scope = str(body.get("scope") or "read write")
            else:
                try:
                    identity = verify_aws_get_caller_identity_subject_token(payload.subject_token)
                except GciValidationError as exc:
                    return jsonify({"detail": str(exc)}), HTTPStatus.UNAUTHORIZED
                claims, scope = claims_from_sts_identity(identity, audience=payload.audience)
                access_token, expires_in = mint_access_token(claims=claims, scope=scope)
        else:
            return jsonify({"detail": "Unsupported grant_type."}), HTTPStatus.BAD_REQUEST

        return _j(
            AuthTokenResponse(
                success=True,
                data=AuthTokenData(
                    access_token=access_token,
                    token_type="Bearer",
                    expires_in=expires_in,
                    scope=scope,
                ),
                errors=[],
            )
        )

    @app.post("/auth/build-gci-subject-token")
    def build_gci_subject_token_route():
        if not settings.ALLOW_GCI_SUBJECT_TOKEN_BUILDER:
            return (
                jsonify(
                    {
                        "detail": "GCI builder is disabled. Set AURA_ALLOW_GCI_SUBJECT_TOKEN_BUILDER=true to enable (dev only)."
                    }
                ),
                HTTPStatus.NOT_FOUND,
            )
        try:
            payload = GciSubjectTokenBuildRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        try:
            token = build_gci_subject_token(
                region=payload.region,
                audience=payload.audience,
                access_key_id=payload.access_key_id,
                secret_access_key=payload.secret_access_key,
                session_token=payload.session_token,
            )
        except ValueError as exc:
            return jsonify({"detail": str(exc)}), HTTPStatus.BAD_REQUEST
        return _j(
            GciSubjectTokenBuildResponse(
                success=True,
                data=GciSubjectTokenBuildData(subject_token=token),
                errors=[],
            )
        )

    @app.post("/upload/presigned-url")
    def create_presigned_url():
        try:
            payload = PresignedUrlRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        upload_id = "uuid"
        STATE.uploads_status[upload_id] = {"status": "UPLOADING", "file_count": 0}
        return _j(
            PresignedUrlResponse(
                success=True,
                data=PresignedUrlData(
                    upload_id=upload_id,
                    presigned_url="https://s3.amazonaws.com/...",
                    expires_in=3600,
                    s3_path=f"jobs/{upload_id}/input/",
                    max_file_size_bytes=524288000,
                ),
                errors=[],
            )
        )

    @app.post("/upload/confirm")
    def confirm_upload():
        try:
            payload = UploadConfirmRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        STATE.uploads_status[payload.upload_id] = {"status": "COMPLETED", "file_count": 150}
        return _j(
            UploadConfirmResponse(
                success=True,
                data=UploadConfirmData(upload_id=payload.upload_id, status="VALIDATED", file_count=150),
                errors=[],
            )
        )

    @app.get("/upload/<upload_id>/status")
    def upload_status(upload_id: str):
        record = STATE.uploads_status.get(upload_id) or {"status": "CLONING", "file_count": 150}
        return _j(
            UploadStatusResponse(
                success=True,
                data=UploadStatusData(upload_id=upload_id, status=record["status"], file_count=record["file_count"]),
                errors=[],
            )
        )

    @app.post("/repo/bitbucket")
    def clone_bitbucket():
        try:
            payload = RepoCloneRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        _ = payload
        upload_id = "uuid"
        STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0}
        return _j(
            RepoCloneResponse(
                success=True,
                data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
                errors=[],
            )
        )

    @app.post("/repo/github")
    def clone_github():
        try:
            payload = RepoCloneRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        _ = payload
        upload_id = "uuid"
        STATE.uploads_status[upload_id] = {"status": "CLONING", "file_count": 0}
        return _j(
            RepoCloneResponse(
                success=True,
                data=RepoCloneData(upload_id=upload_id, status="CLONING", estimated_time_seconds=120),
                errors=[],
            )
        )

    @app.get("/uploads/<upload_id>/files")
    def list_files(upload_id: str):
        current_path = request.args.get("current_path", "src/")
        page = int(request.args.get("page", 1))
        page_size = int(request.args.get("page_size", 50))
        return _j(
            FileListResponse(
                success=True,
                data=FileListData(
                    upload_id=upload_id,
                    current_path=current_path,
                    items=[
                        FileListItem(
                            name="UserController.java",
                            path="src/api/UserController.java",
                            type="file",
                            size_bytes=4096,
                            language="java",
                        ),
                        FileListItem(
                            name="services",
                            path="src/services/",
                            type="directory",
                            item_count=12,
                        ),
                    ],
                    pagination=Pagination(page=page, page_size=page_size, total_items=150, total_pages=3),
                ),
                errors=[],
            )
        )

    @app.get("/files/<path:path>")
    def preview_file(path: str):
        upload_id = request.args.get("upload_id")
        if not upload_id:
            return jsonify({"detail": "upload_id query parameter is required"}), HTTPStatus.BAD_REQUEST
        line_start = request.args.get("line_start", type=int)
        line_end = request.args.get("line_end", type=int)
        _ = line_start, line_end
        return _j(
            FilePreviewResponse(
                success=True,
                data=FilePreviewData(
                    path=path,
                    language="java",
                    size_bytes=4096,
                    line_count=150,
                    content="package com.example...",
                    syntax_highlighted=True,
                    encoding="UTF-8",
                ),
                errors=[],
            )
        )

    @app.get("/jobs")
    def list_jobs():
        sort_by = request.args.get("sort_by", ListJobsQuerySortBy.created_at.value)
        sort_order = request.args.get("sort_order", "desc")
        if sort_order not in {"asc", "desc"}:
            return jsonify({"detail": "sort_order must be asc or desc"}), HTTPStatus.BAD_REQUEST
        page = int(request.args.get("page", 1))
        page_size = int(request.args.get("page_size", 50))
        _ = sort_by, sort_order
        STATE.seed_job("uuid")
        jobs = [STATE.jobs["uuid"]["summary"]]
        return _j(
            ListJobsResponse(
                success=True,
                data=ListJobsData(
                    jobs=jobs,
                    pagination=Pagination(page=page, page_size=page_size, total_items=len(jobs), total_pages=1),
                ),
                errors=[],
            )
        )

    @app.delete("/jobs/<job_id>")
    def delete_job(job_id: str):
        STATE.seed_job(job_id)
        prev = STATE.jobs[job_id]["summary"].status
        new = "CANCELLED" if prev == "RUNNING" else "DELETED"
        return _j(
            DeleteJobResponse(
                success=True,
                data=DeleteJobData(job_id=job_id, previous_status=prev, new_status=new),
                errors=[],
            )
        )

    @app.post("/jobs/estimate")
    def estimate_job():
        try:
            payload = JobsEstimateRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        estimate_id = "uuid"
        STATE.estimates[estimate_id] = {"upload_id": payload.upload_id, "created_at": datetime.utcnow()}
        return _j(
            JobsEstimateResponse(
                success=True,
                data=JobsEstimateData(
                    estimate_id=estimate_id,
                    status="ESTIMATED",
                    estimation=Estimation(
                        total_files=150,
                        total_lines=45000,
                        total_tokens=125000,
                        estimated_chunks=25,
                        oversized_files=3,
                        languages_detected={"java": 80, "python": 50, "javascript": 20},
                    ),
                    cost_estimate=CostEstimate(
                        bedrock_input_tokens=125000,
                        bedrock_output_tokens=75000,
                        estimated_cost_usd=2.45,
                        pricing_model="claude-3-sonnet",
                        breakdown=CostEstimateBreakdown(phase_4_input_cost=1.0, phase_4_output_cost=1.0),
                    ),
                    time_estimate=TimeEstimate(
                        estimated_duration_minutes=15,
                        phase_breakdown={"phase_1": 1, "phase_2": 1, "phase_3": 1, "phase_4": 10, "phase_5": 1},
                    ),
                    phase_1_output_path=f"jobs/{estimate_id}/phase1/",
                ),
                errors=[],
            )
        )

    @app.post("/jobs/estimate/<estimate_id>/proceed")
    def proceed_from_estimate(estimate_id: str):
        try:
            payload = ProceedFromEstimateRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        _ = payload
        job_id = "uuid"
        STATE.seed_job(job_id)
        return _j(
            ProceedFromEstimateResponse(
                success=True,
                data=ProceedFromEstimateData(
                    job_id=job_id,
                    status="RUNNING",
                    starting_phase=2,
                    skipped_phases=[1],
                    message="Job started from Phase 2 (Phase 1 results reused from estimation)",
                ),
                errors=[],
            )
        )

    @app.delete("/jobs/estimate/<estimate_id>")
    def discard_estimate(estimate_id: str):
        STATE.estimates.pop(estimate_id, None)
        return _j(
            DiscardEstimateResponse(
                success=True,
                data=DiscardEstimateData(estimate_id=estimate_id, status="DISCARDED", cleanup_completed=True),
                errors=[],
            )
        )

    @app.post("/jobs/<job_id>/rerun")
    def rerun_job(job_id: str):
        try:
            payload = JobRerunRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        STATE.seed_job(job_id)
        options = payload.options
        chunks = options.chunk_ids or ["chunk_7", "chunk_12"]
        starting_phase = options.from_phase or 4
        return _j(
            JobRerunResponse(
                success=True,
                data=JobRerunData(
                    job_id=job_id,
                    rerun_id="uuid",
                    status="RUNNING",
                    rerun_type=payload.rerun_type,
                    chunks_to_retry=chunks,
                    chunks_from_cache=["chunk_1", "chunk_2", "..."],
                    starting_phase=starting_phase,
                ),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/chunks")
    def get_chunks(job_id: str):
        STATE.seed_job(job_id)
        chunk_statuses = STATE.jobs[job_id]["chunks"]
        summary = ChunkSummary(
            success=sum(1 for c in chunk_statuses if c.status == "SUCCESS"),
            failed=sum(1 for c in chunk_statuses if c.status == "FAILED"),
            permanently_failed=sum(1 for c in chunk_statuses if c.status == "PERMANENTLY_FAILED"),
            in_progress=sum(1 for c in chunk_statuses if c.status == "IN_PROGRESS"),
        )
        return _j(
            JobChunksResponse(
                success=True,
                data=JobChunksData(
                    job_id=job_id, total_chunks=len(chunk_statuses), chunk_statuses=chunk_statuses, summary=summary
                ),
                errors=[],
            )
        )

    @app.post("/jobs/<job_id>/retry-chunks")
    def retry_chunks(job_id: str):
        try:
            payload = RetryChunksRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        STATE.seed_job(job_id)
        return _j(
            RetryChunksResponse(
                success=True,
                data=RetryChunksData(job_id=job_id, chunks_queued=payload.chunk_ids, status="RETRYING"),
                errors=[],
            )
        )

    @app.post("/jobs/<job_id>/change-detection")
    def change_detection(job_id: str):
        try:
            payload = ChangeDetectionRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        return _j(
            ChangeDetectionResponse(
                success=True,
                data=ChangeDetectionData(
                    current_job_id=job_id,
                    previous_job_id=payload.compare_with_job_id,
                    changes_detected=True,
                    change_summary=ChangeSummary(
                        files_added=5, files_modified=12, files_deleted=3, total_affected_chunks=8
                    ),
                    changed_files=[
                        ChangedFile(path="src/api/UserController.java", change_type="modified", lines_changed=42),
                    ],
                ),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/diff")
    def job_diff(job_id: str):
        compare_with = request.args.get("compare_with")
        if not compare_with:
            return jsonify({"detail": "compare_with query parameter is required"}), HTTPStatus.BAD_REQUEST
        fmt = request.args.get("format", JobDiffFormat.summary.value)
        try:
            diff_format = JobDiffFormat(fmt)
        except ValueError:
            return jsonify({"detail": "invalid format"}), HTTPStatus.BAD_REQUEST
        STATE.seed_job(job_id)
        detailed = STATE.jobs[job_id]["diff"]["detailed"] if diff_format == JobDiffFormat.detailed else None
        return _j(
            JobDiffResponse(
                success=True,
                data=JobDiffData(
                    current_job_id=job_id,
                    previous_job_id=compare_with,
                    diff_summary=STATE.jobs[job_id]["diff"]["summary"],
                    detailed_changes=detailed,
                ),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/review")
    def get_review_specs(job_id: str):
        STATE.seed_job(job_id)
        return _j(
            ReviewGetResponse(
                success=True,
                data=ReviewGetData(
                    job_id=job_id,
                    status="AWAITING_REVIEW",
                    phase_completed=5,
                    specs=STATE.jobs[job_id]["review_specs"],
                    review_expires_at=datetime.utcnow(),
                    total_specs=45,
                ),
                errors=[],
            )
        )

    @app.put("/jobs/<job_id>/review/<path:spec_path>")
    def update_review_spec(job_id: str, spec_path: str):
        try:
            payload = ReviewUpdateRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        _ = job_id, payload
        return _j(ReviewUpdateResponse(success=True, data=ReviewUpdateData(spec_path=spec_path, status="UPDATED"), errors=[]))

    @app.post("/jobs/<job_id>/review/approve")
    def approve_review(job_id: str):
        try:
            payload = ReviewApproveRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        return _j(
            ReviewApproveResponse(
                success=True,
                data=ReviewApproveData(
                    job_id=job_id, status="RUNNING", current_phase=6, output_formats=payload.output_formats
                ),
                errors=[],
            )
        )

    @app.post("/jobs/<job_id>/review/regenerate")
    def regenerate_from_review(job_id: str):
        try:
            payload = ReviewRegenerateRequest.model_validate(request.get_json() or {})
        except ValidationError as exc:
            return jsonify({"detail": exc.errors()}), HTTPStatus.UNPROCESSABLE_ENTITY
        _ = payload
        return _j(
            ReviewRegenerateResponse(
                success=True,
                data=ReviewRegenerateData(job_id=job_id, status="RUNNING", restarting_from_phase=4),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/outputs")
    def list_outputs(job_id: str):
        STATE.seed_job(job_id)
        return _j(
            OutputsResponse(
                success=True,
                data=OutputsData(job_id=job_id, status="COMPLETED", outputs=STATE.jobs[job_id]["outputs"]),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/download")
    def download_outputs(job_id: str):
        fmt = request.args.get("format", "all")
        if fmt not in {"pdf", "html", "txt", "markdown", "all"}:
            return jsonify({"detail": "invalid format"}), HTTPStatus.BAD_REQUEST
        category = request.args.get("category")
        bundle = request.args.get("bundle", "false").lower() in {"1", "true", "yes"}
        STATE.seed_job(job_id)
        individual = STATE.jobs[job_id]["download_individual"]
        if category is not None:
            individual = [i for i in individual if i.category == category]
        if fmt != "all":
            individual = [i for i in individual if i.format == fmt]
        return _j(
            DownloadResponse(
                success=True,
                data=DownloadData(
                    job_id=job_id,
                    download_urls=DownloadUrls(
                        bundle_url="https://presigned-url-to-zip..." if bundle else None,
                        individual=individual,
                    ),
                ),
                errors=[],
            )
        )

    @app.get("/jobs/<job_id>/events")
    def poll_events(job_id: str):
        since = request.args.get("since")
        event_types = request.args.get("event_types")
        _ = since
        STATE.seed_job(job_id)
        events = list(STATE.events.get(job_id, []))
        if event_types:
            allowed = {t.strip() for t in event_types.split(",") if t.strip()}
            events = [e for e in events if e.type.value in allowed]
        if not events:
            events = [
                JobEvent(
                    event_id="uuid",
                    type=EventType.JOB_COMPLETE,
                    timestamp=datetime.utcnow(),
                    data={
                        "job_id": job_id,
                        "status": "COMPLETED",
                        "duration_seconds": 123,
                        "output_summary": {},
                    },
                )
            ]
        return _j(
            EventsResponse(
                success=True,
                data=EventsData(events=events, last_event_id=events[-1].event_id, has_more=False),
                errors=[],
            )
        )
