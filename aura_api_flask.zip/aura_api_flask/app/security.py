from __future__ import annotations

from jwt.exceptions import PyJWTError
from flask import Flask, jsonify, request

from . import settings
from .jwt_tokens import decode_access_token


def _is_exempt_path(path: str) -> bool:
    if path in {"/", "/health", "/favicon.ico"}:
        return True
    if path.startswith("/docs") or path.startswith("/redoc"):
        return True
    if path in {"/openapi.json", "/auth/token"}:
        return True
    return False


def register_auth_hook(app: Flask) -> None:
    @app.before_request
    def _enforce_bearer_jwt() -> tuple | None:
        if not settings.REQUIRE_AUTH:
            return None
        if request.method == "OPTIONS" or _is_exempt_path(request.path):
            return None
        authorization = request.headers.get("Authorization")
        if not authorization or not authorization.lower().startswith("bearer "):
            return jsonify({"detail": "Not authenticated"}), 401
        token = authorization.split(" ", 1)[1].strip()
        try:
            decode_access_token(token)
        except PyJWTError:
            return jsonify({"detail": "Invalid or expired token"}), 401
        return None
